from pathlib import Path

def edit(name, substitutions):
    path = Path('pancake/src') / name
    code = path.read_text()
    for old, new in substitutions:
        assert code.count(old) == 1, (name, old)
        code = code.replace(old, new)
    path.write_text(code)

probe = "crate::job::exposure_probe"

def observe(indent, event):
    return f"{indent}#[cfg(test)]\n{indent}{probe}::record({probe}::Event::{event});\n"

edit('job/mod.rs', [('mod events;', 'mod events;\n#[cfg(test)]\n#[path = "../../../artifacts/exposure-resident/native_probe.rs"]\npub(crate) mod exposure_probe;')])
needle = '    let mut alignment = Alignment::new('
edit('job/stream.rs', [(needle, f'    #[cfg(test)]\n    let retain_input = retain_input && !{probe}::force_host();\n' + needle)])
needle = '    let resident = retain_input.then('
edit('registration/kernels.rs', [(needle, observe('    ', 'LumaUpload') + needle)])
needle = '            warp(device, frame(&image)?, map.original, self.canvas, budget)?'
edit('job/registration.rs', [(needle, f'            let warped = {needle.strip()}{' ;'.strip()}\n' + observe('            ', 'Warp') + '            warped')])
old = '''            input.into_tensor(&self.client, self.grid.width, self.grid.height)?
        } else {
            self.grid.validate(rgb)?;
            upload(&self.client, rgb)
'''
new = '''            let tensor = input.into_tensor(&self.client, self.grid.width, self.grid.height)?;
''' + observe('            ', 'Resident') + '''            tensor
        } else {
            self.grid.validate(rgb)?;
            let tensor = upload(&self.client, rgb);
''' + observe('            ', 'FusionUpload') + '''            tensor
'''
weight = '        let mut weights = weights::weights('
sync = '''        cubecl::future::block_on(self.client.sync_buffers(outputs))
            .map_err(|error| error.to_string())
'''
new_sync = '''        let completion = cubecl::future::block_on(self.client.sync_buffers(outputs))
            .map_err(|error| error.to_string());
        #[cfg(test)]
        if completion.is_ok() {
''' + observe('            ', 'FrameWait') + '''        }
        completion
'''
batch = '        self.frames = 0;'
edit('fusion/advanced/mod.rs', [(old, new), (weight, observe('        ', 'Weight') + weight),
    (sync, new_sync), (batch, observe('        ', 'Batch(self.frames)') + batch)])

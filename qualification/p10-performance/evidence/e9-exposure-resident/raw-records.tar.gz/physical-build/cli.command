taskset -c 12\,13 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli --features cubecl/cuda 

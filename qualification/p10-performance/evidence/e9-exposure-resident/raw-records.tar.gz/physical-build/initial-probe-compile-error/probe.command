taskset -c 12\,13 cargo +1.100.0 test --locked --offline --release -p pancake --lib --features cubecl/cuda --no-run --message-format json 

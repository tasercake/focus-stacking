#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/exposure-resident"
run="$base/$1"
mkdir "$run"
cd "$root/pancake"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_DIR="$root/pancake/target/exposure-resident-cpu"
git rev-parse HEAD 'HEAD^{tree}' > "$run/source.txt"
sha256sum Cargo.lock "$base/native_probe.rs" "$base/native-observation.patch" > "$run/inputs.sha256"
rustc +1.100.0 -Vv > "$run/rustc.txt"
cmd=(taskset -c 12,13 cargo +1.100.0 test --locked --offline -p pancake --lib job::exposure_probe:: -- --test-threads=1 --nocapture)
printf '%s\n' "$PWD" "CARGO_TARGET_DIR=$CARGO_TARGET_DIR CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUSTC_WRAPPER=unset RUSTC_WORKSPACE_WRAPPER=unset" > "$run/command.txt"
printf '%q ' "${cmd[@]}" >> "$run/command.txt"
printf '\n' >> "$run/command.txt"
trap 'status=$?; printf "%s\n" "$status" > "$run/exit.txt"; date -u +%FT%TZ > "$run/end.txt"' EXIT
date -u +%FT%TZ > "$run/start.txt"
/usr/bin/time -v -o "$run/resources.txt" "${cmd[@]}" > "$run/cargo.log" 2>&1

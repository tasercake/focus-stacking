#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/exposure-resident"
build="$base/physical-build"
record="$base/physical"
test -s "$base/physical-lease.txt"
grep -qx 0 "$build/exit.txt"
test "$(git rev-parse HEAD)" = 481d8052e288c54cf027808b3eaad1ea5655e128
test -z "$(git status --porcelain=v1)"
sha256sum -c "$build/cli.sha256" "$build/probe.sha256"
read -r ignored_digest executable < "$build/probe.sha256"
test -x "$executable"
mkdir -m 700 "$record"
trap 'status=$?; { date -u +%FT%TZ; printf "exit=%s\n" "$status"; } > "$record/terminal.txt"' EXIT
unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS PANCAKE_RUNTIME CUDA_VISIBLE_DEVICES
unset VK_ICD_FILENAMES VK_ADD_DRIVER_FILES LD_LIBRARY_PATH CUDA_PATH
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
export XDG_RUNTIME_DIR="$record/runtime"
mkdir -m 700 "$XDG_RUNTIME_DIR"
sha256sum "$VK_DRIVER_FILES" > "$record/icd.sha256"
nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$record/nvidia.txt"
vulkaninfo --summary > "$record/vulkaninfo.txt" 2> "$record/vulkaninfo-stderr.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$record/nvidia.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$record/vulkaninfo.txt"
test "$(grep -c '^GPU[0-9]' "$record/vulkaninfo.txt")" = 1
run_probe() (
    backend=$1
    export PANCAKE_EXPOSURE_PROBE_BACKEND="$backend"
    probe="$record/$backend"
    mkdir -m 700 "$probe"
    export HOME="$probe/home" XDG_CACHE_HOME="$probe/cache" TMPDIR="$probe/tmp"
    export CUDA_CACHE_PATH="$probe/cuda-cache"
    mkdir -m 700 "$HOME" "$XDG_CACHE_HOME" "$TMPDIR" "$CUDA_CACHE_PATH"
    export PANCAKE_EXPOSURE_PROBE_OUTPUT="$probe/output"
    if [[ "$backend" = cuda ]]; then
        export CUDA_PATH=/usr/local/cuda-12.5
        export LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64
    fi
    cd "$probe"
    cmd=(timeout --signal=TERM --kill-after=5s 60s taskset -c 12,13 "$executable"
      job::exposure_probe:: --test-threads 1)
    printf 'cwd=%q\nbackend=%q\nCUDA_PATH=%q\nLD_LIBRARY_PATH=%q\nVK_DRIVER_FILES=%q\nHOME=%q\nXDG_CACHE_HOME=%q\nTMPDIR=%q\nCUDA_CACHE_PATH=%q\noutput=%q\n' "$PWD" "$backend" "${CUDA_PATH-}" "${LD_LIBRARY_PATH-}" "$VK_DRIVER_FILES" "$HOME" "$XDG_CACHE_HOME" "$TMPDIR" "$CUDA_CACHE_PATH" "$PANCAKE_EXPOSURE_PROBE_OUTPUT" > command
    printf '%q ' "${cmd[@]}" >> command
    printf '\n' >> command
    timeout_started=$(date -u +%FT%TZ)
    printf '%s\n' "$timeout_started" > start.txt
    status=0
    "${cmd[@]}" > native.log 2>&1 || status=$?
    printf '%s\n' "$status" > exit.txt
    date -u +%FT%TZ > end.txt
    return "$status"
)
outcome=0
run_probe wgpu-vulkan || outcome=1
run_probe cuda || outcome=1
exit "$outcome"

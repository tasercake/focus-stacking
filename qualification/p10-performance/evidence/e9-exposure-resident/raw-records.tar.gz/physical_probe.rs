//! Temporary native witness for real aligned exposure uploads and batching.

use std::cell::RefCell;
use std::path::{Path, PathBuf};

use crate::config::{
    AlignmentMode, AlignmentReference, BitDepth, DevicePreference, JobConfig, JobSettings, Method,
};
use crate::image_io::{RgbImage, export};
use crate::registration::Affine;
use crate::runtime::RuntimeOverride;

use super::{Options, run};

/// Events recorded at the actual owner-thread call sites.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum Event {
    LumaUpload,
    FusionUpload,
    Resident,
    Weight,
    FrameWait,
    Warp,
    Batch(usize),
}

/// One deterministic fixture and assertion set.
struct Fixture {
    last_shift: [f32; 2],
    last_width: u16,
    slab_size: u32,
    alignment: AlignmentMode,
    count: usize,
}

/// Capture state is private to one synthetic job and owner thread.
struct Capture {
    force_host: bool,
    events: Vec<Event>,
}

thread_local! {
    static CAPTURE: RefCell<Option<Capture>> = const { RefCell::new(None) };
}

/// Record a successful transfer or a submitted operation from the actual path.
pub(crate) fn record(event: Event) {
    CAPTURE.with_borrow_mut(|capture| {
        if let Some(active) = capture {
            active.events.push(event);
        }
    });
}

/// Force the pre-change path only during the control arm.
pub(crate) fn force_host() -> bool {
    CAPTURE.with_borrow(|active| active.as_ref().is_some_and(|run| run.force_host))
}

/// Completed samples, export bytes, transforms, progress, and actual operations.
#[derive(Debug)]
struct Witness {
    pixels: Vec<u32>,
    export: Vec<u8>,
    transforms: Vec<Affine>,
    progress: Vec<usize>,
    events: Vec<Event>,
    runtime_receipt: serde_json::Value,
}

/// Materialize five or nine analytically related exposure frames.
fn materialize(path: &Path, spec: &Fixture) -> Result<Vec<PathBuf>, String> {
    const WIDTH: u16 = 113;
    const HEIGHT: u16 = 95;
    (0..spec.count)
        .map(|index| {
            let last = index == spec.count.saturating_sub(1);
            let [dx, dy] = if last { spec.last_shift } else { [0.0, 0.0] };
            let width = if last { spec.last_width } else { WIDTH };
            let gain = if index % 2 == 0 { 0.625 } else { 0.875 };
            let mut pixels = Vec::new();
            for y in (0..HEIGHT).map(f32::from) {
                for x in (0..width).map(f32::from) {
                    let (x, y) = (x - dx, y - dy);
                    let weight_x = (0.017 * y).mul_add(y, 0.11 * x).sin();
                    let weight_y = (0.011 * x).mul_add(x, 0.16 * y).cos();
                    let coarse = 0.27_f32.mul_add(y, 0.31 * x).cos();
                    let fine = 0.19_f32.mul_add(-y, 0.13 * x).sin();
                    let scene = (0.22 * weight_x).mul_add(
                        weight_y,
                        0.14_f32.mul_add(coarse, 0.06_f32.mul_add(fine, 0.5)),
                    );
                    pixels.extend([scene * gain, scene * gain * 0.875, scene * gain * 0.75]);
                }
            }
            let raster = RgbImage::new(usize::from(width), usize::from(HEIGHT), pixels)?;
            let original = path.join(format!("exposure-{index:02}.tif"));
            export(&original, &raster, BitDepth::Sixteen, 95, &[])?;
            Ok(original)
        })
        .collect()
}

/// Exact backend name and runtime override for the physical synthetic witness.
fn target() -> Result<(&'static str, RuntimeOverride), String> {
    match std::env::var("PANCAKE_EXPOSURE_PROBE_BACKEND").as_deref() {
        Ok("cuda") => Ok(("cuda", RuntimeOverride::Cuda)),
        Ok("wgpu-vulkan") => Ok(("wgpu-vulkan", RuntimeOverride::Wgpu)),
        _ => Err("physical probe requires cuda or wgpu-vulkan".into()),
    }
}

/// Run production decoding, registration, application loop and publication.
fn capture(
    root: &Path,
    input: &[PathBuf],
    spec: &Fixture,
    force_host: bool,
) -> Result<Witness, String> {
    let arm = if force_host { "host" } else { "resident" };
    let output = root.join(format!("{arm}.tif"));
    let event_path = root.join(format!("{arm}.jsonl"));
    let config = JobConfig::new(
        input,
        Some(output.clone()),
        JobSettings {
            alignment: spec.alignment,
            alignment_reference: AlignmentReference::First,
            method: Method::ExposureFusion,
            slab_size: spec.slab_size,
            pyramid_levels: 3,
            bit_depth: BitDepth::Sixteen,
            device: DevicePreference::Gpu,
            gpu_id: Some(0),
            ..JobSettings::default()
        },
    )?;
    let options = Options {
        events_path: Some(event_path.clone()),
        runtime: Some(target()?.1),
        ..Options::default()
    };
    CAPTURE.with_borrow_mut(|active| {
        *active = Some(Capture {
            force_host,
            events: Vec::new(),
        })
    });
    let mut progress = Vec::new();
    let result = run(config, &options, |snapshot| {
        progress.push(snapshot.completed)
    });
    let events = CAPTURE
        .with_borrow_mut(Option::take)
        .ok_or("lost exposure trace")?
        .events;
    let result = result.map_err(|error| error.to_string())?;
    let transforms = (0..input.len())
        .map(|index| {
            result
                .source_transform(index)
                .ok_or("missing transform".to_owned())
        })
        .collect::<Result<Vec<_>, _>>()?;
    let receipt = std::fs::read_to_string(event_path).map_err(|error| error.to_string())?;
    let runtime_receipt = serde_json::from_str(&receipt).map_err(|error| error.to_string())?;
    let pixels = result.image().samples();
    if pixels.iter().any(|value| !value.is_finite()) {
        return Err("exposure readback contains a nonfinite result".into());
    }
    Ok(Witness {
        pixels: pixels.iter().map(|value| value.to_bits()).collect(),
        export: std::fs::read(output).map_err(|error| error.to_string())?,
        transforms,
        progress,
        events,
        runtime_receipt,
    })
}

/// Ensure only the redundant copy changes on the real stack.
fn compare(spec: &Fixture, retained: usize, warps: usize) -> Result<(), String> {
    let root = tempfile::tempdir().map_err(|error| error.to_string())?;
    let inputs = materialize(root.path(), spec)?;
    let control = capture(root.path(), &inputs, spec, true)?;
    let candidate = capture(root.path(), &inputs, spec, false)?;
    let path = PathBuf::from(
        std::env::var_os("PANCAKE_EXPOSURE_PROBE_OUTPUT").ok_or("missing proof output")?,
    );
    let tag = format!(
        "{}-{:?}-{}-{}-{:?}",
        spec.count, spec.alignment, spec.slab_size, spec.last_width, spec.last_shift
    );
    let path = path.join(tag);
    std::fs::create_dir_all(&path).map_err(|error| error.to_string())?;
    for (arm, witness) in [("control", &control), ("candidate", &candidate)] {
        std::fs::write(path.join(format!("{arm}.tif")), &witness.export)
            .map_err(|error| error.to_string())?;
        let raw: Vec<u8> = witness
            .pixels
            .iter()
            .flat_map(|bits| bits.to_le_bytes())
            .collect();
        std::fs::write(path.join(format!("{arm}.f32le")), raw)
            .map_err(|error| error.to_string())?;
        let proof = serde_json::json!({
            "event": witness.runtime_receipt,
            "operations": witness.events.iter().map(|event| format!("{event:?}")).collect::<Vec<_>>(),
            "progress": witness.progress,
        });
        std::fs::write(
            path.join(format!("{arm}.json")),
            serde_json::to_vec_pretty(&proof).map_err(|error| error.to_string())?,
        )
        .map_err(|error| error.to_string())?;
    }
    if control.pixels != candidate.pixels
        || control.export != candidate.export
        || control.transforms != candidate.transforms
        || control.progress != candidate.progress
        || control.runtime_receipt != candidate.runtime_receipt
        || candidate.runtime_receipt["runtime"] != target()?.0
        || candidate.runtime_receipt["actual_backend"] != "gpu"
        || candidate.runtime_receipt["physical_gpu"] != true
        || candidate.runtime_receipt["device"] != "NVIDIA GeForce RTX 3090"
        || candidate.runtime_receipt["device_pci_address"] != "0000:01:00.0"
        || candidate.runtime_receipt["device_fingerprint"]
            != if target()?.0 == "cuda" {
                "ptx_sm86"
            } else {
                "spirv_4318_8708"
            }
        || candidate.runtime_receipt["completed"] != true
        || !candidate.runtime_receipt["fallback_reason"].is_null()
        || !candidate.progress.iter().copied().eq(1..=spec.count)
        || candidate
            .transforms
            .iter()
            .filter(|&&map| map != Affine::IDENTITY)
            .count()
            != warps
    {
        return Err(format!(
            "exposure output, actual physical completion, progress, or transforms changed; maps {:?}",
            candidate.transforms
        ));
    }
    let expected_batch_sizes = if spec.count == 9 {
        vec![4, 4, 1]
    } else {
        vec![4, 1]
    };
    let expected_luma = if spec.alignment == AlignmentMode::Off {
        0
    } else {
        spec.count
    };
    for (arm, witness, expected_resident) in [
        ("control", &control, 0),
        ("candidate", &candidate, retained),
    ] {
        let count = |event| witness.events.iter().filter(|&&seen| seen == event).count();
        let batches = witness
            .events
            .iter()
            .filter_map(|seen| match seen {
                Event::Batch(frames) => Some(*frames),
                _ => None,
            })
            .collect::<Vec<_>>();
        let upload = count(Event::FusionUpload);
        let actual_resident = count(Event::Resident);
        if upload != spec.count.saturating_sub(expected_resident)
            || actual_resident != expected_resident
            || count(Event::LumaUpload) != expected_luma
            || count(Event::Weight) != spec.count
            || count(Event::FrameWait) != spec.count
            || count(Event::Warp) != warps
            || batches != expected_batch_sizes
        {
            return Err(format!(
                "{arm}: expected {expected_resident} resident and {} fusion uploads, found {actual_resident} and {upload}; actual events: {:?}",
                spec.count.saturating_sub(expected_resident),
                witness.events
            ));
        }
    }
    Ok(())
}

/// Ordinary aligned exposures should reuse the exact RGB that fed luma.
#[test]
fn exposure_identity_reuses_every_rgb_upload() -> Result<(), String> {
    compare(
        &Fixture {
            last_shift: [0.0, 0.0],
            last_width: 113,
            slab_size: 0,
            alignment: AlignmentMode::Translation,
            count: 9,
        },
        9,
        0,
    )
}

/// Warp, mismatched canvas, disabled alignment and explicit slab requests retain the old route.
#[test]
fn exposure_residency_preserves_fallbacks() -> Result<(), String> {
    let mut spec = Fixture {
        last_shift: [3.25, -1.5],
        last_width: 113,
        slab_size: 0,
        alignment: AlignmentMode::Translation,
        count: 5,
    };
    compare(&spec, 4, 1)?;
    spec.last_shift = [0.0, 0.0];
    spec.last_width = 111;
    compare(&spec, 4, 1)?;
    spec.last_width = 113;
    spec.slab_size = 3;
    compare(&spec, 0, 0)?;
    spec.slab_size = 0;
    spec.alignment = AlignmentMode::Off;
    compare(&spec, 0, 0)
}

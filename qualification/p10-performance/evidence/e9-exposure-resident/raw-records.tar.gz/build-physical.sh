#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/exposure-resident"
record="$base/physical-build"
mkdir -p "$record"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CUDARC_CUDA_VERSION=12050
export CARGO_TARGET_DIR="$root/pancake/target/exposure-resident-cpu"
test "$(git rev-parse HEAD)" = 481d8052e288c54cf027808b3eaad1ea5655e128
test -z "$(git status --porcelain=v1)"
git rev-parse HEAD 'HEAD^{tree}' > "$record/source-tree.txt"
sha256sum "$root/pancake/Cargo.lock" > "$record/lock.sha256"
rustc +1.100.0 -Vv > "$record/rustc.txt"
printf '%s\n' "CARGO_BUILD_JOBS=$CARGO_BUILD_JOBS" "CARGO_INCREMENTAL=$CARGO_INCREMENTAL" "CUDARC_CUDA_VERSION=$CUDARC_CUDA_VERSION" "CARGO_TARGET_DIR=$CARGO_TARGET_DIR" "RUSTC_WRAPPER=unset" "RUSTC_WORKSPACE_WRAPPER=unset" > "$record/build-settings.txt"
restore_probe() {
  cd "$root"
  git restore --worktree pancake/src/fusion/advanced/mod.rs pancake/src/job/mod.rs pancake/src/job/registration.rs pancake/src/job/stream.rs pancake/src/registration/kernels.rs
}
trap 'status=$?; printf "%s\n" "$status" > "$record/exit.txt"; date -u +%FT%TZ > "$record/end.txt"' EXIT
if [[ "${1-}" = --probe-only ]]; then
    sha256sum -c "$record/cli.sha256"
    date -u +%FT%TZ > "$record/probe-retry-start.txt"
else
date -u +%FT%TZ > "$record/start.txt"
cd "$root/pancake"
cmd=(taskset -c 12,13 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli --features cubecl/cuda)
printf '%q ' "${cmd[@]}" > "$record/cli.command"
printf '\n' >> "$record/cli.command"
/usr/bin/time -v -o "$record/cli-resources.txt" "${cmd[@]}" > "$record/cli.log" 2>&1
elf="$CARGO_TARGET_DIR/release/pancake-cli"
sha256sum "$elf" > "$record/cli.sha256"
readelf -n "$elf" > "$record/cli-elf-notes.txt"
nm --defined-only --demangle "$elf" | awk '
    /cubecl_cuda/ { cuda++ } /cubecl_wgpu/ { wgpu++ } /wgpu_hal::vulkan/ { vulkan++ }
    END { print "CUDA", cuda; print "CubeCL wgpu", wgpu; print "Vulkan HAL", vulkan; exit !(cuda>0 && wgpu>0 && vulkan>0); }
' > "$record/cli-linked-backends.txt"
fi
test -z "$(git status --porcelain=v1)"
cd "$root"
trap 'status=$?; restore_probe; printf "%s\n" "$status" > "$record/exit.txt"; date -u +%FT%TZ > "$record/end.txt"' EXIT
python3 "$base/instrument.py"
sed -i 's@exposure-resident/native_probe\.rs@exposure-resident/physical_probe.rs@' pancake/src/job/mod.rs
git diff --check
git diff > "$record/physical-observation.patch"
sha256sum "$base/physical_probe.rs" "$record/physical-observation.patch" > "$record/physical-source.sha256"
cd "$root/pancake"
cmd=(taskset -c 12,13 cargo +1.100.0 test --locked --offline --release -p pancake
  --lib --features cubecl/cuda --no-run --message-format json)
printf '%q ' "${cmd[@]}" > "$record/probe.command"
printf '\n' >> "$record/probe.command"
/usr/bin/time -v -o "$record/probe-resources.txt" "${cmd[@]}" > "$record/probe.jsonl" 2> "$record/probe.log"
testbin=$(jq -er 'select(.reason=="compiler-artifact" and .target.name=="pancake" and .profile.test and .executable) | .executable' "$record/probe.jsonl")
test -x "$testbin"
sha256sum "$testbin" > "$record/probe.sha256"
readelf -n "$testbin" > "$record/probe-elf-notes.txt"
restore_probe
test -z "$(git status --porcelain=v1)"

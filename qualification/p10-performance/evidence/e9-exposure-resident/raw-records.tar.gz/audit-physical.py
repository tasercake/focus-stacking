"""Audit exact output and operations from the existing paired synthetic driver."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

base = Path(sys.argv[1]) / "physical"
all_cases = {
    "9-Translation-0-113-[0.0, 0.0]": (9, 9, 0, 9, [4, 4, 1]),
    "5-Translation-0-113-[3.25, -1.5]": (5, 4, 1, 5, [4, 1]),
    "5-Translation-0-111-[0.0, 0.0]": (5, 4, 1, 5, [4, 1]),
    "5-Translation-3-113-[0.0, 0.0]": (5, 0, 0, 5, [4, 1]),
    "5-Off-0-113-[0.0, 0.0]": (5, 0, 0, 0, [4, 1]),
}
result = {}
for backend in ("wgpu-vulkan", "cuda"):
    backend_dir = base / backend
    assert (backend_dir / "exit.txt").read_text().strip() == "0", backend
    assert "2 passed; 0 failed" in (backend_dir / "native.log").read_text(), backend
    output = backend_dir / "output"
    assert {p.name for p in output.iterdir()} == set(all_cases), backend
    per_case = {}
    for case, (frames, eligible, warp, luma, batches) in all_cases.items():
        pair = output / case
        stock, candidate = [json.loads((pair / (side + ".json")).read_text()) for side in ("control", "candidate")]
        assert stock["event"] == candidate["event"], (backend, case)
        actual = stock["event"]
        assert actual["completed"] is True and actual["fallback_reason"] is None, (backend, case)
        assert actual["runtime"] == backend and actual["actual_backend"] == "gpu" and actual["physical_gpu"] is True, actual
        assert actual["device"] == "NVIDIA GeForce RTX 3090" and actual["device_pci_address"] == "0000:01:00.0", actual
        assert actual["device_fingerprint"] == ("ptx_sm86" if backend == "cuda" else "spirv_4318_8708"), actual
        assert stock["progress"] == candidate["progress"] == list(range(1, frames + 1)), (backend, case)
        for run, reused in ((stock, 0), (candidate, eligible)):
            operations = Counter(run["operations"])
            assert operations == Counter({
                "LumaUpload": luma, "FusionUpload": frames - reused, "Resident": reused,
                "Weight": frames, "FrameWait": frames, "Warp": warp,
                **{f"Batch({size})": amount for size, amount in Counter(batches).items()},
            }), (backend, case, run["operations"])
            assert [int(event[6:-1]) for event in run["operations"] if event.startswith("Batch(")] == batches
        per_case[case] = {"actual_runtime": actual, "fusion_uploads": [frames, frames - eligible]}
        for format_name in ("f32le", "tif"):
            original, new = [(pair / (side + "." + format_name)).read_bytes() for side in ("control", "candidate")]
            assert original and original == new, (backend, case, format_name)
            per_case[case][format_name] = {"bytes": len(new), "sha256": sha256(new).hexdigest()}
    result[backend] = per_case
print(json.dumps(result, indent=2))

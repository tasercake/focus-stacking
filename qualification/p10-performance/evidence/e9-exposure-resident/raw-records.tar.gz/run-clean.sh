#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/exposure-resident"
record="$base/clean"
mkdir "$record" "$record/policy"
cd "$root/pancake"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_DIR="$root/pancake/target/exposure-resident-cpu"
sha256sum Cargo.lock > "$record/lock.sha256"
git rev-parse HEAD 'HEAD^{tree}' > "$record/source.txt"
cmd=(taskset -c 12,13 cargo +1.100.0 test --locked --offline -p pancake
  --lib --test cpu_job --test cpu_advanced_fusion --test cpu_fusion_contract --test cpu_stack_plan)
printf '%q ' "${cmd[@]}" > "$record/cpu.command"
printf '\n' >> "$record/cpu.command"
trap 'status=$?; printf "%s\n" "$status" > "$record/exit.txt"; date -u +%FT%TZ > "$record/end.txt"' EXIT
/usr/bin/time -v -o "$record/cpu-resources.txt" "${cmd[@]}" > "$record/cpu.log" 2>&1
taskset -c 12,13 cargo +1.100.0 metadata --offline --locked --all-features --format-version 1 > "$record/policy/metadata.json"
python3 scripts/dependency_policy.py --config deny.toml --ledger dependency-policy.json \
  --metadata "$record/policy/metadata.json" --effective-config "$record/policy/deny.toml" \
  --license-inventory "$record/policy/licenses.json" --clippy-config clippy.toml \
  --effective-clippy-dir "$record/policy/clippy" > "$record/policy.log" 2>&1
export CLIPPY_CONF_DIR="$record/policy/clippy"
cmd=(taskset -c 12,13 cargo +1.100.0 clippy --locked --offline -p pancake
  --lib --test cpu_job --test cpu_advanced_fusion --test cpu_fusion_contract --test cpu_stack_plan -- -D warnings)
printf '%q ' "${cmd[@]}" > "$record/clippy.command"
printf '\n' >> "$record/clippy.command"
"${cmd[@]}" > "$record/clippy.log" 2>&1
test -z "$(git status --porcelain=v1)"

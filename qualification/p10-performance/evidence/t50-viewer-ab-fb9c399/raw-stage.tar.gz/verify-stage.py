"""Verify the owner stage against the exact frozen T50 receipt."""

import hashlib
import json
import re
import stat
from pathlib import Path

stage = Path(__file__).resolve().parent
tree = stage.parent.parent
frozen_path = tree / "qualification/t50-generated/evidence/native-t50-receipt.json"
prepared = json.loads((stage / "prepared-stage.json").read_bytes())
receipt_path = stage / "materialization.json"
receipt_bytes = receipt_path.read_bytes()
receipt = json.loads(receipt_bytes)
frozen_bytes = frozen_path.read_bytes()
frozen = json.loads(frozen_bytes)
frozen_sha256 = hashlib.sha256(frozen_bytes).hexdigest()

def require(condition, message):
    if not condition:
        raise SystemExit(message)

require((stage / "generation.exit").read_text().strip() == "0", "Generator failed")
require(
    frozen_sha256
    == receipt["reference_receipt_sha256"]
    == prepared["frozen_receipt_sha256"],
    "Frozen receipt identity mismatch",
)
require(
    receipt["mode"] == "materialized"
    and receipt["recipe"] == prepared["frozen_recipe"] == frozen["recipe"]
    and receipt["files"] == frozen["files"],
    "Frozen recipe, file bytes or image records mismatch",
)
required_names = [f"focus_{index:03}.tif" for index in range(50)]
required_names += ["sharp_truth.tif", "depth_truth.tif"]
records = receipt["files"]
require([record["name"] for record in records] == required_names, "Unexpected file order")
require(
    len({record["file_sha256"] for record in records}) == 52
    and len({record["decoded_pixel_sha256"] for record in records}) == 52
    and all(
        record["bits_per_sample"] == 16
        and record["decoded_pixel_sha256"] == record["independent_zlib_pixel_sha256"]
        for record in records
    ),
    "Encoded/decoded TIFF identities or native bit depths differ from the freeze",
)
inputs = stage / "inputs"
require(stat.S_ISDIR(inputs.lstat().st_mode), "Input root is not an owned directory")
marker_path = inputs / "ownership.json"
require(stat.S_ISREG(marker_path.lstat().st_mode), "Missing regular owner marker")
marker = json.loads(marker_path.read_bytes())
require(
    marker == {
        "kind": receipt["dataset_kind"],
        "token": receipt["ownership_token"],
    }
    and receipt["cleanup"]["owned_output_directory"] == str(inputs)
    and receipt["cleanup"]["ownership_marker_retained"]
    and receipt["cleanup"]["remaining_tiff_count"] == 52,
    "Corpus ownership does not match the materialization receipt",
)
require(
    {entry.name for entry in inputs.iterdir()} == set(required_names) | {"ownership.json"},
    "Unexpected path retained in stage",
)
verified_bytes = 0
for record in records:
    info = (inputs / record["name"]).lstat()
    require(
        stat.S_ISREG(info.st_mode) and info.st_size == record["bytes"],
        f"File metadata mismatch for {record['name']}",
    )
    verified_bytes += info.st_size
require(
    verified_bytes == receipt["total_generated_tiff_bytes"] == prepared["expected_retained_bytes"],
    "Unexpected total size of staged corpus",
)
require(
    receipt["limits"]["full_set_preflight_bytes"] == prepared["full_set_preflight_bytes"]
    and receipt["limits"]["reserve_bytes"] == prepared["generator_reserve_bytes"]
    and receipt["free_disk_after_bytes"] >= prepared["generator_reserve_bytes"],
    "Free space fell below the generator reserve",
)
rss_pattern = r"Maximum resident set size \(kbytes\): (\d+)"
time_metadata = (stage / "generation-time.txt").read_text()
rss = int(re.search(rss_pattern, time_metadata).group(1))
package_path = Path(
    "/home/krishna/Documents/focus-stacking/artifacts/pancake-packages/linux-fb9c399"
)
package_file = package_path / prepared["candidate_package"]["file"]
package_receipt = package_path / "package-verification.json"
with package_file.open("rb") as stream:
    archive_sha256 = hashlib.file_digest(stream, "sha256").hexdigest()
require(
    archive_sha256 == prepared["candidate_package"]["sha256"]
    and package_file.stat().st_size == prepared["candidate_package"]["bytes"]
    and hashlib.sha256(package_receipt.read_bytes()).hexdigest()
    == prepared["package_verification_sha256"],
    "Packaged baseline archive or sealed verification receipt changed",
)
result = {
    "source_commit": prepared["source_commit"],
    "materialization_sha256": hashlib.sha256(receipt_bytes).hexdigest(),
    "frozen_receipt_sha256": frozen_sha256,
    "materialization": str(receipt_path),
    "input_root": str(inputs),
    "frozen_records_matched": 52,
    "focus_count": 50,
    "truth_count": 2,
    "verified_bytes": verified_bytes,
    "generation_seconds": receipt["elapsed_seconds"],
    "peak_generation_rss_kib": rss,
    "resource_policy": {
        "cpu_affinity": [14],
        "nice": 12,
        "io": "idle",
        "thread_limits": 1,
        **receipt["limits"],
    },
    "started_at": (stage / "generation-start.txt").read_text().strip(),
    "finished_at": (stage / "generation-end.txt").read_text().strip(),
    "benchmark_jobs": 0,
    "package_archive_verified_sha256": archive_sha256,
    "package_verification_sha256": prepared["package_verification_sha256"],
    "read_only_borrowers": prepared["planned_roles"],
    "cleanup": "after both declared borrowers explicitly release and root gives disposition",
}
(stage / "shared-stage.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))

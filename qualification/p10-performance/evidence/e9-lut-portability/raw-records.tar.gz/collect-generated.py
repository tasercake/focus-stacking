"""Hash only the generated inputs and exports, while retaining raw logs separately."""

from hashlib import sha256
import json
from pathlib import Path
import sys

base = Path(sys.argv[1])
records = {}
for lane in ("p5-host", "p5-vulkan"):
    for path in sorted((base / lane).rglob("*")):
        if path.is_file() and path.suffix in (".png", ".tif", ".tiff"):
            records[str(path.relative_to(base))] = {
                "bytes": path.stat().st_size,
                "sha256": sha256(path.read_bytes()).hexdigest(),
            }
print(json.dumps(records, indent=2))

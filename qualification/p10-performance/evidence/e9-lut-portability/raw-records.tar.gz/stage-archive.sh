#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/lut-portability"
evidence="$root/qualification/p10-performance/evidence/e9-lut-portability"
mkdir -p "$evidence"
python3 "$base/collect-generated.py" "$base" > "$base/generated-case-media.json"
cd "$base"
tar -czf "$evidence/raw-records.tar.gz"   --exclude='./conformance-venv' --exclude='./*-xdg' --exclude='./__pycache__'   --exclude='./probes/*/spectral-probe'   --exclude='./physical/*/home' --exclude='./physical/*/xdg-cache'   --exclude='./physical/*/tmp' --exclude='./physical/*/cuda-cache'   --exclude='*.png' --exclude='*.tif' --exclude='*.tiff'   --exclude='./README.prepared.md' .
cd "$evidence"
sha256sum raw-records.tar.gz > raw-records.sha256
sha256sum -c raw-records.sha256
tar -tzf raw-records.tar.gz > "$base/archive-inventory.txt"

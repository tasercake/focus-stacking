#!/usr/bin/env bash
set -euo pipefail
candidate=$(git rev-parse --show-toplevel)
stock=$(realpath "$candidate/../e9-lut-stock-portability")
base="$candidate/artifacts/lut-portability"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CUDARC_CUDA_VERSION=12050
export CARGO_TARGET_DIR="$candidate/pancake/target/lut-spectral-probes"
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
rustc +1.100.0 -Vv > "$base/rustc.txt"
sha256sum "$RUSTC_WRAPPER" > "$base/wrapper.sha256"
build() (
  arm=$1
  cd "$2"
  test "$(git rev-parse HEAD)" = "$3"
  test -z "$(git status --porcelain=v1)"
  temporary="$PWD/artifacts/physical_spectral_probe.rs"
  mkdir -p "$PWD/artifacts"
  cp "$base/probes/physical_$arm.rs" "$temporary"
  spectral=pancake/src/registration/spectral.rs
  trap 'git restore --worktree "$spectral"; unlink "$temporary"' EXIT
  printf '\n#[cfg(test)]\n#[path = "../../../artifacts/physical_spectral_probe.rs"]\nmod physical_spectral_probe;\n' >> "$spectral"
  out="$base/probes/$arm"
  mkdir -p "$out"
  git rev-parse HEAD 'HEAD^{tree}' > "$out/source-tree.txt"
  git diff -- "$spectral" > "$out/test-only.patch"
  sha256sum "$spectral" "$temporary" pancake/Cargo.lock > "$out/source-lock.sha256"
  cd pancake
  trap 'cd ..; git restore --worktree "$spectral"; unlink "$temporary"' EXIT
  cmd=(taskset -c 12,13 cargo +1.100.0 rustc --locked --offline --release --lib
    --crate-type bin -p pancake --features cubecl/cuda --message-format json -- --test)
  printf '%s\n' "$PWD" "CARGO_BUILD_JOBS=$CARGO_BUILD_JOBS CARGO_INCREMENTAL=$CARGO_INCREMENTAL CUDARC_CUDA_VERSION=$CUDARC_CUDA_VERSION CARGO_TARGET_DIR=$CARGO_TARGET_DIR RUSTC_WRAPPER=$RUSTC_WRAPPER" > "$out/build.command"
  printf '%q ' "${cmd[@]}" >> "$out/build.command"
  printf '\n' >> "$out/build.command"
  /usr/bin/time -v -o "$out/build-resource.txt" "${cmd[@]}" > "$out/build.jsonl" 2> "$out/build.log"
  exe=$(python3 - "$out/build.jsonl" <<'PY'
import json
from pathlib import Path
import sys
records = [json.loads(l) for l in Path(sys.argv[1]).read_text().splitlines()]
assert records[-1] == {"reason": "build-finished", "success": True}
[exe] = [
  file for item in records
  if item.get("reason") == "compiler-artifact" and item["target"]["name"] == "pancake"
  for file in item["filenames"] if file.endswith("/pancake")
]
print(exe)
PY
  )
  cp --reflink=auto "$exe" "$out/spectral-probe"
  sha256sum "$out/spectral-probe" > "$out/elf.sha256"
  readelf -n "$out/spectral-probe" > "$out/elf-notes.txt"
)
if [[ "${1-}" = --candidate-only ]]; then
  sha256sum -c "$base/probes/baseline/elf.sha256"
else
  build baseline "$stock" 75c3213a8e4c1d91298c4ba954102fd295eaa114
fi
build candidate "$candidate" a919045e8004e138df9fcc05650d9e87e50e0e36
for root in "$stock" "$candidate"; do
  test -z "$(git -C "$root" status --porcelain=v1)"
done

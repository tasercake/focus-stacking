/tmp/pancake-worktrees.t3paqgWM/e9-lut-portability/pancake
CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CUDARC_CUDA_VERSION=12050 CARGO_TARGET_DIR=/tmp/pancake-worktrees.t3paqgWM/e9-lut-portability/pancake/target/lut-spectral-probes RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
taskset -c 12\,13 cargo +1.100.0 rustc --locked --offline --release --lib --crate-type bin -p pancake --features cubecl/cuda --message-format json -- --test 

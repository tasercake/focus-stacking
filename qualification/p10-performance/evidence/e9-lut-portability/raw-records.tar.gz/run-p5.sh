#!/usr/bin/env bash
set -euo pipefail
base=$(realpath "$1")
lane=$2
case "$lane" in
  host)
    cases="$base/p5-cpu-cases.txt"
    unset PANCAKE_RUNTIME CUDA_VISIBLE_DEVICES VK_DRIVER_FILES VK_ICD_FILENAMES VK_ADD_DRIVER_FILES
    ;;
  vulkan)
    test -s "$base/physical-lease.txt"
    cases="$base/p5-vulkan-case.txt"
    export PANCAKE_RUNTIME=wgpu
    export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
    unset VK_ICD_FILENAMES VK_ADD_DRIVER_FILES
    ;;
  *)
    exit 2
    ;;
esac
test "$(git rev-parse HEAD)" = a919045e8004e138df9fcc05650d9e87e50e0e36
test -z "$(git status --porcelain=v1)"
sha256sum -c "$base/cli.sha256"
unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS LD_LIBRARY_PATH
export XDG_RUNTIME_DIR="$base/$lane-xdg"
mkdir -p -m 700 "$XDG_RUNTIME_DIR"
declare -a selection=()
while IFS= read -r case_id; do selection+=(--case "$case_id"); done < "$cases"
adapter=pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml
runner="$base/conformance-venv/bin/pancake-conformance"
cmd=(timeout --signal=TERM --kill-after=5s 420s taskset -c 12,13 "$runner"
  run --target "$adapter" --no-coverage "${selection[@]}" --output "$base/p5-$lane")
printf '%q ' "${cmd[@]}" > "$base/p5-$lane.command"
printf '\n' >> "$base/p5-$lane.command"
trap 'result=$?;
  { date -u +%FT%TZ; printf "exit=%s\n" "$result"; } > "$base/p5-$lane-terminal.txt"
' EXIT
date -u +%FT%TZ > "$base/p5-$lane-start.txt"
"${cmd[@]}" > "$base/p5-$lane.log" 2>&1
sha256sum -c "$base/cli.sha256"

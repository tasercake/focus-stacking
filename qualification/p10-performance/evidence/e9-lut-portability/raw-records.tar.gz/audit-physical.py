"""Require matched physical backend and report raw f32/decision parity by fixture."""

from hashlib import sha256
import json
import math
from pathlib import Path
from struct import iter_unpack
import sys

base = Path(sys.argv[1]) / "physical"
fixtures = ("flat", "identity", "shift")
report = {}
checks = []
for backend in ("wgpu-vulkan", "cuda"):
    left, right = [base / f"{backend}-{arm}" for arm in ("baseline", "candidate")]
    for record in (left, right):
        assert (record / "exit.txt").read_text().strip() == "0"
        assert "1 passed; 0 failed" in (record / "native.log").read_text()
    probes = [record.joinpath("physical-device.txt").read_text().strip() for record in (left, right)]
    assert probes[0] == probes[1]
    assert probes[0].startswith(f"runtime={backend} physical=true model=NVIDIA GeForce RTX 3090 pci=0000:01:00.0 fingerprint=")
    assert probes[0].endswith(" fallback=None")
    if backend == "cuda":
        assert " fingerprint=ptx_sm86 " in probes[0]
    semantics = [record.joinpath("semantics.txt").read_text().splitlines() for record in (left, right)]
    for decisions in semantics:
        assert len(decisions) == 6
        assert all(line.endswith(" launches=2,6,1") for line in decisions)
    checks.append(semantics[0] == semantics[1])
    results = {"device": probes[0], "semantics_match": semantics[0] == semantics[1], "surfaces": {}}
    for side in (64, 128):
        for kind in fixtures:
            name = f"{side}-{kind}.f32le"
            stock, lut = [record.joinpath(name).read_bytes() for record in (left, right)]
            assert len(stock) == len(lut) == side * side * 2 * 4
            assert all(
                math.isfinite(v) for raw in (stock, lut) for (v,) in iter_unpack("<f", raw)
            )
            changed = sum(a != b for a, b in zip(iter_unpack("<I", stock), iter_unpack("<I", lut), strict=True))
            max_abs = max(abs(a - b) for ((a,), (b,)) in zip(iter_unpack("<f", stock), iter_unpack("<f", lut), strict=True))
            checks.append(changed == 0)
            results["surfaces"][name] = {
                "channels": len(stock) // 4,
                "stock_sha256": sha256(stock).hexdigest(),
                "lut_sha256": sha256(lut).hexdigest(),
                "changed_bits_count": changed,
                "max_abs_difference": max_abs,
            }
    report[backend] = results
print(json.dumps(report, indent=2))
assert all(checks), "at least one physical surface or decision differed"

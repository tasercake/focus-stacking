#!/usr/bin/env bash
set -euo pipefail
base=$(realpath "$1")
root=$(git rev-parse --show-toplevel)
test -s "$base/physical-lease.txt"
test -z "$(git status --porcelain=v1)"
test "$(git rev-parse HEAD)" = a919045e8004e138df9fcc05650d9e87e50e0e36
sha256sum -c "$base/cli.sha256" "$base/probes/baseline/elf.sha256" "$base/probes/candidate/elf.sha256"

unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS PANCAKE_RUNTIME
unset VK_ICD_FILENAMES VK_ADD_DRIVER_FILES CUDA_VISIBLE_DEVICES LD_LIBRARY_PATH
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
export XDG_RUNTIME_DIR="$base/physical-xdg"
mkdir -m 700 "$XDG_RUNTIME_DIR" "$base/physical"
sha256sum "$VK_DRIVER_FILES" > "$base/physical/vulkan-icd.sha256"
trap 'result=$?;
  { date -u +%FT%TZ; printf "exit=%s\n" "$result"; } > "$base/physical/terminal.txt"
' EXIT
date -u +%FT%TZ > "$base/physical/start.txt"
nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$base/physical/nvidia.txt"
vulkaninfo --summary > "$base/physical/vulkaninfo.txt" 2> "$base/physical/vulkaninfo-stderr.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$base/physical/nvidia.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$base/physical/vulkaninfo.txt"
test "$(grep -c '^GPU[0-9]' "$base/physical/vulkaninfo.txt")" = 1

outcomes=0
run_probe() (
  runtime=$1
  arm=$2
  record="$base/physical/$runtime-$arm"
  mkdir "$record"
  exe="$base/probes/$arm/spectral-probe"
  export PANCAKE_SPECTRAL_PROBE_BACKEND="$runtime"
  export PANCAKE_SPECTRAL_PROBE_OUTPUT="$record"
  export HOME="$record/home"
  export XDG_CACHE_HOME="$record/xdg-cache"
  export TMPDIR="$record/tmp"
  export CUDA_CACHE_PATH="$record/cuda-cache"
  mkdir -m 700 "$HOME" "$XDG_CACHE_HOME" "$TMPDIR" "$CUDA_CACHE_PATH"
  if [[ "$runtime" = cuda ]]; then
    export CUDA_PATH=/usr/local/cuda-12.5
    export LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64
  fi
  cd "$record"
  cmd=(timeout --signal=TERM --kill-after=5s 80s taskset -c 12,13 "$exe" --exact registration::spectral::physical_spectral_probe::registration_physical_surface_and_counts --test-threads 1 --nocapture)
  printf 'cwd=%q\nbackend=%q\nCUDA_PATH=%q\nLD_LIBRARY_PATH=%q\nVK_DRIVER_FILES=%q\nHOME=%q\nXDG_CACHE_HOME=%q\nTMPDIR=%q\nCUDA_CACHE_PATH=%q\noutput=%q\n' "$PWD" "$runtime" "${CUDA_PATH-}" "${LD_LIBRARY_PATH-}" "$VK_DRIVER_FILES" "$HOME" "$XDG_CACHE_HOME" "$TMPDIR" "$CUDA_CACHE_PATH" "$PANCAKE_SPECTRAL_PROBE_OUTPUT" > "$record/command"
  printf '%q ' "${cmd[@]}" >> "$record/command"
  printf '\n' >> "$record/command"
  if "${cmd[@]}" > "$record/native.log" 2>&1; then
    printf '0\n' > "$record/exit.txt"
  else
    status=$?
    printf '%s\n' "$status" > "$record/exit.txt"
    exit "$status"
  fi
  grep -qF '1 passed; 0 failed' "$record/native.log"
)
if ! bash "$base/run-p5.sh" "$base" vulkan > "$base/physical/p5-driver.log" 2>&1; then
  outcomes=1
fi
for backend in wgpu-vulkan cuda; do
  for arm in baseline candidate; do
    if ! run_probe "$backend" "$arm"; then
      outcomes=1
    fi
  done
done
cd "$root"
sha256sum -c "$base/cli.sha256" "$base/probes/baseline/elf.sha256" "$base/probes/candidate/elf.sha256"
test -z "$(git status --porcelain=v1)"
exit "$outcomes"

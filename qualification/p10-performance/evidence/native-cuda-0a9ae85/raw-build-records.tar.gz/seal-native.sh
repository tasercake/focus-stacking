#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
cd "$root"
stage="$root/artifacts/native-cuda-0a9ae85"
source_commit=0a9ae85b88519a795e3b6ba90860c3b3e664bcaa
binary="$stage/target/release/pancake-cli"
stable=/home/krishna/Documents/focus-stacking/artifacts/pancake-linux-native/0a9ae85/pancake-cli
test "$(git rev-parse HEAD)" = "$source_commit"
test -z "$(git status --porcelain)"
grep -Fxq 'exit=0' "$stage/build-status.txt"
grep -Fq 'Finished `release`' "$stage/build.log"
test ! -e "$stable" && test ! -e "$stable.staging"
readelf -n "$binary" > "$stage/elf-notes.txt"
readelf -d "$binary" > "$stage/elf-dynamic.txt"
nm --defined-only --demangle "$binary" | awk '/cubecl_cuda/ { cuda++ } /[Nn][Vv][Pp][Tt][Xx]/ { nvptx++ } END { print "CUDA native symbols:", cuda; print "NVPTX symbols:", nvptx; exit !(cuda > 0 && nvptx > 0) }' > "$stage/link-witness.txt"
cat > "$stage/runtime-libraries.sha256" <<'EOF'
fb37b3f5b0ed35bf6b24f31f1277d30f2fadb08f8562e90d1e6ce208817fc8ed  /usr/local/cuda-12.5/lib64/libnvrtc.so.12.5.40
1237ef425d116b1faee57d924e099b877fd6548ce3b367e50a7e1ef912eeb08c  /usr/local/cuda-12.5/lib64/libnvrtc-builtins.so.12.5.40
dcdf334aeb177c95b3385b797c9b871d03a287895713c6d107f79096b0985aa9  /usr/lib/x86_64-linux-gnu/libcuda.so.580.178.04
8c593e48547f85458b6bfbed93a2e6b05484644ccc6b429bb0d8424e06a68b6c  /usr/local/cuda-12.5/nvvm/libdevice/libdevice.10.bc
EOF
sha256sum --check "$stage/runtime-libraries.sha256" > "$stage/runtime-libraries-verify.txt"
mkdir -p "${stable%/*}"
cp --reflink=auto "$binary" "$stable.staging"
chmod 0555 "$stable.staging"
mv -n "$stable.staging" "$stable"
cmp "$binary" "$stable"
sha256sum "$stable" > "${stable%/*}/pancake-cli.sha256"
cp "${stable%/*}/pancake-cli.sha256" "$stage/native-binary.sha256"
RUSTC_WRAPPER= RUSTC_WORKSPACE_WRAPPER= cargo +1.100.0 tree --manifest-path "$root/pancake/Cargo.toml" --locked --offline -p pancake -p pancake-cli --features cubecl/cuda -e features > "$stage/native-feature-tree.txt"
rg -m 1 'cubecl-cuda v0\.11\.4' "$stage/native-feature-tree.txt"
cat "$stage/link-witness.txt" "$stage/native-binary.sha256"

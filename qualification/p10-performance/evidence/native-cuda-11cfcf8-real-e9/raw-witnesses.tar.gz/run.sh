#!/usr/bin/env bash
# Preflight touches no photos. Run requires the explicit exclusive RTX handoff.
set -euo pipefail
source_root=$(git rev-parse --show-toplevel)
record="$source_root/artifacts/native-e9-11cfcf8"
workspace=/home/krishna/Documents/focus-stacking
loan=/tmp/pancake-worktrees.t3paqgWM/e9-cuda-integrated-replay/artifacts/e9-cuda-integrated-replay/input-stage
retained="$workspace/artifacts/pancake-linux-native/11cfcf8"
qual="$workspace/pancake-conformance/.venv/bin/python"
mode=$1
case "$mode" in
  preflight) output=() ;;
  run) output=(--output "$record/witnesses") ;;
  *) exit 2 ;;
esac
cd "$source_root"
export PYTHONPATH="$source_root/qualification/p10-performance:$source_root/pancake-conformance/src"
export PATH=/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8 PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
unset LD_PRELOAD LD_LIBRARY_PATH VK_DRIVER_FILES VK_ICD_FILENAMES OCL_ICD_VENDORS TZ
cmd=(
  timeout --signal=TERM --kill-after=5s 90s taskset --cpu-list 10,11
  "$qual" "$record/witness.py" "$mode" --binary "$retained/pancake-cli"
  --receipt "$retained/build-receipt.json" --input-root "$loan/input"
  --input-receipt "$loan/receipt.json" "${output[@]}"
)
printf '%q ' "${cmd[@]}" > "$record/$mode.command"
printf '\n' >> "$record/$mode.command"
status=0
"${cmd[@]}" > "$record/$mode.log" 2> "$record/$mode.stderr" || status=$?
printf '%s\n' "$status" > "$record/$mode.exit"
date -u +%FT%T.%NZ > "$record/$mode.terminal"
cat "$record/$mode.log" "$record/$mode.stderr"
exit "$status"

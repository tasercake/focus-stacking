#!/usr/bin/env bash
# Archive verified receipts only. The shared corpus remains owned by this stage.
set -euo pipefail
stage=$(cd "$(dirname "$0")" && pwd)
tree=$(cd "$stage/../.." && pwd)
cd "$tree"
source_commit=$(jq -r '.source_commit' "$stage/shared-stage.json")
test "$(git rev-parse HEAD)" = "$source_commit"
evidence=qualification/p10-performance/evidence/t50-shared-c1e2cac
mkdir "$evidence"
cp "$stage/prepared-stage.json" "$stage/shared-stage.json" "$evidence/"
gzip -nc "$stage/materialization.json" > "$evidence/materialization.json.gz"
cp /home/krishna/Documents/focus-stacking/artifacts/pancake-packages/linux-c1e2cac/package-verification.json     "$stage/package-verification.json"
test "$(sha256sum "$stage/package-verification.json" | cut -d ' ' -f 1)" =     "$(jq -r '.package_verification_sha256' "$stage/shared-stage.json")"
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner     -C "$stage" -czf "$evidence/raw-stage.tar.gz"     materialize.sh verify-stage.py seal-stage.sh package-verification.json     generation-command.txt generation-start.txt generation-end.txt generation-time.txt     generation.log generation.exit disk-before.txt disk-after.txt     memory-before.txt memory-after.txt inputs/ownership.json
python3 - "$stage" "$evidence" <<'PY'
import json
import sys
from pathlib import Path

stage = Path(sys.argv[1])
evidence = Path(sys.argv[2])
result = json.loads((stage / "shared-stage.json").read_bytes())
disk_before = int((stage / "disk-before.txt").read_text().splitlines()[1].split()[-3])
disk_after = int((stage / "disk-after.txt").read_text().splitlines()[1].split()[-3])
memory_before = int((stage / "memory-before.txt").read_text().splitlines()[1].split()[1])
memory_after = int((stage / "memory-after.txt").read_text().splitlines()[1].split()[1])
start, end = (result[key][11:19] for key in ("started_at", "finished_at"))

(evidence / "README.md").write_text(f"""# Shared frozen T50 stage for the c1e2cac viewer comparison

The materializer ran from the clean `{result['source_commit']}`
checkout. The frozen generator, scalar oracle and performance targets
retain their recorded hashes. The sealed Debian package and its verification
receipt also matched their recorded hashes.

All 50 ordered 6000×4000 RGB16 focus TIFFs and both native 16-bit truth TIFFs
matched the frozen encoded hashes and both independent decoded pixel hashes.
The full staged set totals {result['verified_bytes']:,} bytes. The materialization
receipt SHA-256 is
`{result['materialization_sha256']}`.
The viewer receives the 50 focus TIFFs as its input stack. Both truth TIFFs
remain separate.

Generation took {result['generation_seconds']:.3f} seconds with peak RSS of
{result['peak_generation_rss_kib']:,} KiB. The owner held the shared performance
lock from {start} to {end} SGT on 2026-11-18 and limited generation to CPU14,
nice +12, idle I/O, and one numerical thread and decode worker. The generator
reserved 15 GiB. Available disk space was {disk_before:,} bytes at entry and
{disk_after:,} bytes at exit. Available memory was {memory_before:,} KiB at
entry and {memory_after:,} KiB at exit. This run generated and verified
input data. The packaged viewer was identified by archive and sealed receipt
hashes. Application and device measurements are tracked by their consumers.

Both the exact packaged baseline and the isolated bounded-poll GUI candidate
are planned consumers of this same immutable stage. The owner removes the
corpus after both readers release and the coordinator clears cleanup.

[Stage receipt](shared-stage.json) · [Preflight](prepared-stage.json) ·
[Complete encoded and decoded records](materialization.json.gz) ·
[Exact command, resource logs, package verification and ownership](raw-stage.tar.gz)
""")
PY
cd "$evidence"
sha256sum README.md prepared-stage.json shared-stage.json materialization.json.gz raw-stage.tar.gz > SHA256SUMS
sha256sum -c SHA256SUMS
tar -tzf raw-stage.tar.gz
test "$(gzip -dc materialization.json.gz | sha256sum | cut -d ' ' -f 1)" =     "$(jq -r '.materialization_sha256' shared-stage.json)"

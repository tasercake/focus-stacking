"""Run exactly one leased, unscored T50 Hybrid GPU pair through the frozen helpers."""

import argparse
from contextlib import ExitStack
import json
import os
from pathlib import Path
import runpy
import subprocess
import time

import p10
from protocol import Campaign, corpus, pinned_json, pixel_metrics, sha256, verify_frames
from resources import NvidiaMemory

CANDIDATE = "8694b555666a1ddf4051e2839bbced4bcc625859"
REFERENCE = "ab7a92708269c01c6094729f6cdfaf1415677364"
CLI = "e5fa8d2cb31a55071c999a83e35b4c3d31d6c569717b7baca328c16ea7ed4b6f"
DEB = "7dbc969e1813bc62aa4df206bb77982e3f7705298f753e12b7a493ae89ce3784"
LOCK = "f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc"
GPU = "GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac"
BOUNDS = (4000, 6000, 3)


def package_identity(options, identities):
    """Bind the staged executable to the existing combined Debian package."""
    package = options.package.resolve(strict=True)
    proof = json.loads(options.package_receipt.read_text())
    candidate = identities["candidate"]
    if (
        package.stat().st_size != 69_494_350
        or sha256(package) != DEB
        or proof["source_commit"] != CANDIDATE
        or proof["archive"]["sha256"] != DEB
        or proof["binaries"]["pancake-cli"]["sha256"] != CLI
        or proof["cargo_lock_sha256"] != LOCK
        or candidate["commit"] != CANDIDATE
        or candidate["binary_sha256"] != CLI
        or candidate["lock_sha256"] != LOCK
        or identities["reference"]["commit"] != REFERENCE
    ):
        raise ValueError("combined Debian or pinned reference identity does not match")
    return {"path": str(package), "sha256": DEB, "verification_receipt": proof}


def warning_summary(log):
    """Count the software's actual alignment warning strings without weighting time."""
    counts = {}
    if not log.is_file():
        return counts
    for line in log.read_text(errors="replace").splitlines():
        for marker in ("GPU alignment help failed (", "GPU alignment help unavailable ("):
            if marker in line:
                message = marker + line.split(marker, 1)[1].strip()
                counts[message] = counts.get(message, 0) + 1
                break
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("input-root", "build-receipt", "output", "package", "package-receipt", "quiet-receipt"):
        parser.add_argument(f"--{key}", type=Path, required=True)
    parser.add_argument("--truth-review", type=Path)
    parser.add_argument("--rss-sampler-cpu", type=int)
    args = parser.parse_args()
    args.profile = "T50.hybrid.gpu"
    args.runtime = "wgpu-vulkan"
    args.gpu_uuid = GPU
    args.reference_gpu_index = args.candidate_gpu_index = 0
    args.cuda_library_path = None
    args.threads = len(os.sched_getaffinity(0))
    args.timeout = 900
    if args.rss_sampler_cpu is not None and (
        args.rss_sampler_cpu < 0 or args.rss_sampler_cpu in os.sched_getaffinity(0)
    ):
        raise ValueError("RSS sampler CPU must be outside the common job affinity")
    quiet_digest = sha256(args.quiet_receipt)
    output = args.output.resolve()
    output.mkdir()
    campaign = Campaign.load(p10.TARGETS_PATH)
    profile = next(item for item in campaign.profiles("gpu") if item.key == args.profile)
    report = {
        "scope": "One reference and one candidate diagnostic, outside frozen timing qualification",
        "profile": args.profile,
        "settings": profile.options,
        "quiet_receipt_sha256": quiet_digest,
        "protocol_sha256": sha256(p10.TARGETS_PATH),
        "runner_sha256": sha256(Path(p10.__file__)),
        "diagnostic_sha256": sha256(Path(__file__)),
        "started_unix_ns": time.time_ns(),
        "jobs": {},
    }
    try:
        with p10._campaign_lock(), ExitStack() as stack:
            specs, identities = p10._prepared_targets(args, campaign)
            report["targets"] = identities
            report["package"] = package_identity(args, identities)
            records, corpus_source = corpus(p10.ROOT, campaign, "T50")
            receipt = pinned_json(Path(corpus_source["path"]), corpus_source["sha256"])
            all_records = [
                {**row, "path": row["name"], "sha256": row["file_sha256"]}
                for row in receipt["files"]
            ]
            original = verify_frames(args.input_root, all_records, 52)
            frames = [args.input_root.resolve() / row["path"] for row in records]
            if len(frames) != 50 or frames != original[:50] or frames != sorted(frames):
                raise ValueError("input order differs from the authenticated native T50 order")
            report["corpus"] = corpus_source
            try:
                hardware = p10._hardware(GPU)
                hardware["reference_opencl"] = p10._opencl_preflight(
                    args, specs["reference"], identities["reference"], hardware["gpu"], output,
                )
                report["hardware"] = hardware
                gpu = NvidiaMemory(GPU)
                stack.callback(gpu.close)
                exports = {}
                for arm in ("reference", "candidate"):
                    sample, path = p10._run_sample(
                        profile, ("diagnostic", 1, arm), arm, specs[arm],
                        identities[arm], args, frames, BOUNDS, output, gpu,
                    )
                    report["jobs"][arm] = sample
                    case = output / "diagnostic-01" / arm
                    sample["gpu_alignment_helper_warnings"] = warning_summary(case / "stderr.txt")
                    if not sample["valid"]:
                        raise ValueError(f"{arm} diagnostic invalid: {sample['invalid_reason']}")
                    sample["backend_by_stage"] = sample["completion"].get("actual_backend_by_stage")
                    exports[arm] = path
                    p10._write(output / "pair-report.json", report)
                report["decoded_pair"] = pixel_metrics(exports["reference"], exports["candidate"], BOUNDS)
                if args.truth_review:
                    review = runpy.run_path(str(args.truth_review))
                    for arm, path in exports.items():
                        try:
                            sample = report["jobs"][arm]
                            sample["geometry"] = review["geometry"](sample["completion"], frames)
                            sample["truth_review"] = review["generated_oracle"](path, args.input_root, campaign)
                        except ValueError as error:
                            report.setdefault("truth_review_errors", {})[arm] = str(error)
                    report["truth_review_sha256"] = sha256(args.truth_review)
            finally:
                report["all_52_unchanged"] = verify_frames(args.input_root, all_records, 52) == original
                report["target_identities_unchanged"] = p10._prepared_targets(args, campaign)[1] == identities
            if not report["all_52_unchanged"] or not report["target_identities_unchanged"]:
                raise ValueError("post-run source or target authentication did not match")
        report["status"] = "functional_pair_completed"
        return 0
    except (KeyError, OSError, RuntimeError, ValueError, subprocess.CalledProcessError) as error:
        report.update(status="failed", failure=str(error))
        raise
    finally:
        report["finished_unix_ns"] = time.time_ns()
        p10._write(output / "pair-report.json", report)


if __name__ == "__main__":
    raise SystemExit(main())

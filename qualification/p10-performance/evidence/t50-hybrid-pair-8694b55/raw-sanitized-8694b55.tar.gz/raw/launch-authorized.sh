#!/usr/bin/env bash
# Invoke only after the full viewer run ends and the coordinator grants the exclusive GPU.
set -euo pipefail
release=$(git rev-parse --show-toplevel)
scratch="$release/artifacts/t50-pair-8694"
shared=/tmp/pancake-worktrees.t3paqgWM/t50-shared-8694b55/artifacts/p10-t50-shared-002
package=/home/krishna/Documents/focus-stacking/artifacts/pancake-packages/linux-8694b55/pancake_0.1.0_amd64.deb
ref="$release/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference"
[[ $(git rev-parse HEAD) == 8694b555666a1ddf4051e2839bbced4bcc625859 ]]
[[ -z $(git status --porcelain=v1) ]]
test -s "$scratch/gpu-quiet-lease.txt"
test ! -e "$scratch/diagnostic-pair"
printf '%s  %s\n' 317f4b0c9be5837cd7082227bf700ee232e7e995471ee44be8488cbf3511603c "$shared/materialization.json" | sha256sum -c
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$release/pancake-conformance/src:$release/qualification/p10-performance"
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
exec env -u DISPLAY -u WAYLAND_DISPLAY systemd-run --user --scope --quiet \
  --unit=pancake-t50-8694-hybrid-pair -p MemoryMax=28G -p MemorySwapMax=0 \
  "$ref/.venv/bin/python" "$scratch/diagnostic-pair-8694.py" \
  --input-root "$shared/inputs" --package "$package" \
  --package-receipt "$scratch/package-receipt.json" --build-receipt "$scratch/build-receipt.json" \
  --quiet-receipt "$scratch/gpu-quiet-lease.txt" --output "$scratch/diagnostic-pair" \
  --truth-review "$scratch/truth-review.py"

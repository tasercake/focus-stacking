"""Probe resource collection with identical original E9 completed jobs."""
import argparse
import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path

from p10 import CANDIDATE, ROOT, TARGETS_PATH, _environment, _hardware, _write
from pancake_conformance.target import TargetSpec
from protocol import Campaign, corpus, sha256, verify_frames, verify_output
from resources import NvidiaMemory, measure


def previous_sampler(module_path):
    spec = importlib.util.spec_from_file_location("previous_resources", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.measure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for label in ("binary", "input-root", "output"):
        parser.add_argument("--" + label, type=Path, required=True)
    parser.add_argument("--gpu-uuid")
    args = parser.parse_args()
    output = args.output.resolve(strict=True)
    binary = args.binary.resolve(strict=True)
    campaign = Campaign.load(TARGETS_PATH)
    device = "gpu" if args.gpu_uuid else "cpu"
    profiles = {item.key: item for item in campaign.profiles(device)}
    profile = profiles[f"E9.exposure_fusion.{device}"]
    settings = profile.options | ({"gpu_id": 0} if args.gpu_uuid else {})
    target = TargetSpec.load(CANDIDATE)
    rows, source = corpus(ROOT, campaign, "E9")
    paths = verify_frames(args.input_root, rows, 9)
    receipt = {
        "scope": "same immutable application and flags; sampler diagnostic, no performance-gate credit",
        "binary_sha256": sha256(binary), "input_manifest": source, "settings": settings,
        "frozen_targets_sha256": sha256(TARGETS_PATH), "hardware": _hardware(args.gpu_uuid),
        "previous_sampler_sha256": sha256(output / "previous_resources.py"),
        "candidate_sampler_sha256": sha256(Path(sys.modules[measure.__module__].__file__)),
        "samples": [],
    }
    gpu = NvidiaMemory(args.gpu_uuid) if args.gpu_uuid else None
    try:
        collectors = [("previous", previous_sampler(output / "previous_resources.py")),
                      ("current-1", measure), ("current-2", measure)]
        for name, collect in collectors:
            case = output / name
            case.mkdir()
            export = case / "complete.tif"
            env = _environment(target, case / "cache", case, len(os.sched_getaffinity(0)),
                               args.gpu_uuid, "wgpu" if args.gpu_uuid else None, True)
            argv = [str(binary), *target.stack_arguments(paths, export, settings)]
            try:
                sample = collect(argv, cwd=target.root, env=env, directory=case, timeout=90, gpu=gpu)
                sample.update({"sampler": name, "argv": argv, "env": env})
                if sample["returncode"] == 0:
                    sample["output"] = verify_output(export, (337, 510, 3))
                receipt["samples"].append(sample)
            finally:
                export.unlink(missing_ok=True)
                shutil.rmtree(case / "cache")
    finally:
        if gpu is not None:
            gpu.close()
        receipt["inputs_unchanged"] = paths == verify_frames(args.input_root, rows, 9)
        _write(output / "report.json", receipt)


if __name__ == "__main__":
    main()

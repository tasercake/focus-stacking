#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/e9-warm-gpu"
stock=/home/krishna/Documents/focus-stacking/artifacts/pancake-linux-native/12f2151/pancake-cli
reference_python=/home/krishna/Documents/focus-stacking/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin/python
graph_processes=(cargo rustc ld.lld pancake-cli pancake-gui)
process_names=$(IFS=,; printf '%s' "${graph_processes[*]}")
processes() {
    ps -C "$process_names" -o pid,state,time,etime,comm > "$1" || test "$?" = 1
}

processes "$record/comparison-processes-before.txt"
if awk 'NR > 1 && $2 !~ /^[TZ]/ {found=1} END {exit(found ? 0 : 1)}' "$record/comparison-processes-before.txt"; then
    cat "$record/comparison-processes-before.txt"
    exit 1
fi
sha256sum --check "$record/stock-cli.sha256"
sha256sum --check "$record/candidate-binary.sha256"
date -Iseconds > "$record/comparison-start.txt"
status=0
timeout --signal=TERM --kill-after=5s 180s "$reference_python" "$record/measure-e9.py" \
    "$stock" "$record/candidate-pancake-cli" \
    "$record/comparison-run" compare > "$record/comparison.log" 2>&1 || status=$?
date -Iseconds > "$record/comparison-finish.txt"
printf '%s\n' "$status" > "$record/comparison.status"
processes "$record/comparison-processes-after.txt"
cat "$record/comparison.log"
exit "$status"

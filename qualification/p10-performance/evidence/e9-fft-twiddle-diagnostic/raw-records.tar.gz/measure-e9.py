"""Run paired Pancake E9 phase diagnostics, with the frozen CUDA workload."""

from collections import defaultdict
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

import tifffile

base = Path(__file__).resolve().parent
materialized = json.loads((base / "materialized-e9.json").read_text())
reference = json.loads((base / "historical-cuda-sample.json").read_text())
input_root = Path(materialized["input_root"])
inputs = [input_root / frame["path"] for frame in materialized["ordered_inputs"]]
output = Path(sys.argv[3]).resolve()
output.mkdir()
mode = sys.argv[4] if len(sys.argv) > 4 else "phase"
assert mode in ("phase", "nsys", "compare")
variant = "twiddles" if mode == "compare" else "trace"
variants = {"stock": Path(sys.argv[1]).resolve(), variant: Path(sys.argv[2]).resolve()}
profile_only = mode == "nsys"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def verify_inputs():
    for path, expected in zip(inputs, materialized["ordered_inputs"], strict=True):
        assert path.stat().st_size == expected["bytes"]
        assert digest(path) == expected["sha256"]


def thermal_state():
    return subprocess.check_output(
        ["nvidia-smi", "--query-gpu=name,uuid,pci.bus_id,driver_version,temperature.gpu,pstate",
         "--format=csv,noheader"],
        text=True,
    ).splitlines()


def phase_totals(path):
    records = defaultdict(list)
    lines = path.read_text().splitlines()
    assert lines[0] == "# dropped_records=0"
    for line in lines[2:]:
        frame, stage, start, elapsed, size = line.split("\t")
        records[stage].append(int(elapsed))
    return {stage: {"count": len(times), "total_ns": sum(times)} for stage, times in records.items()}


def launch(kind, iteration, variant, binary, binary_hash):
    job = output / f"{kind}-{iteration:02d}-{variant}"
    job.mkdir()
    image = job / "complete.tif"
    event_path = job / "events.jsonl"
    phase_path = job / "phase.tsv"
    cache = output / "cache" / variant
    historical_flags = reference["argv"][reference["argv"].index("--output") + 2:]
    argv = [str(binary), "--input", *map(str, inputs), "--output", str(image), *historical_flags]
    env = dict(reference["environment"])
    env["PATH"] = os.environ["PATH"]
    for key, relative in {
        "HOME": "home", "XDG_CACHE_HOME": "cache", "XDG_CONFIG_HOME": "config",
        "TMPDIR": "tmp", "CUDA_CACHE_PATH": "cuda", "__GL_SHADER_DISK_CACHE_PATH": "nvidia",
        "MESA_SHADER_CACHE_DIR": "mesa", "NUMBA_CACHE_DIR": "numba",
        "PANCAKE_STATE_DIR": "home", "PANCAKE_COMPUTE_CACHE_DIR": "home/device-cache",
    }.items():
        directory = cache / relative
        directory.mkdir(exist_ok=True, parents=True)
        env[key] = str(directory)
    env["CONFORMANCE_EVENTS_PATH"] = str(event_path)
    if variant == "trace":
        env["PANCAKE_T50_PHASE_TRACE"] = str(phase_path)
    if profile_only:
        argv = [
            "/usr/local/cuda-12.5/bin/nsys", "profile", "--trace=cuda,nvtx",
            "--sample=none", "--cpuctxsw=none", "--export=sqlite", "--output", str(job / "cuda"),
            *argv,
        ]
    launch_info = {"argv": argv, "environment": env, "binary_sha256": binary_hash,
                   "cpu_affinity": sorted(os.sched_getaffinity(0))}
    (job / "launch.json").write_text(json.dumps(launch_info, indent=2) + "\n")

    with (job / "stdout.txt").open("wb") as stdout, (job / "stderr.txt").open("wb") as stderr:
        start = time.monotonic_ns()
        with subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr) as process:
            _, status, usage = os.wait4(process.pid, 0)
            elapsed = time.monotonic_ns() - start
            process.returncode = os.waitstatus_to_exitcode(status)
    assert process.returncode == 0, (process.returncode, (job / "stderr.txt").read_text())
    event, = map(json.loads, event_path.read_text().splitlines())
    assert event["event"] == "stack_complete" and event["completed"] is True
    assert event["actual_backend"] == "gpu" and event["physical_gpu"] is True
    assert event["runtime"] == "cuda" and event["fallback_reason"] is None
    assert event["device"] == "NVIDIA GeForce RTX 3090"
    assert event["device_pci_address"] == "0000:01:00.0"
    assert event["device_fingerprint"] == "ptx_sm86"
    assert len(event["sequential_transforms"]) == len(inputs)
    assert all(matrix == [[1., 0., 0.], [0., 1., 0.]] for matrix in event["sequential_transforms"])
    pixels = tifffile.imread(image)
    assert list(pixels.shape) == reference["output"]["shape"] and str(pixels.dtype) == "uint16"
    assert sha256(pixels.tobytes()).hexdigest() == reference["output"]["pixel_sha256"]
    encoded = digest(image)
    assert encoded == reference["output"]["sha256"]
    phases = phase_totals(phase_path) if variant == "trace" else {}
    record = {"kind": kind, "iteration": iteration, "variant": variant, "elapsed_ns": elapsed,
              "encoded_sha256": encoded, "phases": phases,
              "user_seconds": usage.ru_utime, "system_seconds": usage.ru_stime}
    (job / "sample.json").write_text(json.dumps(record, indent=2) + "\n")
    image.unlink()
    return record


verify_inputs()
before = thermal_state()
samples = []
binary_hashes = {variant: digest(binary) for variant, binary in variants.items()}
if profile_only:
    shutil.copytree(base / "phase-run/cache/trace", output / "cache/trace")
    sample = launch("compiler-witness", 0, "trace", variants["trace"], binary_hashes["trace"])
    verify_inputs()
    (output / "profile-session.json").write_text(json.dumps({
        "gpu_before": before, "gpu_after": thermal_state(), "sample": sample,
    }, indent=2) + "\n")
    sys.exit(0)
for index in range(7):
    variant_names = list(variants)
    if index % 2:
        variant_names.reverse()
    kind = "warmup" if index < 2 else "diagnostic"
    for variant in variant_names:
        samples.append(launch(kind, index, variant, variants[variant], binary_hashes[variant]))
verify_inputs()
after = thermal_state()
timed = [sample for sample in samples if sample["kind"] == "diagnostic"]
stage_rows = defaultdict(list)
for sample in timed:
    for stage, value in sample["phases"].items():
        stage_rows[stage].append(value["total_ns"])
summary = {
    "scope": "Fresh-process diagnostic comparison between Pancake executables",
    "gpu_before": before,
    "gpu_after": after,
    "binary_sha256": binary_hashes,
    "medians_ns": {variant: statistics.median(s["elapsed_ns"] for s in timed if s["variant"] == variant)
                   for variant in variants},
    "trace_median_stage_ns": {stage: statistics.median(durations) for stage, durations in stage_rows.items()},
    "samples": samples,
}
(output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({key: val for key, val in summary.items() if key != "samples"}, indent=2))

#!/usr/bin/env bash
# Start after the coordinator grants the stage owner the generation slot.
set -euo pipefail
stage=$(cd "$(dirname "$0")" && pwd)
release_tree=$(cd "$stage/../.." && pwd)
cd "$release_tree"
cpu="${1:-6}"
test "$(git rev-parse HEAD)" = e81079dee4078d7a1149da0f5950aab8c89f8d44
test -z "$(git status --porcelain)"
test ! -e "$stage/inputs"
test ! -e "$stage/materialization.json"
test ! -e "$stage/generation.exit"
generator=/home/krishna/Documents/focus-stacking/pancake-conformance/.venv/bin/python
frozen=qualification/t50-generated/evidence/native-t50-receipt.json
printf '%s  %s\n' \
    8881a4968bb95f5a911b040a6ebc9635a9cbdc5a759ac0443605de33f700849c "$frozen" \
    58bb68533311c48696a3a844d80eef2f37a3c1f39649305948c838b7002663dc pancake/docs/performance-targets.json | sha256sum -c -
df -B1 "$stage" | tee "$stage/disk-before.txt"
awk '/^(MemTotal|MemAvailable|SwapFree):/{print}' /proc/meminfo | tee "$stage/memory-before.txt"
available=$(df -B1 --output=avail "$stage" | awk 'NR==2 { print $1 }')
(( available >= 25769803776 ))
awk '$1=="MemAvailable:" { enough=$2>=25165824 } END { exit !enough }' /proc/meminfo
lock="$(git rev-parse --path-format=absolute --git-common-dir)/pancake-performance.lock"
execution=(
    flock -n "$lock" taskset -c "$cpu" nice -n 12 ionice -c 3
    env -u DISPLAY -u WAYLAND_DISPLAY OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=1
    OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
    /usr/bin/time -v -o "$stage/generation-time.txt" "$generator" -u
    qualification/t50-generated/t50_generated.py --materialize-from "$frozen"
    --reserve-gib 15 --output "$stage/inputs" --receipt "$stage/materialization.json"
)
printf '%q ' "${execution[@]}" > "$stage/generation-command.txt"
printf '\n' >> "$stage/generation-command.txt"
TZ=Asia/Singapore date --iso-8601=seconds > "$stage/generation-start.txt"
set +e
"${execution[@]}" 2>&1 | tee "$stage/generation.log"
status=${PIPESTATUS[0]}
set -e
printf '%s\n' "$status" > "$stage/generation.exit"
TZ=Asia/Singapore date --iso-8601=seconds > "$stage/generation-end.txt"
df -B1 "$stage" > "$stage/disk-after.txt"
awk '/^(MemTotal|MemAvailable|SwapFree):/{print}' /proc/meminfo > "$stage/memory-after.txt"
exit "$status"

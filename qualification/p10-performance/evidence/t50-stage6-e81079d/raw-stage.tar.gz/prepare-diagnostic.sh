#!/usr/bin/env bash
set -euo pipefail
stage=$(cd "$(dirname "$0")" && pwd)
tree=$(cd "$stage/../.." && pwd)
main=/home/krishna/Documents/focus-stacking
pinned_ref=ab7a92708269c01c6094729f6cdfaf1415677364
package_root="$main/artifacts/pancake-packages/linux-e81079d"
archive="$package_root/pancake_0.1.0_amd64.deb"
proof="$package_root/package-verification.json"
ref="$tree/submodules/ChimpStackr"
adapter="$tree/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference"
cli="$tree/pancake/target/release/pancake-cli"
pinned_cli=9630572be5e637c38c604f2fcd6d7a44e31e171a5ccf17dadb1f59ba345c24f0
test "$(git -C "$tree" rev-parse HEAD)" = e81079dee4078d7a1149da0f5950aab8c89f8d44
test ! -e "$cli"
test ! -e "$adapter/.venv"
printf '%s  %s\n' \
    8ed6e70d7552140c0257520a07ac2b9fc5f97ff82a5fb3126864df821df4507e "$archive" \
    f0a6402c9d79038ef86876f91a0ae36fa526e97332746b13ee8a8ba242ea1fae "$proof" \
    fda57ac5eea063aebcc278eb57a90228e6da32fe2d8f67d7025ac367f4b51036 "$adapter/uv.lock" | sha256sum -c -
mkdir -p "$(dirname "$cli")"
dpkg-deb --fsys-tarfile "$archive" | tar -xOf - ./usr/bin/pancake-cli > "$cli"
printf '%s  %s\n' "$pinned_cli" "$cli" | sha256sum -c -
chmod 0555 "$cli"
git clone --local --no-checkout "$main/submodules/ChimpStackr" "$ref"
git -C "$ref" switch --detach "$pinned_ref"
test "$(git -C "$ref" rev-parse HEAD)" = "$pinned_ref"
test -z "$(git -C "$ref" status --porcelain)"
uv --version
uv sync --offline --frozen --python 3.12.12 --project "$adapter"
"$adapter/.venv/bin/python" -B --version
uv pip freeze --python "$adapter/.venv/bin/python" > "$stage/reference-packages.txt"
test -z "$(git -C "$ref" status --porcelain)"
test -z "$(git -C "$tree" status --porcelain)"
git -C "$tree" show b33c2f6:qualification/p10-performance/evidence/t50-profile-priority-e810/weighted-cpu-pair.py.txt > "$stage/weighted-cpu-pair.py"
python3 - "$stage" "$tree" "$proof" "$archive" "$ref" "$adapter" "$cli" <<'PY'
from datetime import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

stage, tree, proof_path, archive, ref, adapter, cli = map(Path, sys.argv[1:])
proof_bytes = proof_path.read_bytes()
proof = json.loads(proof_bytes)
descriptor = adapter.parent / "pancake/pancake.toml"
lock = tree / "pancake/Cargo.lock"
reference_descriptor = adapter / "chimpstackr.toml"
python = adapter / ".venv/bin/python"

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

build = {
    "commit": proof["source_commit"],
    "lock_sha256": sha(lock),
    "descriptor_sha256": sha(descriptor),
    "executable": str(cli),
    "binary_sha256": sha(cli),
    "component": "cli",
    "package_archive_sha256": proof["archive"]["sha256"],
    "package_receipt_sha256": hashlib.sha256(proof_bytes).hexdigest(),
}
assert build["lock_sha256"] == proof["cargo_lock_sha256"]
assert build["binary_sha256"] == proof["binaries"]["pancake-cli"]["sha256"]
assert cli.stat().st_size == proof["binaries"]["pancake-cli"]["bytes"]
assert sha(reference_descriptor) == "e3e951b674bc0103f267575a99533cc33ead40e2af56671766f4fc71f3f12b76"
ref_head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ref, capture_output=True, text=True, check=True).stdout.strip()
assert ref_head == "ab7a92708269c01c6094729f6cdfaf1415677364"
(stage / "build-receipt.json").write_text(json.dumps(build, indent=2) + "\n")
setup = {
    "status": "prepared_no_jobs_launched",
    "prepared_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    "package_archive": str(archive),
    "package_verification": str(proof_path),
    "build_receipt": str(stage / "build-receipt.json"),
    "build_receipt_sha256": sha(stage / "build-receipt.json"),
    "reference": {
        "checkout": str(ref),
        "commit": ref_head,
        "descriptor_sha256": sha(reference_descriptor),
        "runtime_lock_sha256": sha(adapter / "uv.lock"),
        "python": str(python),
        "python_sha256": sha(python),
        "package_inventory_sha256": sha(stage / "reference-packages.txt"),
        "package_count": len((stage / "reference-packages.txt").read_text().splitlines()),
    },
    "replay": str(stage / "weighted-cpu-pair.py"),
    "replay_sha256": sha(stage / "weighted-cpu-pair.py"),
}
(stage / "diagnostic-setup.json").write_text(json.dumps(setup, indent=2) + "\n")
PY

#!/usr/bin/env bash
# Archive verified receipts only. The shared corpus remains owned by this stage.
set -euo pipefail
stage=$(cd "$(dirname "$0")" && pwd)
tree=$(cd "$stage/../.." && pwd)
cd "$tree"
source_commit=$(jq -r '.source_commit' "$stage/shared-stage.json")
test "$(git rev-parse HEAD)" = "$source_commit"
evidence=qualification/p10-performance/evidence/t50-stage6-e81079d
mkdir "$evidence"
cp "$stage/prepared-stage.json" "$stage/shared-stage.json" "$stage/diagnostic-setup.json" "$evidence/"
gzip -nc "$stage/materialization.json" > "$evidence/materialization.json.gz"
cp /home/krishna/Documents/focus-stacking/artifacts/pancake-packages/linux-e81079d/package-verification.json     "$stage/package-verification.json"
test "$(sha256sum "$stage/package-verification.json" | cut -d ' ' -f 1)" =     "$(jq -r '.package_verification_sha256' "$stage/shared-stage.json")"
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner     -C "$stage" -czf "$evidence/raw-stage.tar.gz"     materialize.sh verify-stage.py seal-stage.sh package-verification.json     generation-command.txt generation-start.txt generation-end.txt generation-time.txt     generation.log generation.exit disk-before.txt disk-after.txt     memory-before.txt memory-after.txt process-census.txt inputs/ownership.json \
    prepare-diagnostic.sh diagnostic-setup.log reference-packages.txt build-receipt.json \
    diagnostic-argv.json weighted-cpu-pair.py
python3 - "$stage" "$evidence" <<'PY'
import json
import sys
from pathlib import Path

stage = Path(sys.argv[1])
evidence = Path(sys.argv[2])
result = json.loads((stage / "shared-stage.json").read_bytes())
disk_before = int((stage / "disk-before.txt").read_text().splitlines()[1].split()[-3])
disk_after = int((stage / "disk-after.txt").read_text().splitlines()[1].split()[-3])
memory_before = int((stage / "memory-before.txt").read_text().splitlines()[1].split()[1])
memory_after = int((stage / "memory-after.txt").read_text().splitlines()[1].split()[1])
start, end = (result[key][11:19] for key in ("started_at", "finished_at"))

(evidence / "README.md").write_text(f"""# Shared frozen T50 stage for the exact e81079d Weighted Average CPU pair

The materializer ran from the clean `{result['source_commit']}`
checkout. The frozen generator, scalar oracle and performance targets
retain their recorded hashes. The sealed Debian package and its verification
receipt also matched their recorded hashes.

All 50 ordered 6000×4000 RGB16 focus TIFFs and both native 16-bit truth TIFFs
matched the frozen encoded hashes and both independent decoded pixel hashes.
The full staged set totals {result['verified_bytes']:,} bytes. The materialization
receipt SHA-256 is
`{result['materialization_sha256']}`.
The corpus contains the CC0-1.0 generated images from the original frozen
recipe. Both actual applications will receive the same 50 focus TIFFs. The
two independent truth TIFFs remain separate from their input arguments.

Generation took {result['generation_seconds']:.3f} seconds with peak RSS of
{result['peak_generation_rss_kib']:,} KiB. The owner held the shared performance
lock from {start} to {end} SGT on 2026-11-18 and limited generation to CPU6,
nice +12, idle I/O, and one numerical thread and decode worker. The generator
reserved 15 GiB. Available disk space was {disk_before:,} bytes at entry and
{disk_after:,} bytes at exit. Available memory was {memory_before:,} KiB at
entry and {memory_after:,} KiB at exit. This run generated and verified
input data. The prelaunch census and common lock excluded timed jobs. An
independent setup step used CPU7 to extract and verify the sealed Debian CLI
and instantiate the 46-package frozen reference environment offline. The
archived frozen-runner preflight checked both exact planned argv lists,
including all 50 ordered source names and explicit CPU. It started no jobs.

The named borrower is the matched Weighted Average CPU diagnostic. The owner
retains the corpus until the pair and its authenticated postflight release
the stage and the coordinator clears cleanup.

[Stage receipt](shared-stage.json) · [Preflight](prepared-stage.json) ·
[Exact diagnostic setup](diagnostic-setup.json) ·
[Complete encoded and decoded records](materialization.json.gz) ·
[Exact command, resource logs, package verification and ownership](raw-stage.tar.gz)
""")
PY
cd "$evidence"
sha256sum README.md prepared-stage.json shared-stage.json diagnostic-setup.json materialization.json.gz raw-stage.tar.gz > SHA256SUMS
sha256sum -c SHA256SUMS
tar -tzf raw-stage.tar.gz
test "$(gzip -dc materialization.json.gz | sha256sum | cut -d ' ' -f 1)" =     "$(jq -r '.materialization_sha256' shared-stage.json)"

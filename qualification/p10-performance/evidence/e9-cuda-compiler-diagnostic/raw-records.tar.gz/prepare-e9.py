"""Download and verify the exact historical E9 inputs in an owned root."""

import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

evidence = Path("qualification/p10-performance/evidence/e9-vulkan-overhead/input-receipt.json")
manifest = json.loads(evidence.read_text())
record = Path("artifacts/e9-cuda-cpp")
root = (record / "input").resolve()
root.mkdir()
item = manifest["archive"]
archive = root / item["path"]
checksum = hashlib.sha256()
total = 0
with urllib.request.urlopen(item["url"], timeout=40) as response, archive.open("xb") as handle:
    while block := response.read(1024 * 1024):
        total += len(block)
        assert total <= item["size"], "download exceeds the pinned archive size"
        checksum.update(block)
        handle.write(block)
assert total == item["size"] and checksum.hexdigest() == item["sha256"]

notice_url = "https://ivc.uwaterloo.ca/database/MEF/MEF-Database.html"
with urllib.request.urlopen(notice_url, timeout=40) as response:
    (root / "waterloo-source-notice.html").write_bytes(response.read(1024 * 1024))

inputs = []
for expected in manifest["frames"]:
    path = root / expected["path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    member = "MEFDatabase/" + expected["path"].split("/MEFDatabase/", 1)[1]
    payload = subprocess.check_output(["7z", "x", "-so", str(archive), member])
    assert len(payload) == expected["bytes"] and hashlib.sha256(payload).hexdigest() == expected["sha256"]
    with path.open("xb") as handle:
        handle.write(payload)
    inputs.append({**expected, "archive_member": member})
receipt = {"archive": item, "ordered_inputs": inputs, "input_root": str(root), "source_notice": notice_url}
(record / "materialized-e9.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Verified {len(inputs)} frozen Balloons photographs and {total} source archive bytes")

"""Verify exact CUDA profile case provenance, pixel witnesses, and archive entries."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import sys
import tarfile

record = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
source = (record / "source-revision.txt").read_text().strip()
descriptor = Path("pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml")
cases = {
    "cpu": {
        "cli.reject.corrupt-images",
        "cli.export.failed-retention",
        "algorithms.coverage.gray_array.weighted_average.cpu",
        "devices.cpu.weighted_average",
        "devices.cpu.exposure_fusion",
    },
    "gpu": {"devices.gpu.weighted.zero_regions", "devices.gpu.exposure_constant_mix.9"},
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


outcomes = {}
for lane, expected in cases.items():
    directory = record / f"{lane}-run"
    assert (record / f"{lane}-run.status").read_text().strip() == "0"
    provenance = load(directory / "provenance.json")
    report = load(directory / "report.json")
    assert provenance["target_commit"] == provenance["suite_commit"] == source
    assert provenance["target_dirty"] == provenance["suite_dirty"] == ""
    assert provenance["target_descriptor_sha256"] == digest(descriptor)
    assert provenance["uv_lock_sha256"] == digest(Path("pancake-conformance/uv.lock"))
    assert set(provenance["cases"]) == expected
    assert report["complete"] and report["status"] == "passed"
    assert report["counts"] == {"passed": len(expected), "failed": 0, "unsupported": 0}
    assert {case["id"] for case in report["cases"]} == expected
    events = {}
    for case in report["cases"]:
        case_id = case["id"]
        assert case["status"] == "passed" and case["execution_environment"] == "host"
        case_dir = directory / "cases" / case_id
        event_rows = [json.loads(line) for path in case_dir.glob("call-*/events.jsonl")
                      for line in path.read_text().splitlines()]
        for event in event_rows:
            assert event["event"] == "stack_complete" and event["completed"] is True
            assert event["actual_backend"] == lane and event["fallback_reason"] is None
            if lane == "gpu":
                assert event["runtime"] == "cuda" and event["physical_gpu"] is True
                assert event["device"] == "NVIDIA GeForce RTX 3090"
                assert event["device_pci_address"] == "0000:01:00.0"
            else:
                assert event["runtime"] == "cpu" and event["physical_gpu"] is False
        if lane == "gpu" or case_id in {
            "devices.cpu.weighted_average",
            "devices.cpu.exposure_fusion",
            "algorithms.coverage.gray_array.weighted_average.cpu",
        }:
            assert event_rows
        events[case_id] = event_rows
    outcomes[lane] = {"provenance": provenance, "counts": report["counts"], "events": events}

assert (record / "comparison.status").read_text().strip() == "0"
result = load(record / "comparison-run/summary.json")
historical = load(record / "historical-cuda-sample.json")["output"]
assert Counter(row["kind"] for row in result["samples"]) == {"warmup": 4, "diagnostic": 10}
assert len(result["paired_pixel_differences"]) == 7
assert result["binary_sha256"] == {
    "llvm": (record / "llvm-binary.sha256").read_text().split()[0],
    "cpp": (record / "candidate-binary.sha256").read_text().split()[0],
}
for sample in result["samples"]:
    assert sample["shape"] == historical["shape"] and sample["dtype"] == "uint16"
    if sample["variant"] == "llvm":
        assert sample["decoded_sha256"] == historical["pixel_sha256"]
        assert sample["encoded_sha256"] == historical["sha256"]

differences = []
for index in range(2, 7):
    pair = {row["variant"]: row["elapsed_ns"] for row in result["samples"] if row["iteration"] == index}
    differences.append(pair["cpp"] - pair["llvm"])

archive = out / "raw-records.tar.gz"
with tarfile.open(archive, "r:gz") as bundle:
    entries = {member.name: sha256(bundle.extractfile(member).read()).hexdigest()
               for member in bundle.getmembers() if member.isfile()}
assert sum(name.startswith("comparison-run/") and name.endswith("/events.jsonl") for name in entries) == 14
assert sum(name.startswith("comparison-run/") and name.endswith("/sample.json") for name in entries) == 14
assert not any(name.endswith((".tif", ".tiff", ".png")) or "/cache/" in name for name in entries)

report = {
    "scope": "Same-source CUDA compiler comparison against real E9 on NVIDIA RTX 3090",
    "source_revision": source,
    "source_tree": (record / "source-tree.txt").read_text().strip(),
    "lock_sha256": (record / "cargo-lock.sha256").read_text().split()[0],
    "cpu_and_gpu_frozen_smoke": outcomes,
    "comparison": result,
    "cpp_to_llvm_warm_median": result["medians_ns"]["cpp"] / result["medians_ns"]["llvm"],
    "paired_differences_ns": differences,
    "paired_median_difference_ns": median(differences),
    "input_cleanup": load(record / "input-cleanup.json"),
    "archive": {"sha256": digest(archive), "entries_sha256": entries},
}
(out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(f"Validated {len(entries)} archived items, 5 CPU and 2 CUDA smoke cases, and 14 E9 exports")

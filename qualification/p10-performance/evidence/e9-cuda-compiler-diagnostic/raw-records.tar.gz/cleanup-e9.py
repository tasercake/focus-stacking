"""Rehash and remove only the staged database and frozen cases owned by this run."""

from hashlib import sha256
import json
from pathlib import Path
import sys

receipt = Path(sys.argv[1])
record = json.loads(receipt.read_text())
root = Path(record["input_root"])
assert root == (receipt.parent / "input").resolve()
archive = record["archive"]
paths = [{**archive, "bytes": archive["size"]}, *record["ordered_inputs"]]
owned = root / "waterloo-source-notice.html"
notice = owned.read_bytes()
paths.append({"path": owned.name, "bytes": len(notice), "sha256": sha256(notice).hexdigest()})
expected = {root / value["path"] for value in paths}
observed = {path for path in root.rglob("*") if path.is_file()}
assert observed == expected, (observed - expected, expected - observed)

for expected_record in paths:
    path = root / expected_record["path"]
    assert path.resolve() == path and not path.is_symlink()
    with path.open("rb") as stream:
        checksum = sha256()
        while part := stream.read(1024 * 1024):
            checksum.update(part)
    assert path.stat().st_size == expected_record["bytes"]
    assert checksum.hexdigest() == expected_record["sha256"]

for path in sorted(expected):
    path.unlink()
for path in sorted(root.rglob("*"), key=lambda child: len(child.parts), reverse=True):
    path.rmdir()
root.rmdir()
result = {"input_root": str(root), "removed_bytes": sum(value["bytes"] for value in paths),
          "verified_removed": paths, "remaining_owned_paths": []}
(receipt.parent / "input-cleanup.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"Removed {len(paths)} verified files, {result['removed_bytes']} bytes")

#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/e9-cuda-cpp"
test "$(git rev-parse HEAD)" = 2143eda2b308497caee96334357dd23d324e1e8e
test -z "$(git status --porcelain)"
sha256sum --check "$record/candidate-binary.sha256"
mkdir -p -m700 "$record/xdg"
suite=(uv run --project pancake-conformance --offline --frozen pancake-conformance run
    --target pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml
    --no-coverage)
status=0
taskset --cpu-list 20,21 env -u PANCAKE_RUNTIME -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS -u LD_LIBRARY_PATH \
    "XDG_RUNTIME_DIR=$record/xdg" "UV_PROJECT_ENVIRONMENT=$record/venv" \
    "PANCAKE_COMPUTE_CACHE_DIR=$record/cpu-cache" \
    "${suite[@]}" --case devices.cpu.weighted_average --case devices.cpu.exposure_fusion \
    --case cli.reject.corrupt-images --case cli.export.failed-retention \
    --case algorithms.coverage.gray_array.weighted_average.cpu \
    --output "$record/cpu-run" > "$record/cpu-console.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/cpu-run.status"
cat "$record/cpu-console.log"
exit "$status"

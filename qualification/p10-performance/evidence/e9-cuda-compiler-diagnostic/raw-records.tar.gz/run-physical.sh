#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/e9-cuda-cpp"
reference_python=/home/krishna/Documents/focus-stacking/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin/python
suite=(uv run --project pancake-conformance --offline --frozen pancake-conformance run
    --target pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml
    --no-coverage)
watched=cargo,rustc,ld.lld,pancake-cli,pancake-gui
test "$(git rev-parse HEAD)" = 2143eda2b308497caee96334357dd23d324e1e8e
test -z "$(git status --porcelain)"
test "$(cat "$record/cpu-run.status")" = 0
test "$(cat "$record/llvm-build.status")" = 0
sha256sum --check "$record/candidate-binary.sha256"
sha256sum --check "$record/llvm-binary.sha256"
sha256sum --check "$record/cuda-compiler-libraries.sha256"
ps -C "$watched" -o pid,state,time,etime,comm > "$record/physical-processes-before.txt" || test "$?" = 1
if awk 'NR > 1 && $2 !~ /^[TZ]/ {found=1} END {exit(found ? 0 : 1)}' "$record/physical-processes-before.txt"; then
    cat "$record/physical-processes-before.txt"
    exit 1
fi
date -Iseconds > "$record/physical-start.txt"
status=0
env -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS \
    "XDG_RUNTIME_DIR=$record/xdg" "UV_PROJECT_ENVIRONMENT=$record/venv" \
    "PANCAKE_COMPUTE_CACHE_DIR=$record/gpu-smoke-cache" \
    "CUDA_CACHE_PATH=$record/gpu-smoke-nvidia" \
    CUDA_VISIBLE_DEVICES=GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac \
    PANCAKE_RUNTIME=cuda LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64 \
    "${suite[@]}" --case devices.gpu.weighted.zero_regions --case devices.gpu.exposure_constant_mix.9 \
    --output "$record/gpu-run" > "$record/gpu-console.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/gpu-run.status"
cat "$record/gpu-console.log"
test "$status" = 0
timeout --signal=TERM --kill-after=5s 180s "$reference_python" "$record/measure-e9.py" \
    "$record/llvm-pancake-cli" "$PWD/pancake/target/release/pancake-cli" \
    "$record/comparison-run" > "$record/comparison.log" 2>&1 || status=$?
date -Iseconds > "$record/physical-finish.txt"
printf '%s\n' "$status" > "$record/comparison.status"
ps -C "$watched" -o pid,state,time,etime,comm > "$record/physical-processes-after.txt" || test "$?" = 1
cat "$record/comparison.log"
exit "$status"

#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/e9-cuda-cpp"
test "$(git rev-parse HEAD)" = 2143eda2b308497caee96334357dd23d324e1e8e
test -z "$(git status --porcelain)"
test "$(cat "$record/build.status")" = 0
sha256sum --check "$record/candidate-binary.sha256"
date -Iseconds > "$record/llvm-build-start.txt"
cd pancake
export CUDARC_CUDA_VERSION=12050 CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
export CARGO_TARGET_DIR="$PWD/target/e9-cuda-cpp-release"
cargo +1.100.0 tree --offline --locked -p pancake -p pancake-cli \
    --features cubecl/cuda -e features -i cubecl-cuda > "$record/llvm-compiler-feature-tree.txt"
if rg -q 'cubecl-cuda feature "cpp"' "$record/llvm-compiler-feature-tree.txt"; then
    exit 1
fi
status=0
taskset --cpu-list 20,21 cargo +1.100.0 build --offline --locked --release \
    -p pancake -p pancake-cli --bin pancake-cli --features cubecl/cuda \
    > "$record/llvm-build.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/llvm-build.status"
date -Iseconds > "$record/llvm-build-finish.txt"
tail -n 12 "$record/llvm-build.log"
test "$status" = 0
install -m755 "$CARGO_TARGET_DIR/release/pancake-cli" "$record/llvm-pancake-cli"
sha256sum "$record/llvm-pancake-cli" > "$record/llvm-binary.sha256"
readelf -n "$record/llvm-pancake-cli" > "$record/llvm-elf-notes.txt"
rg 'Build ID' "$record/llvm-elf-notes.txt"
cat "$record/llvm-binary.sha256"

"""Run the frozen roadmap selection against the current locked release binary."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
adapter = root / "pancake-conformance/src/pancake_conformance/adapters/pancake"
application = root / "pancake"
binary = application / "target/release/pancake-cli"
report = Path(sys.argv[1]).resolve()
before = sha256(binary.read_bytes()).hexdigest()
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
ids = [entry["id"] for entry in json.loads((adapter / "case-roadmap.json").read_bytes())["cases"]
       if entry["primary_milestone"] == "P4"]
assert len(ids) == len(set(ids)) == 69
args = ["uv", "run", "--project", "pancake-conformance", "--frozen", "pancake-conformance", "run",
        "--target", str(adapter / "pancake.toml"), "--no-coverage", "--output", str(report),
        *[word for case in ids for word in ("--case", case)]]
completed = subprocess.run(args, check=False)
status = json.loads((report / "report.json").read_bytes())
provenance = json.loads((report / "provenance.json").read_bytes())
assert sha256(binary.read_bytes()).hexdigest() == before
assert status["complete"] and status["selected_count"] == status["completed_count"] == 69
assert {case["id"] for case in status["cases"]} == set(ids)
assert not provenance["target_dirty"] and not provenance["suite_dirty"]
gpu = report / "cases/algorithms.coverage.hdr_multibatch.gpu/call-01/events.jsonl"
physical = json.loads(gpu.read_text().splitlines()[-1]) if gpu.exists() else None
assert physical is not None and physical["actual_backend"] == "gpu" and physical["runtime"] == "wgpu-vulkan" and physical["physical_gpu"] is True and physical["completed"] is True
receipt = {"command": args, "exit": completed.returncode, "binary_sha256": before, "case_ids": ids,
           "release_command": "cargo +1.100.0 build --release --locked -p pancake-cli",
           "lock_sha256": sha256((application / "Cargo.lock").read_bytes()).hexdigest(),
           "commit": provenance["target_commit"], "physical_execution": physical}
(report / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
raise SystemExit(completed.returncode)

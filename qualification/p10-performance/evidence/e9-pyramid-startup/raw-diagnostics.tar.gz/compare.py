"""Compare completed E9 builds on the same original files."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

import numpy as np
import tifffile

root = Path(sys.argv[1]).resolve()
source = Path(sys.argv[2]).resolve()
mode = sys.argv[3]
binaries = {Path(arg).parent.name: Path(arg).resolve() for arg in sys.argv[4:]}
inputs = sorted(source.glob("DSC_*.png"))
if [path.stem for path in inputs] != [f"DSC_{i:04}" for i in range(163, 172)]:
    raise SystemExit(f"invalid E9 inputs: {inputs}")
root.mkdir(parents=True, exist_ok=False)
def digests(paths):
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
before = digests(inputs)
cache_dirs = {key: root / (key + "-cache") for key in binaries}
for directory in cache_dirs.values():
    directory.mkdir()
samples = {key: [] for key in binaries}
all_jobs = {}
anchor = None
for index in range(4):
    order = list(binaries) if index % 2 == 0 else list(reversed(binaries))
    for name in order:
        binary = binaries[name]
        prefix = root / f"{name}-{index}"
        output = prefix.with_suffix(".tif")
        event_file = prefix.with_suffix(".jsonl")
        args = [str(binary), "--input", *map(str, inputs), "--output", str(output),
                f"--{mode}", "--method", "exposure_fusion", "--align", "--alignment-mode", "euclidean",
                "--alignment-ref", "first", "--kernel-size", "6", "--pyramid-levels", "8",
                "--scale-factor", "6", "--slab-size", "0", "--slab-overlap", "0", "--bit-depth", "16",
                "--auto-crop"]
        env = dict(os.environ)
        for variable in ("DISPLAY", "WAYLAND_DISPLAY", "PANCAKE_RUNTIME", "CUBECL_DEBUG_LOG", "CUBECL_DEBUG_OPTION"):
            env.pop(variable, None)
        if mode == "gpu":
            env["PANCAKE_RUNTIME"] = "wgpu"
            args.extend(("--gpu-id", "0"))
        env.update(PANCAKE_COMPUTE_CACHE_DIR=str(cache_dirs[name]), CONFORMANCE_EVENTS_PATH=str(event_file))
        start = time.perf_counter_ns()
        run = subprocess.run(args, env=env, capture_output=True, text=True, check=False, timeout=90)
        elapsed = (time.perf_counter_ns() - start) / 1e9
        if run.returncode:
            raise SystemExit(f"E9 failed for {name} on {mode}: {run.stderr}")
        event = json.loads(event_file.read_text().splitlines()[-1])
        assert event["completed"] is True and event["actual_backend"] == mode
        assert mode == "cpu" or (event["physical_gpu"] is True and event["runtime"] == "wgpu-vulkan")
        pixels = tifffile.imread(output)
        assert pixels.shape == (337, 510, 3) and pixels.dtype == np.dtype("uint16")
        assert np.ptp(pixels) == 65_535, "unexpected E9 output range"
        if anchor is None:
            anchor = pixels.astype(np.int32)
        error = np.abs(pixels.astype(np.int32) - anchor)
        output_hash = hashlib.sha256(output.read_bytes()).hexdigest()
        quality = {"shape": pixels.shape, "dtype": str(pixels.dtype),
                   "decoded_sha256": hashlib.sha256(pixels.tobytes()).hexdigest(),
                   "changed_channels": int(np.count_nonzero(error)),
                   "mae_codes": float(error.mean()), "max_error_codes": int(error.max())}
        all_jobs[prefix.name] = {"argv": args, "stdout": run.stdout, "stderr": run.stderr,
                                "event": event, "output_sha256": output_hash, "seconds": elapsed, "quality": quality}
        if index:
            samples[name].append(elapsed)
        output.unlink()
assert digests(inputs) == before
pixels = {job["output_sha256"] for job in all_jobs.values()}
result = {"scope": "diagnostic only; builds could overlap; one warm-up, three observations per candidate",
          "mode": mode, "inputs": before, "binaries": digests(binaries.values()), "samples": samples,
          "median": {key: statistics.median(values) for key, values in samples.items()}, "jobs": all_jobs,
          "same_encoded_output": len(pixels) == 1}
(root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ("samples", "median", "same_encoded_output")}, indent=2))

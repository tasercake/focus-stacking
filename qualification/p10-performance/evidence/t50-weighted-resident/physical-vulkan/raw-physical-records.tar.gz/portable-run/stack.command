timeout --signal=TERM --kill-after=5s 45s taskset -c 10\,11 /home/krishna/Documents/focus-stacking/artifacts/pancake-linux-native/a49ce69/weighted-vulkan-probe job::weighted_probe:: --test-threads=1 

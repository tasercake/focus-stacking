"""Verify exact Vulkan jobs, fixture flow, and both output representations."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
stats = {
    "9-Translation-0-113-[0.0, 0.0]": (9, 9, 9, 9, 0, 0),
    "5-Translation-0-113-[3.25, -1.5]": (5, 5, 5, 4, 1, 0),
    "5-Translation-0-111-[0.0, 0.0]": (5, 5, 5, 4, 1, 0),
    "5-Off-0-113-[0.0, 0.0]": (5, 5, 0, 0, 0, 0),
    "5-Translation-3-113-[0.0, 0.0]": (5, 7, 5, 0, 0, 0),
    "5-Off-0-111-[0.0, 0.0]": (5, 5, 0, 0, 0, 1),
}
assert "4 passed; 0 failed" in (root / "stack.log").read_text()
layout = (root / "input.log").read_text()
assert "vulkan_weighted_first_import_is_atomic ... ok" in layout
assert "1 passed; 0 failed" in layout
assert "exit=0" in (root / "terminal.txt").read_text()
[nvidia] = (root / "nvidia.txt").read_text().splitlines()
host_name, uuid, driver_pci, driver_version = [field.strip() for field in nvidia.split(",")]
assert host_name == "NVIDIA GeForce RTX 3090"
assert uuid == "GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac"
assert driver_pci.lower() == "00000000:01:00.0"
assert {path.name for path in (root / "output").iterdir()} == set(stats)

cases = {}
for case, (sources, iterations, luma, residents, warps, resizes) in stats.items():
    output = root / "output" / case
    stock, candidate = [
        json.loads((output / f"{side}.json").read_text())
        for side in ("control", "candidate")
    ]
    assert stock["event"] == candidate["event"]
    event = candidate["event"]
    assert event["event"] == "stack_complete" and event["completed"] is True
    assert event["fallback_reason"] is None and event["physical_gpu"] is True
    assert event["actual_backend"] == "gpu" and event["runtime"] == "wgpu-vulkan"
    assert event["device"] == host_name and event["device_pci_address"] == "0000:01:00.0"
    assert event["device_fingerprint"] == "spirv_4318_8708"
    assert len(event["alignment_transforms"]) == len(event["sequential_transforms"]) == sources
    assert stock["progress"] == candidate["progress"] == list(range(1, sources + 1))
    for arm, reused in ((stock, 0), (candidate, residents)):
        assert Counter(arm["operations"]) == Counter({
            "LumaUpload": luma, "FusionUpload": iterations - reused, "Resident": reused,
            "Weight": iterations, "Combine": iterations, "FrameWait": iterations,
            "Warp": warps, "Resize": resizes,
        }), (case, arm["operations"])
    case_summary = {"fusion_uploads": [iterations, iterations - residents], "progress": candidate["progress"]}
    for representation in ("f32le", "tif"):
        stock_bytes, candidate_bytes = [
            (output / f"{side}.{representation}").read_bytes()
            for side in ("control", "candidate")
        ]
        assert stock_bytes and stock_bytes == candidate_bytes, (case, representation)
        case_summary[representation] = {"sha256": sha256(candidate_bytes).hexdigest(), "bytes": len(candidate_bytes)}
    cases[case] = case_summary

print(json.dumps({
    "backend": "wgpu-vulkan", "gpu": host_name, "pci": driver_pci, "uuid": uuid,
    "driver": driver_version, "fingerprint": "spirv_4318_8708", "fixture_pairs": len(cases),
    "jobs": 2 * len(cases), "foreign_cpu_service_and_layout_rejected": True,
    "gpu_weights_and_scores_match_after_first_frame_recovery": True, "fixtures": cases,
}, indent=2))

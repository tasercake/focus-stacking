#!/usr/bin/env bash
set -euo pipefail
bench=/tmp/pancake-worktrees.t3paqgWM/p10-bench
seal=/tmp/pancake-worktrees.t3paqgWM/p10-native-5216ba4
plan="$bench/artifacts/p10-native-plan"
out="$bench/artifacts/p10-e9-vulkan-diagnostic"
real=/home/krishna/Documents/focus-stacking/artifacts/pancake-corpus/p2-real-inputs
ref="$seal/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin/python"
cd "$seal"
mkdir "$out"
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
export PYTHONPATH="$seal/pancake-conformance/src"
date -Iseconds > "$out/quiet-start.txt"
nvidia-smi > "$out/initial-gpu.txt"
ps -eo pcpu,pmem,pid,ppid,stat,comm --sort=-pcpu | head -25 > "$out/initial-host.txt" || test "$?" = 141
threads=$("$ref" -c 'import os; print(len(os.sched_getaffinity(0)))')
status=0
"$ref" qualification/p10-performance/p10.py run \
   --runtime wgpu-vulkan --profile E9.exposure_fusion.gpu \
   --input-root "$real" --build-receipt "$plan/sealed-cli-build-receipt.json" \
   --output "$out/paired" --threads "$threads" --timeout 120 --keep-review-images \
   --gpu-uuid GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac \
   --candidate-gpu-index 0 --reference-gpu-index 0 \
   > "$out/collector.stdout.txt" 2> "$out/collector.stderr.txt" || status=$?
printf '%s\n' "$status" | tee "$out/collector-exit-code.txt"
nvidia-smi > "$out/final-gpu.txt"
date -Iseconds > "$out/quiet-end.txt"

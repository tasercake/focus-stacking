#!/usr/bin/env python3
"""Authenticate and remove this worktree's exact re-acquired D150 originals."""

import hashlib
import json
import sys
from pathlib import Path

scratch, output = map(Path, sys.argv[1:3])
input_root = scratch / 'inputs'
marker = input_root / 'ownership.json'
acquisition = scratch / 'acquisition.json'
receipt = json.loads(acquisition.read_text())
audit = json.loads(marker.read_text())
archive = scratch / receipt['archive']['path']
assert scratch.resolve(strict=True) == scratch and not input_root.is_symlink()
assert audit == {
    'task': 'D150 native lifecycle replay',
    'frozen_manifest_sha256': receipt['frozen_manifest_sha256'],
    'archive_sha256': receipt['archive']['sha256'],
}


def digest(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


assert archive.parent == scratch
originals = {}
for original in receipt['ordered_frames']:
    file = input_root / original['path']
    assert file.resolve(strict=True) == file and file.is_relative_to(input_root)
    assert file.stat().st_size == original['bytes'] and digest(file) == original['sha256']
    originals[file] = original['bytes']
assert len(originals) == 150
assert {path for path in input_root.rglob('*') if path.is_file() or path.is_symlink()} == set(originals) | {marker}
assert archive.stat().st_size == receipt['archive']['size'] and digest(archive) == receipt['archive']['sha256']
proof = {
    'owned_input_root': str(input_root),
    'acquisition_sha256': digest(acquisition),
    'verified_then_removed_originals': len(originals),
    'verified_original_bytes': sum(originals.values()),
    'verified_then_removed_archive_sha256': receipt['archive']['sha256'],
    'verified_archive_bytes': receipt['archive']['size'],
}
for file in originals:
    file.unlink()
marker.unlink()
for directory in sorted((path for path in input_root.rglob('*') if path.is_dir()), key=lambda path: len(path.parts), reverse=True):
    directory.rmdir()
input_root.rmdir()
archive.unlink()
assert not input_root.exists() and not archive.exists()
with output.open('x') as stream:
    stream.write(json.dumps(proof, indent=2) + '\n')

#!/usr/bin/env python3
"""Bind both observed workloads to the historic campaign and evaluate the same gate."""

import json
import sys
from pathlib import Path

from p10 import TARGETS_PATH, sha256
from protocol import Campaign, evaluate_latency, merge_latency_samples


def manifest_without_local_path(item):
    """Compare the input identity shared by different working directories."""
    return {key: value for key, value in item.items() if key != 'path'}


root, plan = map(Path, sys.argv[1:3])
preflight = json.loads((plan / 'preflight.json').read_text())
build = json.loads((plan / 'build-receipt.json').read_text())
assert sha256(TARGETS_PATH) == preflight['targets_sha256']
campaign = Campaign.load(TARGETS_PATH)
traces = {}
receipt_digests = {}
result = {'source': build['commit'], 'gui_sha256': build['binary_sha256'], 'workloads': {}, 'errors': {}}
for label, expected in preflight['scenarios'].items():
    path = root / label / 'native-latency.json'
    if not path.exists():
        result['errors'][label] = 'collector did not leave a native receipt'
        continue
    trace = json.loads(path.read_text())
    receipt_digests[label] = sha256(path)
    traces[label] = trace
    samples = trace['lifecycle']
    if trace['status'] != 'captured':
        result['errors'][label] = trace.get('error', 'incomplete capture')
        result['workloads'][label] = {'samples': len(samples)}
        continue
    assert trace['candidate'] == build
    assert trace['collector_sha256'] == preflight['harness_sha256']['linux_latency.py']
    assert trace['performance_targets_sha256'] == preflight['targets_sha256']
    assert trace['scenario_sha256'] == expected['replay_sha256']
    assert trace['workload'] == expected['workload']
    assert trace['ordered_inputs'] == expected['ordered_inputs']
    assert manifest_without_local_path(trace['input_manifest']) == manifest_without_local_path(expected['input_manifest'])
    _, lifecycle, workloads = merge_latency_samples([trace])
    assert workloads == [expected['workload']]
    assert len(lifecycle) == 60
    timing = evaluate_latency(campaign, [], lifecycle)['lifecycle']
    assert all(entry['acknowledgement_ns']['count'] == 30 for entry in timing.values())
    physical = trace['physical_wgpu_run']
    assert physical['process_gpu_residency_at_visible_launch_bytes'] > 0
    assert all(event['runtime'] == 'wgpu-vulkan' for event in physical['stack_completions'])
    result['workloads'][label] = {
        'samples': len(lifecycle),
        'ordered_inputs': len(trace['ordered_inputs']),
        'inputs_unchanged': trace['inputs_unchanged'],
        'display_size': trace['size'],
        'physical_gpu_uuid': physical['gpu_uuid'],
        'visible_gpu_residency_bytes': physical['process_gpu_residency_at_visible_launch_bytes'],
        'completion_runtime': [event['runtime'] for event in physical['stack_completions']],
        'timing': timing,
    }
result['receipt_sha256'] = receipt_digests
if not result['errors']:
    viewer, lifecycle, workloads = merge_latency_samples(list(traces.values()))
    frozen = evaluate_latency(campaign, viewer, lifecycle)
    result['combined'] = frozen['lifecycle']
    result['qualified_lifecycle_workloads'] = workloads
    result['all_deadlines_passed'] = all(row['status'] == 'pass' for row in frozen['lifecycle'].values())
    reducer_path = root / 'frozen-reduction.json'
    historical_reducer = json.loads(reducer_path.read_text())
    assert historical_reducer['lifecycle'] == result['combined']
    assert historical_reducer['native_lifecycle_workloads']['workloads'] == workloads
    result['reducer_sha256'] = sha256(reducer_path)
else:
    result['all_deadlines_passed'] = False
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['all_deadlines_passed'] else 1)

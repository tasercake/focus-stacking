"""Reduce the corrected native viewer observations alongside the frozen reducer."""

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image
from protocol import distribution, sha256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("corrected", type=Path)
    parser.add_argument("initial_setup", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    capture = args.corrected / "timed/native-latency.json"
    provenance = args.corrected / "calibration/calibration.json"
    collected = json.loads(capture.read_text())
    calibration = json.loads(provenance.read_text())
    original = args.initial_setup / "timed/native-latency.json"
    raw_setup = json.loads(original.read_text())
    scenario = json.loads(
        (args.initial_setup / "calibration/scenario.json").read_text()
    )
    screenshot = Image.open(args.initial_setup / "timed/failure.png").convert("RGB")
    before_errors = []
    for patch in scenario["steps"][3]["before"]:
        expected = np.array(
            Image.open(args.initial_setup / "calibration" / patch["png"])
        ).astype(np.int16)
        x, y = patch["point"]
        height, width, _ = expected.shape
        visible = np.array(screenshot.crop((x, y, x + width, y + height))).astype(
            np.int16
        )
        before_errors.append(int(np.abs(visible - expected).max()))

    result = {
        "corrected_build": {
            key: collected["candidate"][key]
            for key in ("commit", "lock_sha256", "binary_sha256", "harness_commit")
        },
        "capture_sha256": sha256(capture),
        "calibration_sha256": sha256(provenance),
        "calibration": {
            "retained_tiff": calibration["retained_tiff"],
            "inputs_unchanged": calibration["inputs_unchanged"],
            "temporary_tiff_removed": calibration["temporary_tiff_removed"],
            "channel_max_error": {
                key: calibration[key]["channel_max_error"]
                for key in (
                    "source0",
                    "source6",
                    "result",
                    "zoom",
                    "pan",
                    "compare_before",
                    "compare_after",
                )
            },
        },
        "initial_setup": {
            "capture_sha256": sha256(original),
            "status": raw_setup["status"],
            "error": raw_setup["error"],
            "observed_samples": len(raw_setup["viewer"]),
            "confirmed_visible_preparation_maximum_channel_errors": before_errors,
            "generator_used_wrong_tolerance_field": True,
        },
        "corrected_capture_status": collected["status"],
        "corrected_capture_error": collected.get("error"),
        "capture_inputs_unchanged": collected["inputs_unchanged"],
        "capture_workload": collected["workload"],
        "actual_operator_samples": len(collected["viewer"]),
        "observations": {},
    }
    for condition in ("idle", "loaded"):
        valid = [item for item in collected["viewer"] if item["condition"] == condition]
        groups = {}
        for action in sorted({item["action"] for item in valid}):
            groups[action] = distribution(
                [
                    item["presented_ns"] - item["dispatched_ns"]
                    for item in valid
                    if item["action"] == action
                ]
            )
        result["observations"][condition] = {
            "count": len(valid),
            "input_to_present_ns": distribution(
                [item["presented_ns"] - item["dispatched_ns"] for item in valid]
            )
            if valid
            else None,
            "observation_gaps_ns": distribution(
                [item["maximum_observation_gap_ns"] for item in valid]
            )
            if valid
            else None,
            "by_action": groups,
            "worker_stage_at_dispatch": dict(
                Counter(item["worker_before"].split(" · ")[1] for item in valid)
            ),
        }
    with args.output.open("x") as out:
        json.dump(result, out, indent=2)
        out.write("\n")


if __name__ == "__main__":
    main()

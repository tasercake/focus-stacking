"""Build the actual full T50 viewer scenario from independent calibrated screen states."""

import argparse
import json
from pathlib import Path

from native_campaign import build_viewer
from p10 import _write
from PIL import Image
from protocol import sha256


def _click(control):
    return {"kind": "click", "at": {"control": control}}


def _drag(start, end):
    return {
        "kind": "drag",
        "at": {"control": "viewer", "fraction": start},
        "to": {"control": "viewer", "fraction": end},
    }


def _setup(*motions, phase=None):
    step = {"kind": "setup", "inputs": list(motions)}
    if phase:
        step["worker_phase"] = phase
    return step


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("calibration_directory", type=Path)
    args = parser.parse_args()
    output = args.calibration_directory.resolve(strict=True)
    calibration = output / "calibration.json"
    report = json.loads(calibration.read_text())
    if report.get("status") != "pass" or not report.get("inputs_unchanged"):
        raise ValueError("successful exact full T50 physical calibration is required")

    def trial(before, after, motion, *setup):
        left, top, width, height = report[before]["region"]
        if report[after]["region"] != [left, top, width, height]:
            raise ValueError(
                "calibration image geometry changed between physical states"
            )
        coordinates = (
            ((6, 38), (6, 64), (28, 62)) if width > 128 else ((6, 18), (6, 63))
        )
        result = {"input": motion, "setup": [_setup(*setup)]}
        for key, case in (("before", before), ("after", after)):
            entries = []
            with Image.open(output / f"{case}-expected.png", formats=("PNG",)) as image:
                for index, (x, y) in enumerate(coordinates):
                    path = output / f"{case}-{index:02d}-witness.png"
                    region = (x, y, x + 16, y + 16)
                    image.crop(region).save(path)
                    entries.append(
                        {
                            "point": [left + x, top + y],
                            "png": path.name,
                            "max_channel_error": 2,
                        }
                    )
            result[key] = entries
        return result

    selected_result = _click("result.0")
    fit = _click("viewer.fit")
    actual = _click("viewer.actual")
    first, sixth = _click("frame.0"), _click("frame.6")
    start, stop = _click("stack.start"), _click("stack.stop")
    middle, split_right = (0.5, 0.5), (0.74, 0.5)
    trials = {
        "source": trial("source0", "source6", sixth, first, fit),
        "result": trial("source6", "result", selected_result, sixth, fit),
        "pan": trial(
            "zoom", "pan", _drag(middle, (0.59, 0.44)), selected_result, fit, actual
        ),
        "zoom": trial("result", "zoom", actual, selected_result, fit),
        "comparison": trial(
            "compare_before",
            "compare_after",
            _drag(middle, split_right),
            selected_result,
            fit,
            _click("mode.compare"),
            _drag(split_right, middle),
        ),
    }
    manifest = {
        "identity": {
            "commit": report["build"]["commit"],
            "binary_sha256": report["build"]["binary_sha256"],
            "gpu_uuid": report["hardware"]["gpu"]["uuid"],
        },
        "renderer": "physical-wgpu-vulkan",
        "witness_provenance": {
            "calibration_record": calibration.name,
            "calibration_sha256": sha256(calibration),
            "source": report["materialization"],
            "retained_tiff": report["retained_tiff"],
            "source_geometry": "independent decoded TIFF16, projected through pinned FemtoVG-wgpu texture sampler",
            "per_source_maximum_rgb_error": {
                name: report[name]["channel_max_error"]
                for name in (
                    "source0",
                    "source6",
                    "result",
                    "zoom",
                    "pan",
                    "compare_before",
                    "compare_after",
                )
            },
        },
        "cohorts": {
            "idle": {
                "setup": [_setup(_click("method.hybrid"), start, phase="completed")],
                "trials": trials,
            },
            "loaded": {
                "setup": [],
                "round_setup": [_setup(start, phase="running") | {"numerical": True}],
                "round_finish": [_setup(stop, phase="idle")],
                "trials": trials,
            },
        },
    }
    _write(output / "scenario.json", build_viewer(manifest, output))
    _write(output / "witness-manifest.json", manifest)


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail
bench=/tmp/pancake-worktrees.t3paqgWM/p10-bench
source_dir=/tmp/pancake-worktrees.t3paqgWM/p10-native-view-74dfaa
plan="$bench/artifacts/p10-native-plan"
owner="$bench/artifacts/p10-viewer-materialization"
out="$bench/artifacts/p10-corrected-viewer"
ref="$bench/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin/python"
source /home/krishna/Documents/focus-stacking/artifacts/p10-compare/native-tools/gui-env.sh
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
export PYTHONPATH="$source_dir/pancake-conformance/src:$source_dir/qualification/p10-performance"
cd "$source_dir"
mkdir "$out"
status=0
timeout --signal=INT --kill-after=15s 300s "$ref" "$plan/calibrate-full-viewer.py" \
  --build-receipt "$plan/corrected-build-receipt.json" \
  --materialization "$owner/materialization.json" --input-root "$owner/owned-t50" \
  --output "$out/calibration" > "$out/calibration.stdout.txt" 2> "$out/calibration.stderr.txt" || status=$?
printf '%s\n' "$status" > "$out/calibration.exit.txt"
if test "$status" = 0; then
  "$ref" "$plan/prepare-full-scenario.py" "$out/calibration"
fi

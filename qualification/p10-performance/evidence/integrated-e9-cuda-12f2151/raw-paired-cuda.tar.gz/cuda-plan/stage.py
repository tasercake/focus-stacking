"""Verify and stage the retained P6 native CUDA CLI for matched E9."""

import argparse
import shutil
from pathlib import Path
from types import SimpleNamespace

from p10 import (
    CANDIDATE,
    ROOT,
    TARGETS_PATH,
    _candidate_binary,
    _git,
    _prepared_targets,
    _require_clean,
    _snapshot,
    _write,
)
from pancake_conformance.target import TargetSpec
from protocol import Campaign, corpus, sha256, verify_frames

PRODUCT = "12f2151c8a198b5209c8f4d506dbd17fd9aaa74f"
BINARY = "45cb96ed124a3c8145e3c7cbbf836a3334580d14d63fde59596b393225910ec4"
BUILD_LOG = "72b81f3b58d7a894dd496249ff0c5537a235e29ad5778efb607c26c2575b9269"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for item in ("producer", "input-root", "output"):
        parser.add_argument("--" + item, required=True, type=Path)
    args = parser.parse_args()
    producer = args.producer.resolve(strict=True)
    output = args.output.resolve(strict=True)
    target = TargetSpec.load(CANDIDATE)
    _require_clean(ROOT, "pancake", str(CANDIDATE))
    tree = _git(ROOT, "rev-parse", PRODUCT + "^{tree}")
    identity = _snapshot(target, target.root / "Cargo.lock")
    if (
        identity["commit"] != PRODUCT
        or (producer / "source.txt").read_text().strip() != PRODUCT
    ):
        raise ValueError(
            "native producer and staged checkout must be the exact product"
        )
    if (producer / "source-tree.txt").read_text().strip() != tree:
        raise ValueError("native CUDA source tree mismatch")
    if (producer / "lock.txt").read_text().split()[0] != identity["lock_sha256"]:
        raise ValueError("native CUDA lock mismatch")
    if (
        sha256(producer / "pancake-cli") != BINARY
        or sha256(producer / "cuda-build.log") != BUILD_LOG
    ):
        raise ValueError(
            "native CUDA build or executable differs from the retained P6 receipt"
        )
    runtime_libraries = {}
    for line in (producer / "runtime-libraries.sha256").read_text().splitlines():
        value, name = line.split(maxsplit=1)
        if sha256(Path(name)) != value:
            raise ValueError(f"native CUDA runtime library changed: {name}")
        runtime_libraries[name] = value
    provenance = output / "producer"
    provenance.mkdir()
    for source in sorted(producer.iterdir()):
        if source.is_file() and source.name != "pancake-cli":
            shutil.copy2(source, provenance / source.name)
    executable = target.root / target.command("cli")[0]
    executable.parent.mkdir(parents=True, exist_ok=True)
    if executable.exists():
        raise ValueError("staging directory already has a candidate")
    shutil.copy2(producer / "pancake-cli", executable)
    executable = _candidate_binary(target)
    if sha256(executable) != BINARY:
        raise ValueError("staged CUDA binary differs from producer")
    receipt = identity | {
        "component": "cli",
        "executable": str(executable),
        "binary_sha256": BINARY,
        "source_tree": tree,
        "producer_binary": str(producer / "pancake-cli"),
        "producer_log_sha256": BUILD_LOG,
        "producer_build_command": [
            "cargo",
            "build",
            "--locked",
            "--release",
            "-p",
            "pancake",
            "-p",
            "pancake-cli",
            "--bin",
            "pancake-cli",
            "-j",
            "3",
            "--features",
            "cubecl/cuda",
        ],
        "producer_build_environment": {
            "CUDARC_CUDA_VERSION": "12050",
            "CARGO_INCREMENTAL": "0",
            "CARGO_TARGET_DIR": "pancake/target/native-release",
            "RUSTC_WRAPPER": "/tmp/pancake-tools/bin/pancake-rust-cache",
        },
        "producer_toolchain": (provenance / "rustc.txt").read_text(),
        "cuda_runtime_libraries": runtime_libraries,
        "measurement_runner": {
            "git_base": PRODUCT,
            "qualification_only_patch_sha256": sha256(output / "cuda-runner.patch"),
            "files": {
                str(path.relative_to(ROOT)): sha256(path)
                for path in sorted(
                    (ROOT / "qualification/p10-performance").glob("*.py")
                )
            },
        },
    }
    output_receipt = output / "candidate-receipt.json"
    _write(output_receipt, receipt)
    campaign = Campaign.load(TARGETS_PATH)
    rows, source = corpus(ROOT, campaign, "E9")
    verify_frames(args.input_root, rows, 9)
    _, identities = _prepared_targets(
        SimpleNamespace(profile="E9.exposure_fusion.gpu", build_receipt=output_receipt),
        campaign,
    )
    _write(
        output / "preflight.json",
        {
            "input_root": str(args.input_root.resolve()),
            "input_provenance": source,
            "frame_receipts": rows,
            "frozen_targets_sha256": sha256(TARGETS_PATH),
            "launch_identities": identities,
        },
    )


if __name__ == "__main__":
    main()

"""Summarize exact E9 runs while keeping unqualified memory metrics missing."""

import argparse
import csv
import json
from pathlib import Path

from protocol import sha256

COLUMNS = [
    "lane",
    "kind",
    "number",
    "target",
    "valid",
    "elapsed_ns",
    "maximum_rss_sample_gap_ns",
    "maximum_gpu_sample_gap_ns",
    "peak_rss_bytes",
    "peak_gpu_bytes",
    "observed_peak_rss_bytes",
    "observed_peak_gpu_bytes",
    "kernel_process_peak_rss_bytes",
    "max_sample_acquisition_ns",
    "sampler_thread_cpu_ns",
    "pixel_sha256",
    "invalid_reason",
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("sample_table", type=Path)
    args = parser.parse_args()
    result = {"lanes": {}}
    with args.sample_table.open("x", newline="") as stream:
        rows = csv.DictWriter(stream, fieldnames=COLUMNS, lineterminator="\n")
        rows.writeheader()
        for lane in ("cuda",):
            directory = args.runs / lane
            path = directory / "report.json"
            report = json.loads(path.read_text())
            review_path = args.runs / f"{lane}-review.json"
            records = report["samples"]
            for record in [*records, *report["diagnostics"]]:
                row = {field: record.get(field) for field in COLUMNS}
                row.update(
                    lane=lane, pixel_sha256=record.get("output", {}).get("pixel_sha256")
                )
                rows.writerow(row)
            per_target = {}
            for target in ("candidate", "reference"):
                samples = [item for item in records if item["target"] == target]
                valid = [item for item in samples if item["valid"]]
                stats = {
                    "counts": {
                        name: sum(item["kind"] == name for item in valid)
                        for name in ("warmup", "warm", "cold")
                    },
                    "invalid_jobs": len(samples) - len(valid),
                    "output_pixel_hashes": sorted(
                        {item["output"]["pixel_sha256"] for item in valid}
                    ),
                    "rss_unavailable_samples": sum(
                        item.get("peak_rss_bytes") is None for item in valid
                    ),
                    "rss_max_gap_ns": max(
                        (item["maximum_rss_sample_gap_ns"] for item in valid),
                        default=None,
                    ),
                }
                if report["reference_runtime"] == "opencl":
                    stats.update(
                        {
                            "gpu_unavailable_samples": sum(
                                item.get("peak_gpu_bytes") is None for item in valid
                            ),
                            "gpu_max_gap_ns": max(
                                (item["maximum_gpu_sample_gap_ns"] for item in valid),
                                default=None,
                            ),
                            "gpu_observed_lower_bound_bytes": max(
                                (item["observed_peak_gpu_bytes"] for item in valid),
                                default=None,
                            ),
                        }
                    )
                per_target[target] = stats
            result["lanes"][lane] = {
                "profile": report["profile"],
                "status": report["status"],
                "invalid_reason": report.get("invalid_reason"),
                "original_report_sha256": sha256(path),
                "product": report.get("targets", {}).get("candidate"),
                "reference": report.get("targets", {}).get("reference"),
                "hardware": report.get("hardware"),
                "frozen_targets_sha256": report["performance_targets_sha256"],
                "inputs_unchanged": report.get("inputs_unchanged"),
                "numeric_gates": report.get("gates"),
                "per_target": per_target,
                "diagnostic_completions": [
                    {
                        "target": item["target"],
                        "completion": item.get("completion"),
                        "matching_warm_pixel_hashes": item.get(
                            "matching_warm_pixel_hashes"
                        ),
                    }
                    for item in report["diagnostics"]
                ],
                "review_result": json.loads(review_path.read_text())
                if review_path.is_file()
                else None,
            }
    with args.summary.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()

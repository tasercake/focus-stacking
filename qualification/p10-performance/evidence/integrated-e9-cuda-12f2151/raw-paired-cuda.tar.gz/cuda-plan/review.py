"""Independently decode and compare the exact retained first warm E9 pair."""

import argparse
import json
from pathlib import Path

import numpy as np
import tifffile
from protocol import pixel_metrics, verify_output


def channels(image):
    return {
        "rgb_mean_u16": image.mean(axis=(0, 1)).tolist(),
        "rgb_min_u16": image.min(axis=(0, 1)).tolist(),
        "rgb_max_u16": image.max(axis=(0, 1)).tolist(),
        "fraction_at_floor": float((image == 0).mean()),
        "fraction_at_ceiling": float((image == 65535).mean()),
    }


def review(directory):
    report = json.loads((directory / "report.json").read_text())
    if report.get("inputs_unchanged") is not True or not report.get("cleanup", {}).get(
        "retained_review_pair"
    ):
        return {
            "status": "pending",
            "reason": "no complete source-verified first warm pair is available",
        }
    frame = report["frames"][0]
    bounds = frame.get("shape", frame.get("decoded_shape"))
    expected = {
        item["target"]: item["output"]
        for item in report["samples"]
        if item["kind"] == "warm" and item["number"] == 1 and item["valid"]
    }
    paths = {
        name: directory / "warm-01" / name / "complete.tif"
        for name in ("reference", "candidate")
    }
    independent = {name: verify_output(path, bounds) for name, path in paths.items()}
    if expected != independent:
        raise ValueError(
            "retained warm pair differs from the exact timed output metadata"
        )
    pair = pixel_metrics(paths["reference"], paths["candidate"], bounds)
    result = {
        "status": pair["status"],
        "frozen_quality_gate": "pending",
        "reason": "Comparable regions and decoded differences are recorded. Equal fusion quality and final conformance require independent review.",
        "source": "first measured warm pair, exact original E9 Balloons exposure stack",
        "outputs": independent,
        "dimensions_and_pixel_metrics": pair,
        "regions": [],
    }
    if pair["status"] != "decoded_pair":
        return result
    reference, candidate = (
        tifffile.imread(paths[name]) for name in ("reference", "candidate")
    )
    height, width = reference.shape[:2]
    windows = [
        ("upper-left", width // 4, height // 4),
        ("center", width // 2, height // 2),
        ("lower-right", 3 * width // 4, 3 * height // 4),
    ]
    for name, x, y in windows:
        a = reference[y - 24 : y + 24, x - 24 : x + 24]
        b = candidate[y - 24 : y + 24, x - 24 : x + 24]
        difference = b.astype(np.float64) - a
        result["regions"].append(
            {
                "name": name,
                "xywh": [x - 24, y - 24, 48, 48],
                "reference": channels(a),
                "candidate": channels(b),
                "mean_absolute_u16": float(np.abs(difference).mean()),
                "max_absolute_u16": int(np.abs(difference).max()),
                "rms_u16": float(np.square(difference).mean() ** 0.5),
            }
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args()
    result = review(args.directory)
    with args.receipt.open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")


if __name__ == "__main__":
    main()

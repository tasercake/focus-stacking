#!/usr/bin/env bash
set -euo pipefail
root=/tmp/pancake-worktrees.t3paqgWM/integrated-e9-cuda
data_owner=/tmp/pancake-worktrees.t3paqgWM/integrated-e9
cd "$root"
refs=pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin
plan="$root/artifacts/cuda-plan"
work="$root/artifacts/integrated-e9-cuda-run"
mkdir "$work"
export PYTHONPATH="$root/pancake-conformance/src:$root/qualification/p10-performance"
unset LD_LIBRARY_PATH
threads=$("$refs/python" -c 'import os; print(len(os.sched_getaffinity(0)))')
date -Iseconds > "$work/capture-start.txt"
nvidia-smi > "$work/initial-gpu.txt"
ps -eo pcpu,pmem,pid,ppid,stat,comm --sort=-pcpu | head -25 > "$work/initial-host.txt" || test "$?" = 141
status=0
"$refs/python" qualification/p10-performance/p10.py run \
  --runtime cuda --profile E9.exposure_fusion.gpu \
  --gpu-uuid GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac --candidate-gpu-index 0 --reference-gpu-index 0 \
  --cuda-library-path /usr/local/cuda-12.5/lib64 \
  --input-root "$data_owner/artifacts/e9-reacquired/input" \
  --output "$work/cuda" --build-receipt "$plan/candidate-receipt.json" \
  --threads "$threads" --timeout 150 --keep-review-images \
  > "$work/cuda.stdout.txt" 2> "$work/cuda.stderr.txt" || status=$?
printf '%s\n' "$status" > "$work/cuda-exit.txt"
nvidia-smi > "$work/final-gpu.txt"
date -Iseconds > "$work/capture-end.txt"

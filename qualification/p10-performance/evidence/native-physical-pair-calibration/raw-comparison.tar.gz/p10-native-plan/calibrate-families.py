"""Calibrate sealed native physical source and result projection without timing."""

import argparse
import json
import os
import shutil
import subprocess
from pathlib import Path

import numpy as np
from framebuffer import Patch, XTestPointer, XwdScreen, observed_desktop, wait_pixels
from linux_latency import _gui_target, _physical_execution_proof, _prepare_pointer
from native_witness import load_tiff16, render_region
from p10 import _campaign_lock, _environment, _hardware, _write
from pancake_conformance.desktop import DesktopLease
from pancake_conformance.linux_ui import LinuxUISession
from pancake_conformance.macos_ui import MacOSUISession, find_node
from PIL import Image
from protocol import sha256
from resources import NvidiaMemory


def observe_view(
    ui, pointer, screen, texels, native, predicate, name, output, band=None
):
    def matching(snapshot):
        viewer = find_node(snapshot, "viewer")
        data = json.loads(viewer["description"])
        return (viewer, data) if data["has_image"] and predicate(data) else None

    viewer, data = ui.wait(matching, timeout=60, description=name)
    pointer.move(10, 10)
    pointer.settle()
    x, y = viewer["position"]
    width, height = viewer["size"]
    zoom = data["zoom"]
    native_x, native_y = data["center"]
    geometry = (
        x + width / 2 - native_x * zoom,
        y + height / 2 - native_y * zoom,
        native[0] * zoom,
        native[1] * zoom,
    )
    region = (x + width // 2 - 96, y + height // 2 - 48, 192, 96)
    if band is not None:
        region = (x + round(width * band), region[1], 36, region[3])
    expected = render_region(texels, geometry, region)
    try:
        wait_pixels(screen, [Patch(*region[:2], expected, 2)], 2)
    except TimeoutError:
        pass  # Keep the actual pixel differences for calibration diagnosis.
    actual = screen.rgb(*region)
    errors = np.abs(actual.astype(np.int16) - expected)
    for kind, pixels in (("expected", expected), ("displayed", actual)):
        Image.fromarray(pixels).save(output / f"{name}-{kind}.png")
    record = {
        "node": viewer,
        "data": data,
        "geometry": geometry,
        "region": region,
        "expected_sha256": sha256(output / f"{name}-expected.png"),
        "displayed_sha256": sha256(output / f"{name}-displayed.png"),
        "channel_mean_error": float(errors.mean()),
        "channel_max_error": int(errors.max()),
        "pixels_within_two_levels": int(np.sum(errors.max(axis=2) <= 2)),
        "pixel_count": region[2] * region[3],
    }
    _write(output / f"{name}.json", record)
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("build-receipt", "pair-receipt", "output"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {
        "scope": "native physical viewport witness calibration; no performance timestamps"
    }
    result = output / "retained-result.tif"
    try:
        target, build = _gui_target(args.build_receipt)
        pair = json.loads(args.pair_receipt.read_text())
        paths = [Path(pair["owned_output"]) / item["name"] for item in pair["files"]]
        if len(paths) != 2 or any(
            sha256(path) != item["file_sha256"]
            for path, item in zip(paths, pair["files"], strict=True)
        ):
            raise ValueError(
                "source images do not match the authenticated pair receipt"
            )
        report.update(
            {"build": build, "pair_receipt_sha256": sha256(args.pair_receipt)}
        )
        uuid = "GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac"
        hardware = _hardware(uuid)
        report["hardware"] = hardware
        env = _environment(
            target,
            output / "cache",
            output,
            len(os.sched_getaffinity(0)),
            uuid,
            "wgpu",
            True,
        )
        env.update(
            {
                key: os.environ[key]
                for key in ("XDG_DATA_DIRS", "XDG_CONFIG_DIRS", "PANCAKE_ATSPI_PYTHON")
                if key in os.environ
            }
        )
        with (
            _campaign_lock(),
            DesktopLease(),
            observed_desktop(output, env) as (private, framebuffer),
            XwdScreen(framebuffer) as screen,
            (output / "stdout.txt").open("wb") as stdout,
            (output / "stderr.txt").open("wb") as stderr,
        ):
            report["display"] = {
                "name": private["DISPLAY"],
                "size": [screen.width, screen.height],
            }
            process = subprocess.Popen(
                [build["executable"], *map(str, paths)],
                cwd=target.root,
                env=private,
                stdout=stdout,
                stderr=stderr,
                start_new_session=True,
            )
            try:
                with (
                    LinuxUISession(process, output, private) as ui,
                    XTestPointer(private, screen) as pointer,
                ):
                    resident = NvidiaMemory(uuid)
                    try:
                        report["gpu_bytes_at_visible_launch"] = resident.sample(
                            {process.pid}
                        )
                    finally:
                        resident.close()
                    if not report["gpu_bytes_at_visible_launch"]:
                        raise ValueError(
                            "no evidenced physical GPU presentation at visible launch"
                        )
                    ui.click("settings.open")
                    ui.select("settings.device", "GPU")
                    ui.click("dialog.close")
                    first, native = load_tiff16(paths[0])
                    report["source0"] = observe_view(
                        ui,
                        pointer,
                        screen,
                        first,
                        native,
                        lambda data: data["source_index"] == 1,
                        "source0",
                        output,
                    )
                    ui.click("frame.1")
                    second, native = load_tiff16(paths[1])
                    report["source6"] = observe_view(
                        ui,
                        pointer,
                        screen,
                        second,
                        native,
                        lambda data: data["source_index"] == 2,
                        "source6",
                        output,
                    )
                    ui.click("method.hybrid")
                    ui.click("stack.start", position=(0.3, 0.5))
                    ui.wait(
                        lambda snapshot: find_node(snapshot, "export.start").get(
                            "enabled"
                        ),
                        timeout=120,
                        description="physical retained result",
                    )
                    ui.click("export.start")
                    ui.select("export.format", "TIFF")
                    ui.select("export.depth", "16-bit")
                    ui.click("export.confirm")
                    ui.node("save-panel", timeout=30)
                    ui._file_path(result)
                    ui.key("return")
                    ui.wait(
                        lambda snapshot: (
                            result.is_file()
                            and not any(
                                node.get("id") == "save-panel"
                                for node in snapshot["nodes"]
                            )
                        ),
                        timeout=75,
                        description="native full-size TIFF publication",
                    )
                    result_pixels, native = load_tiff16(result)
                    if native != (6000, 4000):
                        raise ValueError(
                            f"expected the true full-size native result, saw {native}"
                        )
                    report["retained_tiff"] = {
                        "sha256": sha256(result),
                        "bytes": result.stat().st_size,
                        "native": native,
                    }
                    ui.click("frame.1")
                    ui.click("result.0")
                    report["result"] = observe_view(
                        ui,
                        pointer,
                        screen,
                        result_pixels,
                        native,
                        lambda data: bool(data["result_method"]),
                        "result",
                        output,
                    )
                    ui.click("viewer.actual")
                    report["zoom"] = observe_view(
                        ui,
                        pointer,
                        screen,
                        result_pixels,
                        native,
                        lambda data: data["zoom"] == 1,
                        "zoom",
                        output,
                    )
                    for task, start, end in (
                        ("pan", (0.5, 0.5), (0.59, 0.44)),
                        ("compare", (0.5, 0.5), (0.74, 0.5)),
                    ):
                        if task == "compare":
                            ui.click("viewer.fit")
                            ui.click("mode.compare")
                            report["compare_before"] = observe_view(
                                ui,
                                pointer,
                                screen,
                                result_pixels,
                                native,
                                lambda data: data["compare"] and data["split"] == 0.5,
                                "compare_before",
                                output,
                                band=0.60,
                            )
                        motion = {
                            "kind": "drag",
                            "at": {"control": "viewer", "fraction": start},
                            "to": {"control": "viewer", "fraction": end},
                        }
                        with _prepare_pointer(pointer, ui, motion) as dispatch:
                            dispatch()
                        if task == "pan":
                            report["pan"] = observe_view(
                                ui,
                                pointer,
                                screen,
                                result_pixels,
                                native,
                                lambda data: data["center"] != [3000, 2000],
                                "pan",
                                output,
                            )
                        else:
                            report["compare_after"] = observe_view(
                                ui,
                                pointer,
                                screen,
                                first,
                                native,
                                lambda data: data["compare"] and data["split"] > 0.70,
                                "compare_after",
                                output,
                                band=0.60,
                            )
            finally:
                MacOSUISession._reap(process)
        report["stack_completions"] = _physical_execution_proof(
            output / "events.jsonl", hardware["gpu"]["pci.bus_id"]
        )
        report["status"] = (
            "pass"
            if all(
                report[name]["channel_max_error"] <= 2
                for name in (
                    "source0",
                    "source6",
                    "result",
                    "zoom",
                    "pan",
                    "compare_before",
                    "compare_after",
                )
            )
            else "fail"
        )
    except (AssertionError, OSError, RuntimeError, ValueError) as error:
        report.update({"status": "fail", "error": str(error)})
    finally:
        if result.is_file():
            result.unlink()
        report["temporary_tiff_removed"] = not result.exists()
        for name in ("bin", "screen", "runtime", "home", "cache"):
            owned = output / name
            if owned.is_dir():
                shutil.rmtree(owned)
        _write(output / "calibration.json", report)
    return report["status"] != "pass"


if __name__ == "__main__":
    raise SystemExit(main())

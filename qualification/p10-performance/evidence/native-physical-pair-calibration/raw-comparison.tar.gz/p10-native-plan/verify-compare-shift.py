"""Check the actual captured split against Slint's independently predicted clip origin."""
import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    args = parser.parse_args()

    def rgb(name):
        return np.asarray(Image.open(args.capture / f"{name}.png")).astype(np.int16)

    reference = rgb("source0-expected")
    source = json.loads((args.capture / "source0.json").read_text())
    findings = {}
    for mode in ("compare_before", "compare_after"):
        visible = rgb(f"{mode}-displayed")
        capture = json.loads((args.capture / f"{mode}.json").read_text())
        split = capture["data"]["split"]
        x = np.float32(capture["node"]["position"][0])
        width = np.float32(capture["node"]["size"][0])
        zoom = np.float32(capture["data"]["zoom"])
        center = np.float32(capture["data"]["center"][0])
        half = np.float32(2)
        origin = x + (width / half - center * zoom)
        logical_delta = (width - width * np.float32(split)) / half
        offset = int(np.floor(origin + logical_delta + 0.5) - np.floor(origin + 0.5))
        screen_positions = capture["region"][0] + np.arange(visible.shape[1])
        source_positions = screen_positions - offset - source["region"][0]
        keep = (source_positions >= 0) & (source_positions < reference.shape[1])
        shifted_source = reference[:, source_positions[keep]]
        error = np.abs(visible[:, keep] - shifted_source)
        findings[mode] = {
            "published_split": split,
            "default_centered_clipping_box_logical_x": float(logical_delta),
            "expected_shift_of_source_textures_in_screen_pixels": offset,
            "correct_anchor_region_max_channel_error": capture["channel_max_error"],
            "shifted_source_region_max_channel_error": int(error.max()),
            "matched_shifted_source_pixels": int(np.sum(error.max(axis=2) <= 1)),
            "tested_shifted_source_pixels": int(error.shape[0] * error.shape[1]),
        }
    print(json.dumps(findings, indent=2))


if __name__ == "__main__":
    main()

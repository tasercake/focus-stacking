"""Snapshot P9's exact locked executable and check the two frozen launch paths."""

import argparse
import shutil
from pathlib import Path
from types import SimpleNamespace

from p10 import (
    CANDIDATE,
    ROOT,
    TARGETS_PATH,
    _candidate_binary,
    _git,
    _prepared_targets,
    _require_clean,
    _snapshot,
    _write,
)
from pancake_conformance.target import TargetSpec
from protocol import Campaign, corpus, sha256, verify_frames

PRODUCT = "12f2151c8a198b5209c8f4d506dbd17fd9aaa74f"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("binary", "producer-log", "input-root", "output"):
        parser.add_argument("--" + name, required=True, type=Path)
    parser.add_argument("--producer-sha256", required=True)
    args = parser.parse_args()
    output = args.output.resolve(strict=True)
    target = TargetSpec.load(CANDIDATE)
    _require_clean(ROOT, "pancake", str(CANDIDATE))
    identity = _snapshot(target, target.root / "Cargo.lock")
    log = args.producer_log.read_text().splitlines()
    if identity["commit"] != PRODUCT or log[0].strip() != PRODUCT:
        raise ValueError("product checkout and P9 producer must both be exact 12f2151")
    if log[1].split()[0] != identity["lock_sha256"]:
        raise ValueError("P9 producer lock differs from the immutable product")
    if sha256(args.binary) != args.producer_sha256:
        raise ValueError("the P9 CLI has different bytes than its recorded digest")
    expected = target.root / target.command("cli")[0]
    expected.parent.mkdir(parents=True, exist_ok=True)
    if expected.exists():
        raise ValueError("stage the true P9 binary into a fresh target path")
    shutil.copy2(args.binary, expected)
    executable = _candidate_binary(target)
    if sha256(executable) != args.producer_sha256:
        raise ValueError("staged CLI differs from the P9 producer")
    staged_log = output / "p9-release-build.log"
    shutil.copy2(args.producer_log, staged_log)
    runner = ROOT / "qualification/p10-performance"
    receipt = identity | {
        "component": "cli",
        "executable": str(executable),
        "binary_sha256": sha256(executable),
        "producer_binary": str(args.binary),
        "producer_log_sha256": sha256(staged_log),
        "producer_build_command": [
            "cargo",
            "build",
            "--locked",
            "--workspace",
            "--release",
            "--jobs",
            "4",
        ],
        "producer_build_environment": {"CARGO_INCREMENTAL": "0"},
        "producer_toolchain": next(line for line in log if line.startswith("rustc ")),
        "candidate_source_tree": _git(ROOT, "rev-parse", PRODUCT + "^{tree}"),
        "measurement_runner": {
            "git_base": PRODUCT,
            "qualification_only_patch_sha256": sha256(
                output / "review-retention.patch"
            ),
            "files": {
                str(path.relative_to(ROOT)): sha256(path)
                for path in sorted(runner.glob("*.py"))
            },
        },
    }
    build_receipt = output / "candidate-receipt.json"
    _write(build_receipt, receipt)
    campaign = Campaign.load(TARGETS_PATH)
    rows, source = corpus(ROOT, campaign, "E9")
    verify_frames(args.input_root, rows, 9)
    verified = {}
    for device in ("cpu", "gpu"):
        _, verified[device] = _prepared_targets(
            SimpleNamespace(
                profile=f"E9.exposure_fusion.{device}", build_receipt=build_receipt
            ),
            campaign,
        )
    _write(
        output / "preflight.json",
        {
            "exact_inputs": str(args.input_root.resolve()),
            "input_provenance": source,
            "frame_receipts": rows,
            "frozen_targets_sha256": sha256(TARGETS_PATH),
            "launch_identities": verified,
        },
    )


if __name__ == "__main__":
    main()

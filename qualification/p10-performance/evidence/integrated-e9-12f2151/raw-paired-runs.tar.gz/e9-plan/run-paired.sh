#!/usr/bin/env bash
set -euo pipefail
root=/tmp/pancake-worktrees.t3paqgWM/integrated-e9
cd "$root"
refs=pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin
plan="$root/artifacts/e9-plan"
inputs="$root/artifacts/e9-reacquired/input"
work="$root/artifacts/integrated-e9-runs"
mkdir "$work"
export PYTHONPATH="$root/pancake-conformance/src:$root/qualification/p10-performance"
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
threads=$("$refs/python" -c 'import os; print(len(os.sched_getaffinity(0)))')
date -Iseconds > "$work/capture-start.txt"
nvidia-smi > "$work/initial-gpu.txt"
ps -eo pcpu,pmem,pid,ppid,stat,comm --sort=-pcpu | head -25 > "$work/initial-host.txt" || test "$?" = 141
for lane in cpu vulkan; do
  runtime=cpu
  device=cpu
  gpu=()
  if [[ "$lane" = vulkan ]]; then
    runtime=wgpu-vulkan
    device=gpu
    gpu=(--gpu-uuid GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac --candidate-gpu-index 0 --reference-gpu-index 0)
  fi
  status=0
  date -Iseconds > "$work/$lane-start.txt"
  "$refs/python" qualification/p10-performance/p10.py run \
    --runtime "$runtime" --profile "E9.exposure_fusion.$device" \
    --input-root "$inputs" --output "$work/$lane" --build-receipt "$plan/candidate-receipt.json" \
    --threads "$threads" --timeout 150 --keep-review-images "${gpu[@]}" \
    > "$work/$lane.stdout.txt" 2> "$work/$lane.stderr.txt" || status=$?
  printf '%s\n' "$status" > "$work/$lane-exit.txt"
  date -Iseconds > "$work/$lane-end.txt"
done
nvidia-smi > "$work/final-gpu.txt"
date -Iseconds > "$work/capture-end.txt"

"""Remove the four independently reviewed, hash-matched temporary TIFFs."""

import argparse
import json
from pathlib import Path

from protocol import sha256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", type=Path)
    args = parser.parse_args()
    root = args.runs.resolve(strict=True)
    owned = {}
    for lane in ("cpu", "vulkan"):
        review = root / f"{lane}-review.json"
        records = json.loads(review.read_text())
        for target in ("candidate", "reference"):
            path = root / lane / "warm-01" / target / "complete.tif"
            metadata = records["outputs"][target]
            if (
                path.is_symlink()
                or path.stat().st_size != metadata["bytes"]
                or sha256(path) != metadata["sha256"]
            ):
                raise ValueError(f"review output changed: {path}")
            owned[path] = {
                "path": str(path.relative_to(root)),
                "file_sha256": metadata["sha256"],
                "pixel_sha256": metadata["pixel_sha256"],
                "bytes": metadata["bytes"],
                "review_receipt_sha256": sha256(review),
            }
    if set(root.rglob("*.tif")) != set(owned):
        raise ValueError("unexpected TIFF set in completed job receipts")
    if any((root / lane / "cache").exists() for lane in ("cpu", "vulkan")):
        raise ValueError("a case-owned measurement cache remains")
    removed = []
    with (root / "output-cleanup.json").open("x") as stream:
        try:
            for path, record in owned.items():
                path.unlink()
                removed.append(record)
        finally:
            json.dump(
                {"removed": removed, "remaining_tiffs": len(list(root.rglob("*.tif")))},
                stream,
                indent=2,
            )
            stream.write("\n")


if __name__ == "__main__":
    main()

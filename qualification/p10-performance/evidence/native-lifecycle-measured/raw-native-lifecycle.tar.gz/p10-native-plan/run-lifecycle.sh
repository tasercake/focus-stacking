#!/usr/bin/env bash
set -euo pipefail
bench=/tmp/pancake-worktrees.t3paqgWM/p10-bench
sealed=/tmp/pancake-worktrees.t3paqgWM/p10-native-5216ba4
real=/home/krishna/Documents/focus-stacking/artifacts/pancake-corpus/p2-real-inputs
plan="$bench/artifacts/p10-native-plan"
output="$bench/artifacts/p10-native-sealed-5216ba4"
python="$bench/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin/python"
source /tmp/pancake-worktrees.t3paqgWM/p7-ui/artifacts/p7/gui-env.sh
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
export PYTHONPATH="$sealed/pancake-conformance/src"
cd "$sealed"
mkdir "$output"
date -Iseconds > "$output/quiet-start.txt"
nvidia-smi > "$output/initial-gpu.txt"
ps -eo pcpu,pmem,pid,ppid,stat,comm --sort=-pcpu | head -25 > "$output/initial-host.txt" || test "$?" = 141
common=(--build-receipt "$plan/sealed-build-receipt.json")
for profile in fixture-64 real-D150; do
    dataset=()
    workload=lifecycle
    if [[ "$profile" == real-D150 ]]; then
        workload=D150
        dataset=(--input-root "$real")
    fi
    result=0
    timeout --signal=INT --kill-after=20s 600s "$python" qualification/p10-performance/linux_latency.py \
        "${common[@]}" --scenario "$plan/$profile.json" --workload "$workload" \
        "${dataset[@]}" --output "$output/$profile" > "$output/$profile.collector.log" 2>&1 || result=$?
    printf '%s %s %s\n' "$profile" "$result" "$(date -Iseconds)" | tee -a "$output/exit-status.txt"
done
result=0
"$python" qualification/p10-performance/p10.py latency \
    "$output/fixture-64/native-latency.json" "$output/real-D150/native-latency.json" \
    > "$output/frozen-reduction.json" 2> "$output/frozen-reduction.stderr" || result=$?
printf '%s\n' "$result" > "$output/reducer-exit-status.txt"
nvidia-smi > "$output/final-gpu.txt"
date -Iseconds > "$output/quiet-end.txt"

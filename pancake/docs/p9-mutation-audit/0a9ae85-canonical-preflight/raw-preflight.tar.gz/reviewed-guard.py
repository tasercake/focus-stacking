"""Verify local round-robin cargo-mutants artifact coverage across shards."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

IDENTITY = ("file", "function", "genre", "name", "package", "replacement", "span")
RESULTS = {"CaughtMutant": "caught", "Unviable": "unviable"}


def read_json(path):
    """Load a native cargo-mutants JSON artifact."""
    return json.loads(path.read_text(encoding="utf-8"))


def mutation_id(row):
    """Compare the native mutant identity, excluding list-only diff decoration."""
    return json.dumps({field: row[field] for field in IDENTITY}, sort_keys=True)


def verify_shards(roster, shards):
    """Require each known mutant once and no failed test outcomes or baselines."""
    full = [mutation_id(row) for row in read_json(roster)]
    if not full or len(set(full)) != len(full) or not shards:
        raise ValueError("Expected a nonempty full roster and shards with no duplicate roster identity")
    counts = {"caught": 0, "unviable": 0}
    versions = set()
    for index, shard in enumerate(shards):
        expected = full[index::len(shards)]
        listed = [mutation_id(row) for row in read_json(shard / "list.json")]
        if listed != expected:
            raise ValueError(f"{shard}: partition differs from round-robin shard {index}/{len(shards)}")
        report = read_json(shard / "outcomes.json")
        versions.add(report["cargo_mutants_version"])
        outcomes = report["outcomes"]
        baselines = [row["summary"] for row in outcomes if row["scenario"] == "Baseline"]
        if baselines != ["Success"]:
            raise ValueError(f"{shard}: expected one successful baseline")
        observed = Counter()
        for row in outcomes:
            scenario = row["scenario"]
            if scenario == "Baseline":
                continue
            variant = scenario["Mutant"]
            status = row["summary"]
            if status not in RESULTS:
                raise ValueError(f"{shard}: {status} for {variant['name']}")
            observed[mutation_id(variant)] += 1
            counts[RESULTS[status]] += 1
        if observed != Counter(expected):
            raise ValueError(f"{shard}: missing, duplicate or unexpected mutant in outcome roster")
    if len(versions) != 1:
        raise ValueError("Shard tool versions differ")
    return counts


def verify_native_phases(shard, report, targets, tool_version):
    """Check the commands actually recorded by the pinned mutator."""
    if report["cargo_mutants_version"] != tool_version:
        raise ValueError(f"{shard}: native outcome tool version differs from producer")
    selectors = [arg for target in targets.splitlines() for arg in ("--test", target)]
    suffix = ["--locked", "--lib", "--bins", *selectors, "--", "--include-ignored"]
    for row in report["outcomes"]:
        phases = row["phase_results"]
        summary = row["summary"]
        expected = ["Build"] if summary == "Unviable" else ["Build", "Test"]
        if [phase["phase"] for phase in phases] != expected:
            raise ValueError(f"{shard}: incomplete native build or test phases for {summary}")
        statuses = [phase["process_status"] for phase in phases]
        if ("Timeout" in statuses or (statuses[-1] == "Success") != (summary == "Success")
                or len(statuses) == 2 and statuses[0] != "Success"):
            raise ValueError(f"{shard}: native phase status contradicts {summary}")
        for phase in phases:
            argv = phase["argv"]
            build = phase["phase"] == "Build"
            if (len(argv) < 2 or Path(argv[0]).name != "cargo" or argv[1] != "test"
                    or argv.count("--workspace") != 1 or argv.count("--all-features") != 1
                    or ("--no-run" in argv) != build):
                raise ValueError(f"{shard}: native command did not use the required workspace mode")
            if not build and argv[-len(suffix):] != suffix:
                raise ValueError(f"{shard}: native test differs from the required CPU selectors")
        log = Path(row["log_path"])
        if log.parent != Path("log") or not (shard / "mutants.out" / log).is_file():
            raise ValueError(f"{shard}: missing native phase log")


def verify_hosted_shards(roster, shards, source_commit, workflow_run_id, lock_digest, cpu_targets,
                         expected_shards=16):
    """Bind the complete raw outcomes to one trusted workflow and checked-out inputs."""
    if len(shards) != expected_shards:
        raise ValueError(f"Expected {expected_shards} mutation shards, found {len(shards)}")
    provenance = (roster.parent / "provenance.txt").read_text(encoding="utf-8")
    if not provenance.startswith(f"{source_commit}\n"):
        raise ValueError("The full roster has the wrong source revision")
    lines = provenance.splitlines()
    if f"{lock_digest}  Cargo.lock" not in lines:
        raise ValueError("The full roster has the wrong Cargo lock digest")
    targets = cpu_targets.read_bytes()
    selector_digest = hashlib.sha256(targets).hexdigest()
    if f"{selector_digest}  target/assurance/selected-targets.txt" not in lines:
        raise ValueError("The full roster has the wrong CPU selector digest")
    versions = [line.removeprefix("cargo-mutants ") for line in lines if line.startswith("cargo-mutants ")]
    if len(versions) != 1:
        raise ValueError("The full roster lacks an exact producer tool version")
    for directory in (roster.parent, *shards):
        if (directory / "workflow-run-id.txt").read_text(encoding="utf-8").strip() != workflow_run_id:
            raise ValueError(f"{directory}: unexpected workflow run")
        if (directory / "cpu-targets.txt").read_bytes() != targets:
            raise ValueError(f"{directory}: CPU selectors differ from the checked-out suite")
    reports = []
    for shard in shards:
        if (shard / "provenance.txt").read_text(encoding="utf-8") != provenance:
            raise ValueError(f"{shard}: archived source, lock, CPU selectors or tool provenance differs")
        if (shard / "exit.status").read_text(encoding="utf-8").strip() != "0":
            raise ValueError(f"{shard}: mutation command exit status did not pass")
        if read_json(shard / "mutants.out/mutants.json") != read_json(shard / "list.json"):
            raise ValueError(f"{shard}: native execution list differs from its independent listing")
        report = read_json(shard / "mutants.out/outcomes.json")
        if report != read_json(shard / "outcomes.json"):
            raise ValueError(f"{shard}: copied receipt differs from native outcomes")
        reports.append((shard, report))
    counts = verify_shards(roster, shards)
    for shard, report in reports:
        verify_native_phases(shard, report, targets.decode(), versions[0])
    return counts


def main(argv=None):
    """Check a full JSON listing and numbered shard directories in index order."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("roster", type=Path, help="Independent full cargo mutants --list --json output")
    parser.add_argument("shards", type=Path, nargs="+", help="Directories with list.json and outcomes.json, in index order")
    parser.add_argument("--source-commit", help="Current hosted source revision")
    parser.add_argument("--workflow-run-id", help="Current trusted workflow run")
    parser.add_argument("--lock-digest", help="Cargo.lock digest from the checked-out revision")
    parser.add_argument("--cpu-targets", type=Path, help="CPU integration targets classified from the checkout")
    args = parser.parse_args(argv)
    try:
        provenance = (args.source_commit, args.workflow_run_id, args.lock_digest, args.cpu_targets)
        if all(provenance):
            counts = verify_hosted_shards(args.roster, args.shards, *provenance)
        elif any(provenance):
            raise ValueError("Hosted mode requires source, workflow run, lock and CPU selectors")
        else:
            counts = verify_shards(args.roster, args.shards)
        print(json.dumps(counts, sort_keys=True))
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"Mutation shard evidence: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

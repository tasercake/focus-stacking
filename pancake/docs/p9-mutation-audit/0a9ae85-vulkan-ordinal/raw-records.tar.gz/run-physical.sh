#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/vulkan-ordinal"
record="$base/physical"
test -s "$base/physical-lease.txt"
test -z "$(git status --porcelain=v1)"
git diff --exit-code 0a9ae85 HEAD -- pancake/src pancake/Cargo.lock
for arm in stock mutant; do
  grep -qx 0 "$base/$arm/exit.txt"
  sha256sum -c "$base/$arm/retained-elf.sha256"
done

unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS VK_ICD_FILENAMES VK_ADD_DRIVER_FILES
unset CUDA_VISIBLE_DEVICES PANCAKE_RUNTIME LD_LIBRARY_PATH
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
export XDG_RUNTIME_DIR="$record/runtime"
mkdir -m 700 "$record" "$XDG_RUNTIME_DIR"
trap 'status=$?; { date -u +%FT%TZ; printf "exit=%s\n" "$status"; } > "$record/terminal.txt"' EXIT
sha256sum -c "$root/pancake/docs/p10-registration-luma-lattice/native-f034185/vulkan-icd.sha256"
sha256sum "$VK_DRIVER_FILES" > "$record/icd.sha256"
nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$record/nvidia.txt"
vulkaninfo --summary > "$record/vulkaninfo.txt" 2> "$record/vulkaninfo.stderr"
test "$(grep -c '^GPU[0-9]' "$record/vulkaninfo.txt")" = 1
grep -qF 'PHYSICAL_DEVICE_TYPE_DISCRETE_GPU' "$record/vulkaninfo.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$record/vulkaninfo.txt"
grep -qE '^NVIDIA GeForce RTX 3090, GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac, 00000000:01:00.0, ' "$record/nvidia.txt"
test "$(wc -l < "$record/nvidia.txt")" = 1

run_probe() (
  arm=$1 phase=$2 test_name=$3 expected_status=$4
  run="$record/$phase"
  mkdir -m 700 "$run"
  export HOME="$run/home" XDG_CACHE_HOME="$run/cache" TMPDIR="$run/tmp"
  mkdir -m 700 "$HOME" "$XDG_CACHE_HOME" "$TMPDIR"
  export PANCAKE_TEST_GPU_RUNTIME=wgpu
  export PANCAKE_TEST_RUNTIME_RECEIPT="$run/runtime.txt"
  read -r digest binary < "$base/$arm/retained-elf.sha256"
  cd "$run"
  cmd=(timeout --signal=TERM --kill-after=5s 20s taskset -c 8,9 "$binary"
    --exact "$test_name" --test-threads=1 --nocapture)
  printf '%s\n' "cwd=$PWD" "ELF_SHA256=$digest" "HOME=$HOME" "XDG_CACHE_HOME=$XDG_CACHE_HOME" "TMPDIR=$TMPDIR" "XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR" "VK_DRIVER_FILES=$VK_DRIVER_FILES" 'PANCAKE_TEST_GPU_RUNTIME=wgpu' "PANCAKE_TEST_RUNTIME_RECEIPT=$PANCAKE_TEST_RUNTIME_RECEIPT" > command.txt
  printf '%q ' "${cmd[@]}" >> command.txt
  printf '\n' >> command.txt
  status=0
  "${cmd[@]}" > stdout.log 2> stderr.log || status=$?
  printf '%s\n' "$status" > exit.txt
  test "$status" -eq "$expected_status" || exit 1
  grep -qxF 'runtime=wgpu-vulkan' runtime.txt
  grep -qxF 'device=NVIDIA GeForce RTX 3090' runtime.txt
  grep -qxF 'fingerprint=spirv_4318_8708' runtime.txt
  grep -qxF 'device_pci_address=Some("0000:01:00.0")' runtime.txt
  grep -qxF 'physical_gpu=true' runtime.txt
  grep -qxF 'fallback_reason=None' runtime.txt
)
test_name=explicit_wgpu_rejects_first_absent_physical_ordinal
outcome=0
run_probe stock positive explicit_gpu_override_completes_on_named_runtime 0 || outcome=1
run_probe stock stock "$test_name" 0 || outcome=1
run_probe mutant exact-mutant "$test_name" 101 || outcome=1
run_probe stock restored-stock "$test_name" 0 || outcome=1
grep -qF 'absent wgpu Vulkan GPU index 1 ran on NVIDIA GeForce RTX 3090 at Some("0000:01:00.0"); runtime=wgpu-vulkan, physical=true, fallback=None, samples=[2, 8, 14]' \
  "$record/exact-mutant/stderr.log" "$record/exact-mutant/stdout.log" || outcome=1
exit "$outcome"

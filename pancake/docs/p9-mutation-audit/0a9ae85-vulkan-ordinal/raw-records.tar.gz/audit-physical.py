"""Audit actual process exits and decode the Rust test harness error string."""

import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
[device_line] = (root / "nvidia.txt").read_text().splitlines()
name, uuid, pci, driver = [field.strip() for field in device_line.split(",")]
assert name == "NVIDIA GeForce RTX 3090"
assert uuid == "GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac"
assert pci == "00000000:01:00.0"
summary = (root / "vulkaninfo.txt").read_text()
assert sum(line.startswith("GPU") and line.endswith(":") for line in summary.splitlines()) == 1
assert "PHYSICAL_DEVICE_TYPE_DISCRETE_GPU" in summary
assert name in summary
[terminal_time, terminal_exit] = (root / "terminal.txt").read_text().splitlines()
assert terminal_exit == "exit=1"

phase_status = {}
for phase, expected in (
    ("positive", 0), ("stock", 0), ("exact-mutant", 101), ("restored-stock", 0),
):
    arm = root / phase
    status = int((arm / "exit.txt").read_text())
    assert status == expected, (phase, status)
    phase_status[phase] = status
    receipt = (arm / "runtime.txt").read_text().splitlines()
    assert {
        "runtime=wgpu-vulkan", "backend=gpu", f"device={name}",
        'device_pci_address=Some("0000:01:00.0")',
        "fingerprint=spirv_4318_8708", "physical_gpu=true", "fallback_reason=None",
    }.issubset(receipt), (phase, receipt)
    output = (arm / "stdout.log").read_text()
    stderr = (arm / "stderr.log").read_text()
    if expected == 0:
        assert "1 passed; 0 failed" in output, phase
        assert not stderr, (phase, stderr)
        continue

    assert "0 passed; 1 failed" in output
    [diagnostic] = [line.removeprefix("Error: ") for line in stderr.splitlines() if line.startswith("Error: ")]
    decoded = json.loads(diagnostic)
    assert decoded == (
        'absent wgpu Vulkan GPU index 1 ran on NVIDIA GeForce RTX 3090 at Some("0000:01:00.0"); '
        'runtime=wgpu-vulkan, physical=true, fallback=None, samples=[2, 8, 14]'
    )

print(json.dumps({
    "physical_scope": {"api": "wgpu-vulkan", "adapter_count": 1, "pci": pci,
                       "uuid": uuid, "model": name, "driver": driver},
    "requested_first_absent_ordinal": 1,
    "stock_rejected_absent_ordinal": True,
    "mutant_completed_blur_on_wrong_ordinal": [2, 8, 14],
    "decoded_mutant_assertion": decoded,
    "original_wrapper_exit": 1,
    "original_wrapper_issue": "Fixed-string comparison omitted escaping introduced by Rust test error formatting.",
    "observed_process_exits": phase_status,
    "device_terminal_utc": terminal_time,
    "canonical_cpu_mutant_gate_closed_by_this_gpu_replay": False,
}, indent=2))

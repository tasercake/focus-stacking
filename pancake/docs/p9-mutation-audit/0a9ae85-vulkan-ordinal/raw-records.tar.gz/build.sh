#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/vulkan-ordinal"
record="$base/$1"
mkdir "$record"
cd "$root/pancake"
unset CUDARC_CUDA_VERSION RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$PWD/target/vulkan-ordinal"
git rev-parse HEAD 'HEAD^{tree}' > "$record/source-tree.txt"
git diff --binary -- src/runtime/portable.rs > "$record/product-diff.patch"
sha256sum Cargo.lock src/runtime/portable.rs tests/gpu_runtime_contract.rs > "$record/source.sha256"
rustc +1.100.0 -Vv > "$record/rustc.txt"
cmd=(taskset -c 8,9 cargo +1.100.0 test --locked --offline --release -p pancake
  --test gpu_runtime_contract --no-run --message-format json)
printf '%s\n' "cwd=$PWD" "CARGO_TARGET_DIR=$CARGO_TARGET_DIR CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true RUSTC_WRAPPER=unset" > "$record/command.txt"
printf '%q ' "${cmd[@]}" >> "$record/command.txt"
printf '\n' >> "$record/command.txt"
trap 'status=$?; printf "%s\n" "$status" > "$record/exit.txt"; date -u +%FT%TZ > "$record/end.txt"' EXIT
date -u +%FT%TZ > "$record/start.txt"
/usr/bin/time -v -o "$record/resources.txt" "${cmd[@]}" > "$record/build.jsonl" 2> "$record/build.log"
testbin=$(jq -er 'select(.reason=="compiler-artifact" and .target.name=="gpu_runtime_contract" and .profile.test and .executable) | .executable' "$record/build.jsonl")
test -x "$testbin"
cp --reflink=auto "$testbin" "$record/gpu-runtime-contract"
sha256sum "$record/gpu-runtime-contract" > "$record/test-elf.sha256"
readelf -n "$record/gpu-runtime-contract" > "$record/elf-notes.txt"

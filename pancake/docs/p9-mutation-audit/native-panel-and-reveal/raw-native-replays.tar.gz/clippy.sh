#!/usr/bin/env bash
set -euo pipefail
work=$(pwd)
proof="$work/artifacts/native-mutation-seams"
cd pancake
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$work/pancake/target/native-mutation-seams"
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER
unset DISPLAY WAYLAND_DISPLAY WAYLAND_SOCKET DBUS_SESSION_BUS_ADDRESS AT_SPI_BUS_ADDRESS
mkdir "$proof/policy"
cargo metadata --locked --format-version 1 --all-features > "$proof/policy/metadata.json"
python3 scripts/dependency_policy.py --config deny.toml --ledger dependency-policy.json \
    --metadata "$proof/policy/metadata.json" --effective-config "$proof/policy/deny-effective.toml" \
    --license-inventory "$proof/policy/licenses.json" --clippy-config clippy.toml \
    --effective-clippy-dir "$proof/policy/clippy" > "$proof/policy/generator.log" 2>&1
export CLIPPY_CONF_DIR="$proof/policy/clippy"
cmd=(cargo clippy --locked -p pancake-gui --all-targets --all-features -- -D warnings)
printf '%q ' "${cmd[@]}" > "$proof/clippy.argv"
printf '\n' >> "$proof/clippy.argv"
status=0
timeout --signal=TERM --kill-after=10s 360s "${cmd[@]}" > "$proof/clippy.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$proof/clippy.exit"
tail -35 "$proof/clippy.log"
exit "$status"

#!/usr/bin/env bash
set -euo pipefail
work=$(pwd)
proof="$work/artifacts/native-mutation-seams"
expected=ad81502d1e9b92c3a0d9a188691e76f12a673db3
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain=v1)"
export PATH="/tmp/pancake-tools/bin:$PATH"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$work/pancake/target/native-mutation-seams"
export PANCAKE_COMPUTE_CACHE_DIR="$CARGO_TARGET_DIR/compute-cache"
unset DISPLAY WAYLAND_DISPLAY WAYLAND_SOCKET DBUS_SESSION_BUS_ADDRESS AT_SPI_BUS_ADDRESS
unset GDK_BACKEND GTK_MODULES RUST_TEST_THREADS PANCAKE_RUNTIME PANCAKE_TEST_GPU_RUNTIME CONFORMANCE_EVENTS_PATH
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER
unset TSAN_OPTIONS ASAN_OPTIONS LSAN_OPTIONS UBSAN_OPTIONS PANCAKE_TEST_GTK_UNAVAILABLE_CHILD
cd pancake
{
    git rev-parse HEAD
    git rev-parse HEAD:pancake
    sha256sum Cargo.lock assurance-platforms.json crates/pancake-gui/src/{desktop_menu.rs,panel/linux.rs}
    rustc -vV
    cargo -V
    cargo mutants --version
    sha256sum "$(command -v cargo-mutants)"
    taskset -pc "$$"
    printf 'Cargo build jobs %s\nNo display, desktop bus, GPU override, or inherited Rust flags.\n' "$CARGO_BUILD_JOBS"
} > "$proof/identity.txt"
cargo metadata --locked --no-deps --format-version 1 > "$proof/metadata.json"
python3 scripts/assurance_targets.py "$proof/metadata.json" cpu > "$proof/cpu-targets.txt"
args=(--lib --bins)
while IFS= read -r target; do args+=(--test "$target"); done < "$proof/cpu-targets.txt"
cmd=(cargo mutants --workspace --test-workspace false --cargo-arg=--workspace --cap-lints true --all-features --in-place --timeout 60 --build-timeout 180 --jobserver-tasks 2 --no-shuffle)

run_mutant() {
    local scope=$1 name=$2 filter=$3 status=0
    local file="$proof/$scope.stdout.log"
    "${cmd[@]}" --file "$name" --re "$filter" --list --json > "$proof/$scope.list.json"
    python3 - "$proof/$scope.list.json" <<'PY'
import json, sys
from pathlib import Path
items=json.loads(Path(sys.argv[1]).read_text())
assert isinstance(items, list) and len(items) == 1, items
PY
    local run=("${cmd[@]}" --file "$name" --re "$filter" --output "$proof/$scope"
        -- --locked "${args[@]}" -- --include-ignored)
    printf '%q ' "${run[@]}" > "$proof/$scope.argv"
    printf '\n' >> "$proof/$scope.argv"
    date -Iseconds > "$proof/$scope.start.txt"
    "${run[@]}" > "$file" 2>&1 || status=$?
    printf '%s\n' "$status" > "$proof/$scope.exit"
    date -Iseconds > "$proof/$scope.end.txt"
    if [[ -n "$(git status --porcelain=v1)" ]]; then
        git status --porcelain=v1 > "$proof/$scope.unrestored.txt"
        return 1
    fi
    cat "$file"
    return "$status"
}

run_mutant reveal crates/pancake-gui/src/desktop_menu.rs \
    'replace reveal -> Result<\(\), String> with Ok\(\(\)\)$'
run_mutant build crates/pancake-gui/src/panel/linux.rs \
    'replace build -> Result<\(Dialog, FileChooserWidget, Entry\), String> with Ok\(\(Default::default\(\), Default::default\(\), Default::default\(\)\)\)$'

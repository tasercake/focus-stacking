#!/usr/bin/env python3
"""Verify and summarize the two exact cargo-mutants native receipts."""

import hashlib
import json
import re
import sys
from pathlib import Path

root, destination = map(Path, sys.argv[1:3])


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


old = json.loads((root/'original-patch-check.json').read_text())
assert (root/'clippy.exit').read_text().strip() == '0'
receipt = {
    'tested_source': (root/'identity.txt').read_text().splitlines()[0],
    'previous_native_shard': '287828a, 255/256, e464093 retained archive',
    'selected_cases': {},
    'cargo_mutants': '27.1.0',
    'working_cpu_indices': [0, 1],
    'max_cargo_jobs': 2,
    'cpu_integration_targets': (root/'cpu-targets.txt').read_text().splitlines(),
    'clippy_exit': 0,
    'source_and_dependency_policy_sha256': digest(root/'source-policy.log'),
    'raw_archive_sha256': digest(destination/'raw-native-replays.tar.gz'),
}
expected = {
    'reveal': ('desktop_menu::tests::reveal_reports_a_missing_source', 'Revealing a missing source reported success.'),
    'build': ('panel::linux::tests::unavailable_display_rejects_native_panel', 'GTK has not been initialized. Call `gtk::init` first.'),
}
for name, (test_name, real_diagnostic) in expected.items():
    output = root/name/'mutants.out'
    result = json.loads((output/'outcomes.json').read_text())
    baseline, mutation = result['outcomes']
    assert (root/f'{name}.exit').read_text().strip() == '0'
    assert result['total_mutants'] == result['caught'] == 1
    assert result['missed'] == result['unviable'] == result['timeout'] == 0
    assert baseline['summary'] == 'Success' and mutation['summary'] == 'CaughtMutant'
    assert [p['process_status'] for p in mutation['phase_results']] == ['Success', {'Failure': 101}]
    actual_diff = digest(output/mutation['diff_path'])
    assert actual_diff == old[name]['native_diff_sha256']
    baseline_log = (output/baseline['log_path']).read_text()
    mutated_log = (output/mutation['log_path']).read_text()
    assert re.search(r'^test result: ok\. 18 passed; 0 failed; 0 ignored;', baseline_log, re.MULTILINE)
    groups = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', baseline_log, re.MULTILINE)
    assert len(groups) == 19
    assert f'test {test_name} ... ok' in baseline_log
    assert f'test {test_name} ... FAILED' in mutated_log and real_diagnostic in mutated_log
    receipt['selected_cases'][name] = {
        'name': old[name]['native_name'],
        'native_diff_sha256': actual_diff,
        'process_exit': 0,
        'native_verdict': mutation['summary'],
        'mutated_test_process_exit': 101,
        'intended_failing_test': test_name,
        'observed_diagnostic': real_diagnostic,
        'baseline_cpu_tests_passed': sum(map(int,groups)),
        'baseline_executable_targets': len(groups),
        'baseline_gui_tests_passed': 18,
        'baseline_log_sha256': digest(output/baseline['log_path']),
        'mutated_log_sha256': digest(output/mutation['log_path']),
        'start': (root/f'{name}.start.txt').read_text().strip(),
        'end': (root/f'{name}.end.txt').read_text().strip(),
    }
(destination/'receipt.json').write_text(json.dumps(receipt,indent=2) + '\n')
print([(name, entry['native_verdict'], entry['baseline_cpu_tests_passed']) for name, entry in receipt['selected_cases'].items()])

taskset --cpu-list 20\,21 cargo +1.100.0 build --offline --locked --release -p pancake-cli --jobs 2 

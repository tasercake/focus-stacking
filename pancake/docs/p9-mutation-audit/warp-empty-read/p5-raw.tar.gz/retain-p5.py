"""Seal the bounded warp candidate and mapped qualification evidence."""

import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile


def read_json(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


proof = Path('artifacts/warp-readback-review')
folder = Path('pancake/docs/p9-mutation-audit/warp-empty-read')
archive = folder / 'p5-raw.tar.gz'
cpu = read_json(proof / 'p5-cpu/audit.json')
physical = read_json(proof / 'p5-physical/audit.json')
allocation = read_json(proof / 'warp-maps-receipt.json')
control, candidate = (allocation['variants'][name] for name in ('control', 'candidate'))
actual = cpu['selected'] + physical['selected']
assert len(actual) == len(set(actual)) == 64
assert set(actual) == set((proof / 'p5-all.txt').read_text().splitlines())
assert [cpu['bit_exact_files'], physical['bit_exact_files']] == [63, 1]
assert cpu['control_receipt_sha256'] == physical['control_receipt_sha256']
assert cpu['candidate_binary_sha256'] == physical['candidate_binary_sha256'] == candidate['binary_sha256']
assert cpu['exact_current']['target_commit'] == physical['exact_current']['target_commit']
assert cpu['exact_current']['suite_source_sha256'] == physical['exact_current']['suite_source_sha256']
assert [control['warp_full_frame_mapping_count'], candidate['warp_full_frame_mapping_count']] == [2, 2]
assert sorted(row['mapping_bytes'] for row in candidate['warp_full_frame_mappings']) == [12635148, 12635152]
files = [
    'release-source.txt', 'release-tree.txt', 'release-contract.sha256', 'release-build.command',
    'release-build.start', 'release-build.end', 'release-build.status', 'release-build.log',
    'release-binary.sha256', 'frozen-contract.json', 'p5-all.txt', 'p5-cpu.txt', 'p5-physical.txt',
    'run-p5.sh', 'audit-p5.py', 'retain-p5.py', '8694b55-host-release-receipt.json',
    '8694b55-host-provenance.json', 'physical-host.csv', 'physical-icd.sha256', 'gdb-version.txt',
    'warp-maps.gdb', 'run-warp-maps.py', 'warp-maps-receipt.json', 'warp-maps-summary.log',
    'warp-mmap-only.gdb', 'warp-mmap-only-summary.log',
]
for arm in ('warp-maps-control', 'warp-maps-candidate', 'warp-mmap-only-control'):
    files.extend(f'{arm}/{name}' for name in ('command.txt', 'events.jsonl', 'gdb.log', 'status'))
for lane_name, audit in (('p5-cpu', cpu), ('p5-physical', physical)):
    files.extend(f'{lane_name}/{name}' for name in ('command.sh', 'end', 'start', 'status', 'run.log', 'audit.json'))
    files.extend(f'{lane_name}/suite/{name}' for name in ('report.json', 'provenance.json', 'junit.xml'))
    for case_id in audit['selected']:
        location = f'{lane_name}/suite/cases/{case_id}'
        files.append(f'{location}/result.json')
        files.extend(f'{location}/call-01/{name}' for name in ('command.json', 'events.jsonl', 'stderr.txt', 'stdout.txt'))
assert len(set(files)) == len(files)
with archive.open('wb') as output, gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w|') as tar:
        for name in sorted(files):
            path = proof / name
            file_info = tar.gettarinfo(str(path), arcname=name)
            file_info.uid = file_info.gid = file_info.mtime = 0
            file_info.uname = file_info.gname = ''
            with path.open('rb') as raw:
                tar.addfile(file_info, raw)
assert subprocess.run(['gzip', '--test', str(archive)]).returncode == 0
manifest = {
    'source_revision': cpu['exact_current']['target_commit'],
    'source_tree': (proof / 'release-tree.txt').read_text().strip(),
    'binary_sha256': candidate['binary_sha256'],
    'contracts': {'frozen': read_json(proof / 'frozen-contract.json'),
                  'suite_source_sha256': cpu['exact_current']['suite_source_sha256'],
                  'target_descriptor_sha256': cpu['exact_current']['target_descriptor_sha256'],
                  'uv_lock_sha256': cpu['exact_current']['uv_lock_sha256'],
                  'cargo_lock_sha256': sha(Path('pancake/Cargo.lock')),
                  'case_roadmap_sha256': sha(Path('pancake-conformance/src/pancake_conformance/adapters/pancake/case-roadmap.json'))},
    'locked_release_build': {'command': (proof / 'release-build.command').read_text().strip(),
                             'start': (proof / 'release-build.start').read_text().strip(),
                             'end': (proof / 'release-build.end').read_text().strip(),
                             'exit': int((proof / 'release-build.status').read_text())},
    'case_accounting': {'expected_unique': len(actual), 'passed_cpu': len(cpu['selected']),
                        'passed_physical_vulkan': len(physical['selected']), 'failed': 0,
                        'unsupported': 0, 'skipped_or_unrun': 0,
                        'bit_exact_exports': len(actual), 'exact_transform_events': len(actual)},
    'baseline': {'source_revision': cpu['control_source_revision'], 'binary_sha256': control['binary_sha256'],
                 'release_receipt_sha256': cpu['control_receipt_sha256']},
    'actual_runtimes': {'cpu': cpu['case_comparisons'][0]['runtime'],
                        'physical_vulkan': physical['case_comparisons'][0]['runtime'],
                        'nvidia_inventory': (proof / 'physical-host.csv').read_text().strip()},
    'matching_host_allocation_requests': {'case': allocation['case'], 'shape': allocation['input_shape'],
        'input_sha256': allocation['inputs'], 'tile_geometry': allocation['tile_geometry'],
        'request_bytes_each_arm': [12635148, 12635152],
        'probe': 'GDB entry breakpoint at __libc_malloc and verified warp caller',
        'same_output_sha256': candidate['output_sha256']},
    'archive': {'file_count': len(files), 'sha256': sha(archive)},
}
(folder / 'p5-receipt.json').write_text(json.dumps(manifest, indent=2) + '\n')

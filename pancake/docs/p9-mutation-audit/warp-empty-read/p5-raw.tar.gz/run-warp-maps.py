"""Attribute matched full-frame mapping sizes to genuine native warp callers."""

import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def map_records(log):
    packed = []
    current = None
    for line in log.splitlines():
        match = re.fullmatch(r'packed-map len=(\d+)', line)
        if match:
            current = {'mapping_bytes': int(match[1]), 'stack': []}
            packed.append(current)
        elif current is not None and re.match(r'^#\d+\s', line):
            current['stack'].append(line)
    assert '[Inferior ' in log and 'exited normally' in log
    maps = [item for item in packed if any('pancake::registration::kernels::warp (' in frame
            for frame in item['stack'])]
    assert maps, 'No full frame mapping was observed with a verified native warp caller'
    return maps


proof = Path('artifacts/warp-readback-review').resolve()
case = proof / 'p5-cpu/suite/cases/algorithms.recovery.cascade.cpu'
previous = read_json(case / 'call-01/command.json')['argv']
paths = previous[previous.index('--input') + 1:previous.index('--output')]
options = previous[previous.index('--output') + 2:]
assert '--cpu' in options and '--max-precision' in options
input_paths = list(map(Path, paths))
assert all(path.parent == case for path in input_paths)
receipt = {'case': 'algorithms.recovery.cascade.cpu', 'input_shape': [257, 4097, 3],
           'inputs': {path.name: sha(path) for path in input_paths},
           'tile_geometry': {'rgb_total_samples': 4097 * 257 * 3,
                             'tile_samples': 262144, 'full_tile_count': 12, 'tail_samples': 13059},
           'full_frame_logical_bytes': 4097 * 257 * 3 * 4, 'variants': {}}
expected_before = 'e5fa8d2cb31a55071c999a83e35b4c3d31d6c569717b7baca328c16ea7ed4b6f'
expected_after = (proof / 'release-binary.sha256').read_text().split()[0]
for variant, binary, expected in (
    ('control', proof / 'pancake-cli-control-8694b55', expected_before),
    ('candidate', Path('pancake/target/warp-readback-release/release/pancake-cli').resolve(), expected_after),
):
    assert sha(binary) == expected, variant
    work = proof / f'warp-maps-{variant}'
    work.mkdir()
    env = os.environ.copy()
    for name in ('DISPLAY', 'WAYLAND_DISPLAY', 'DBUS_SESSION_BUS_ADDRESS', 'PANCAKE_RUNTIME',
                 'PANCAKE_DEFAULT_DEVICE', 'LD_LIBRARY_PATH', 'VK_ICD_FILENAMES', 'VK_ADD_DRIVER_FILES'):
        env.pop(name, None)
    env['CONFORMANCE_EVENTS_PATH'] = str(work / 'events.jsonl')
    env['VK_DRIVER_FILES'] = '/usr/share/vulkan/icd.d/lvp_icd.json'
    env['PANCAKE_STATE_DIR'] = str(work)
    env['PANCAKE_COMPUTE_CACHE_DIR'] = str(work / 'cache')
    output = work / 'assembled.png'
    cmd = ['timeout', '--signal=TERM', '--kill-after=5s', '90s', 'taskset', '--cpu-list', '20,21',
           'gdb', '--batch', '-x', str(proof / 'warp-maps.gdb'), '--args', str(binary), '--input',
           *paths, '--output', str(output), *options]
    (work / 'command.txt').write_text(shlex.join(cmd) + '\n')
    with (work / 'gdb.log').open('w') as log:
        completed = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
    (work / 'status').write_text(str(completed.returncode) + '\n')
    assert completed.returncode == 0, variant
    maps = map_records((work / 'gdb.log').read_text())
    complete = [event for line in (work / 'events.jsonl').read_text().splitlines()
                if (event := json.loads(line))['event'] == 'stack_complete']
    assert len(complete) == 1 and complete[0]['runtime'] == complete[0]['actual_backend'] == 'cpu'
    assert complete[0]['completed'] is True and complete[0]['fallback_reason'] is None
    receipt['variants'][variant] = {'binary_sha256': expected, 'output_sha256': sha(output),
                                    'transforms': complete[0]['sequential_transforms'],
                                    'warp_full_frame_mapping_count': len(maps), 'warp_full_frame_mappings': maps}
control, candidate = (receipt['variants'][name] for name in ('control', 'candidate'))
for field in ('output_sha256', 'transforms', 'warp_full_frame_mapping_count'):
    assert candidate[field] == control[field], (field, candidate[field], control[field])
assert sorted(row['mapping_bytes'] for row in candidate['warp_full_frame_mappings']) == sorted(
       row['mapping_bytes'] for row in control['warp_full_frame_mappings'])
assert receipt['inputs'] == {path.name: sha(path) for path in input_paths}
assert control['output_sha256'] == sha(case / 'output-01.png')
(proof / 'warp-maps-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(f"Both exact native CPU binaries used {candidate['warp_full_frame_mapping_count']} "
      'matching full-frame malloc requests with traced warp call stacks and exported identical PNG bytes.')

"""Verify exact P5 selection, genuine app commands, events and matched output bytes."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


def read_json(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def run_report(suite, ids, revision, exact_selection=True):
    report = read_json(suite / 'report.json')
    provenance = read_json(suite / 'provenance.json')
    actual_case_ids = [case['id'] for case in report['cases']]
    assert len(actual_case_ids) == len(set(actual_case_ids))
    if exact_selection:
        assert set(actual_case_ids) == set(provenance['cases']) == set(ids)
        assert report['complete'] and report['status'] == 'passed'
        assert report['completed_count'] == report['selected_count'] == len(ids)
        assert report['counts'] == {'passed': len(ids), 'failed': 0, 'unsupported': 0}
    assert set(ids).issubset(actual_case_ids)
    assert set(ids).issubset(provenance['cases'])
    assert provenance['target_commit'] == provenance['suite_commit'] == revision
    assert not provenance['target_dirty'] and not provenance['suite_dirty']
    per_case = {case['id']: case for case in report['cases']}
    assert all(per_case[case_id]['status'] == 'passed' for case_id in ids)
    return provenance


def call_record(suite, case_id, backend):
    case = suite / 'cases' / case_id
    result = read_json(case / 'result.json')
    assert result['id'] == case_id and result['status'] == 'passed'
    calls = list(case.glob('call-*/command.json'))
    assert len(calls) == 1, (case_id, len(calls))
    command = read_json(calls[0])
    evidence = calls[0].with_name('events.jsonl')
    events = [json.loads(line) for line in evidence.read_text().splitlines()]
    done = [event for event in events if event['event'] == 'stack_complete']
    assert len(done) == 1, (case_id, done)
    complete = done[0]
    flag, physical = {'cpu': ('--cpu', False), 'gpu': ('--gpu', True)}[backend]
    assert flag in command['argv']
    assert complete['actual_backend'] == backend and complete['completed'] is True
    expected_runtime = {'cpu': 'cpu', 'gpu': 'wgpu-vulkan'}[backend]
    assert complete['runtime'] == expected_runtime, complete
    assert complete['physical_gpu'] is physical
    assert complete['fallback_reason'] is None
    if physical:
        assert 'NVIDIA GeForce RTX 3090' in complete['device']
        assert complete['device_pci_address'] == '0000:01:00.0'
    output_index = command['argv'].index('--output') + 1
    output = case / Path(command['argv'][output_index]).name
    inputs = result['notes']['requests']
    assert len(inputs) == 1, (case_id, inputs)
    input_info = inputs[0]
    transforms = complete.get('alignment_transforms', {})
    shape = [Path(name).name for name in transforms]
    assert len(shape) == len(set(shape))
    return {
        'id': case_id,
        'input': input_info,
        'output': {'name': output.name, 'sha256': sha(output), 'bytes': output.stat().st_size},
        'alignment_transforms': {name: transforms[key] for name, key in zip(shape, transforms)},
        'sequential_transforms': complete.get('sequential_transforms'),
        'command_sha256': sha(calls[0]),
        'events_sha256': sha(evidence),
        'runtime': {'backend': backend, 'runtime': expected_runtime, 'device': complete['device'],
                    'device_fingerprint': complete['device_fingerprint'],
                    'device_pci_address': complete['device_pci_address'], 'physical_gpu': physical,
                    'fallback_reason': complete['fallback_reason']},
    }


mode = sys.argv[1]
proof = Path('artifacts/warp-readback-review')
revision = (proof / 'release-source.txt').read_text().strip()
candidate = proof / f'p5-{mode}' / 'suite'
ids = (proof / f'p5-{mode}.txt').read_text().splitlines()
provenance = run_report(candidate, ids, revision)
base = Path('/home/krishna/Documents/focus-stacking/artifacts/p9-8694b55/h/run')
base_revision = '8694b555666a1ddf4051e2839bbced4bcc625859'
base_provenance = run_report(base, ids, base_revision, exact_selection=False)
for field in ('contract_version', 'suite_source_sha256', 'target_descriptor_sha256', 'uv_lock_sha256'):
    assert provenance[field] == base_provenance[field]
if mode == 'cpu':
    control_info = [call_record(base, case_id, 'cpu') for case_id in ids]
else:
    assert mode == 'physical'
    control_info = [call_record(base, case_id, 'gpu') for case_id in ids]
records = [call_record(candidate, case_id, 'cpu' if mode == 'cpu' else 'gpu') for case_id in ids]
for record, control in zip(records, control_info):
    for field in ('id', 'input', 'output', 'alignment_transforms', 'sequential_transforms', 'runtime'):
        assert record[field] == control[field], (record['id'], field, record[field], control[field])
base_receipt = read_json(base.parent / 'release-receipt.json')
expected_phase = 'P5 native CPU' if mode == 'cpu' else 'P5 physical NVIDIA Vulkan'
audit = {
    'lane': expected_phase, 'selected': ids, 'exact_current': provenance,
    'candidate_binary_sha256': (proof / 'release-binary.sha256').read_text().split()[0],
    'control_source_revision': base_revision, 'control_receipt': str(base.parent / 'release-receipt.json'),
    'control_receipt_sha256': sha(base.parent / 'release-receipt.json'),
    'control_cli': base_receipt['executables']['cli'],
    'case_comparisons': records, 'control_case_comparisons': control_info,
    'bit_exact_files': len(records), 'exact_transform_events': len(records),
}
(proof / f'p5-{mode}' / 'audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(f'{expected_phase}: {len(records)}/{len(ids)} passed, with exact prior PNG/TIFF bytes and transforms')

set confirm off
set pagination off
set debuginfod enabled off
set disable-randomization off
set breakpoint pending on
break __libc_malloc if $rdi >= 12635148 && $rdi < 12643340
commands
silent
printf "packed-map len=%ld\n", $rdi
bt 14
continue
end
run

#!/usr/bin/env bash
set -euo pipefail
lane=${1:?CPU or physical lane required}
proof="$PWD/artifacts/warp-readback-review"
case "$lane" in
    cpu) vk_driver=/usr/share/vulkan/icd.d/lvp_icd.json ;;
    physical) vk_driver=/usr/share/vulkan/icd.d/nvidia_icd.json ;;
    *) printf 'Unsupported lane %s\n' "$lane" >&2; exit 2 ;;
esac
repo="$PWD"
run="$proof/p5-$lane"
mkdir "$run" "$run/xdg"
chmod 700 "$run/xdg"
test -z "$(git status --porcelain=v1)"
sha256sum -c "$proof/release-binary.sha256"
mapfile -t ids < "$proof/p5-$lane.txt"
selector=()
for id in "${ids[@]}"; do selector+=(--case "$id"); done
cmd=(timeout --signal=TERM --kill-after=5s 240s taskset --cpu-list 20,21 env -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS -u PANCAKE_RUNTIME -u VK_ICD_FILENAMES -u VK_ADD_DRIVER_FILES -u LD_LIBRARY_PATH "XDG_RUNTIME_DIR=$run/xdg" "UV_PROJECT_ENVIRONMENT=$proof/suite-venv" "VK_DRIVER_FILES=$vk_driver" uv run --project pancake-conformance --offline --frozen pancake-conformance run --target pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml --no-coverage "${selector[@]}" --output "$run/suite")
printf '%q ' "${cmd[@]}" > "$run/command.sh"
printf '\n' >> "$run/command.sh"
date --iso-8601=seconds > "$run/start"
set +e
"${cmd[@]}" > "$run/run.log" 2>&1
status=$?
set -e
printf '%s\n' "$status" > "$run/status"
date --iso-8601=seconds > "$run/end"
tail -6 "$run/run.log"
sha256sum -c "$proof/release-binary.sha256"
test -z "$(git status --porcelain=v1)"
exit "$status"

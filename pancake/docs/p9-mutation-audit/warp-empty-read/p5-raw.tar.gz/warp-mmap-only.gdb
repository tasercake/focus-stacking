set confirm off
set pagination off
set debuginfod enabled off
set disable-randomization off
catch syscall mmap
commands
silent
if (long) $rax == -38 && $rsi >= 12635148 && $rsi < 12643340
printf "packed-map len=%ld\n", $rsi
bt 14
end
continue
end
run

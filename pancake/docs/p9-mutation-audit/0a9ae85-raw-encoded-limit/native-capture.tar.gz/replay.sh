#!/usr/bin/env bash
set -euo pipefail
scope=$(realpath "$1")
cd "$(git rev-parse --show-toplevel)/pancake"
export RUSTC_WRAPPER='' RUSTC_WORKSPACE_WRAPPER='' CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$scope/target" TMPDIR="$scope/tmp"
build=(/usr/bin/taskset -c 8,9 cargo +1.100.0 test --offline --locked -p pancake --test cpu_image_io --jobs 2 --no-run --message-format=json)
{
   git rev-parse HEAD 'HEAD^{tree}'
   sha256sum Cargo.lock tests/data/bayer-conformance.dng "$scope/original.diff"
   rustc +1.100.0 -vV
   uname -a
   taskset -c 8,9 sh -c 'sed -n "/^Cpus_allowed_list:/p" /proc/self/status'
   findmnt -T "$TMPDIR" -no FSTYPE
} > "$scope/identity.txt"
printf '%q ' "${build[@]}" > "$scope/build.command"
printf '\n' >> "$scope/build.command"
build_leg() {
    local arm=$1
    "${build[@]}" > "$scope/$arm-build.jsonl" 2> "$scope/$arm-build.log"
    jq -rs '[.[] | select(.reason == "compiler-artifact" and .target.name == "cpu_image_io" and .executable != null) | .executable] | if length==1 then .[0] else error("unexpected image I/O test executables") end' \
       "$scope/$arm-build.jsonl" > "$scope/$arm-executable.txt"
    sha256sum "$(cat "$scope/$arm-executable.txt")" > "$scope/$arm-executable.sha256"
}
run_leg() {
    local label=$1
    local executor=$2
    shift 2
    local command=(/usr/bin/taskset -c 8,9 /usr/bin/time -f "elapsed_s=%e\nmax_rss_kib=%M" -o "$scope/$label-resource.txt" "$executor" "$@")
    printf '%q ' "${command[@]}" > "$scope/$label.command"
    printf '\n' >> "$scope/$label.command"
    local code=0
    "${command[@]}" > "$scope/$label.log" 2>&1 || code=$?
    printf '%s\n' "$code" > "$scope/$label.status"
    test -z "$(find "$TMPDIR" -mindepth 1 -maxdepth 1 -print -quit)"
}
patch --dry-run -p0 -i "$scope/original.diff"
patch -p0 -i "$scope/original.diff"
trap 'git restore --worktree -- src/image_io/raw.rs' EXIT
git diff -- src/image_io/raw.rs > "$scope/applied.diff"
test "$(git diff --name-only)" = 'pancake/src/image_io/raw.rs'
build_leg mutant
run_leg mutant "$(cat "$scope/mutant-executable.txt")" encoded_raw_at_limit_develops_identically --exact --test-threads=1
git restore --worktree -- src/image_io/raw.rs
trap - EXIT
test -z "$(git diff --name-only)"
test "$(cat "$scope/mutant.status")" = 101
rg -Fq 'compressed RAW source exceeds the byte limit' "$scope/mutant.log"
build_leg stock
test "$(cut -d ' ' -f1 "$scope/stock-executable.sha256")" != "$(cut -d ' ' -f1 "$scope/mutant-executable.sha256")"
exe=$(cat "$scope/stock-executable.txt")
run_leg stock-unpadded "$exe" bayer_dng_develops_true_sixteen_bit_rgb --exact --test-threads=1
run_leg stock-exact-cap "$exe" encoded_raw_at_limit_develops_identically --exact --test-threads=1
run_leg stock-cap-plus-one "$exe" encoded_raw_size_is_limited --exact --test-threads=1
for label in stock-unpadded stock-exact-cap stock-cap-plus-one; do
    test "$(cat "$scope/$label.status")" = 0
done
for label in mutant stock-unpadded stock-exact-cap stock-cap-plus-one; do
    printf '%s\n' "$label"
    cat "$scope/$label-resource.txt"
    tail -8 "$scope/$label.log"
done

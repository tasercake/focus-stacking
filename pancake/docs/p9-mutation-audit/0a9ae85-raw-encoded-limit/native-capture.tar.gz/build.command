/usr/bin/taskset -c 8\,9 cargo +1.100.0 test --offline --locked -p pancake --test cpu_image_io --jobs 2 --no-run --message-format=json 

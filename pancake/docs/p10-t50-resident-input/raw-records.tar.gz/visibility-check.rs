#![deny(unreachable_pub)]
pub mod outer {
    mod inner { pub fn function() {} }
    pub(crate) use inner::function;
}
pub fn entry() { outer::function(); }

#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/resident-input"
test "$(cat "$record/launch.status")" = 0
python3 - "$record" <<'PY'
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

record = Path(sys.argv[1])
run = record / "run"
report = json.loads((run / "report.json").read_text())
exports = []
for ordinal, label in ((1, "baseline"), (2, "resident")):
    path = run / f"diagnostic-{ordinal:02d}/candidate/complete.tif"
    assert not path.is_symlink() and path.resolve().is_relative_to(run.resolve())
    with path.open("rb") as stream:
        actual = file_digest(stream, "sha256").hexdigest()
    output = report["arms"][label]["job"]["output"]
    assert output["sha256"] == actual and output["bytes"] == path.stat().st_size
    exports.append((path, {"arm": label, "sha256": actual, "bytes": output["bytes"]}))
for path, _record in exports:
    path.unlink()
cache = run / "cache"
if cache.exists():
    assert not cache.is_symlink() and cache.resolve().is_relative_to(run.resolve())
    shutil.rmtree(cache)
assert not list(run.rglob("*.tif")) and not cache.exists()
(record / "owned-cleanup.json").write_text(json.dumps({
    "removed_exports": [entry for _, entry in exports],
    "remaining_owned_tiffs": 0, "private_case_cache_removed": True,
    "shared_input_cleanup_owner": "p2_codecs",
}, indent=2) + "\n")
PY
cd "$root/pancake"
cargo clean --target-dir "$PWD/target/resident-input-release" > "$record/release-cleanup.log" 2>&1

"""Package exact resident-input A/B receipts and an immutable source diff."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import re
import sys
import tarfile

record = Path("artifacts/resident-input")
dest = Path(sys.argv[1])
report = json.loads((record / "run/report.json").read_text())
assert report["status"] == "completed_exact_identity" and report["all_52_inputs_unchanged"]
assert all(report["output_comparison"].values())
assert (record / "launch.status").read_text().strip() == "0"
assert (record / "red.status").read_text().strip() == "101"
assert "expected 0 fusion uploads after reuse; baseline 2, candidate 2" in (record / "red.log").read_text()
assert (record / "green.status").read_text().strip() == "0"
assert "2 passed; 0 failed" in (record / "green.log").read_text()
assert (record / "core-lifecycle.status").read_text().strip() == "0"
checks = re.findall(r"test result: ok\. (\d+) passed; 0 failed", (record / "core-lifecycle.log").read_text())
assert sum(map(int, checks)) == 14
for prefix in ("integrated-cpu", "integrated-clippy", "integrated-format", "integrated-source-policy"):
    assert (record / f"{prefix}.status").read_text().strip() == "0", prefix
scope = re.findall(
    r"^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;",
    (record / "integrated-cpu.log").read_text(),
    re.M,
)
assert len(scope) == 18 and sum(map(int, scope)) == 119
for label, ordinal in (("baseline", 1), ("resident", 2)):
    arm = report["arms"][label]
    raw = record / f"run/diagnostic-{ordinal:02d}/candidate/phases.tsv"
    assert arm["trace"]["sha256"] == sha256(raw.read_bytes()).hexdigest()
    assert arm["job"]["completion"]["runtime"] == "wgpu-vulkan"
    assert arm["job"]["completion"]["physical_gpu"] is True
    phases = arm["trace"]["phases"]
    assert phases["proxy_upload"]["count"] == phases["fusion_wait"]["count"] == 50
    assert phases.get("fusion_upload", {}).get("count", 0) == (50 if label == "baseline" else 0)
assert not list((record / "run").rglob("*.tif"))

files = {
    path for path in record.iterdir()
    if path.is_file() and path.name not in {
        "diagnostic-prior.py.txt", "initial-native-test-draft.rs", "report-template.md",
        "report-with-physical.md", "integrated-graph.json", "integrated-licenses.json",
    }
}
files.update(path for path in (record / "run").rglob("*") if path.is_file())
dest.mkdir(parents=True, exist_ok=True)
archive = dest / "raw-records.tar.gz"
manifest = {}
with archive.open("wb") as stream, gzip.GzipFile(
    filename="", mode="wb", fileobj=stream, mtime=0
) as compressed, tarfile.open(fileobj=compressed, mode="w|") as tar:
    for path in sorted(files):
        assert not path.is_symlink()
        name = path.relative_to(record).as_posix()
        contents = path.read_bytes()
        manifest[name] = {"bytes": len(contents), "sha256": sha256(contents).hexdigest()}
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, mode="r:gz") as tar:
    assert set(tar.getnames()) == set(manifest)
    for member in tar.getmembers():
        assert member.isfile()
        contents = tar.extractfile(member).read()
        assert manifest[member.name] == {"bytes": len(contents), "sha256": sha256(contents).hexdigest()}
receipt = {
    "scope": report["scope"],
    "product_base": "2143eda2b308497caee96334357dd23d324e1e8e",
    "untraced_product": (record / "core-revision.txt").read_text().strip(),
    "red_witness": (record / "red-revision.txt").read_text().strip(),
    "traced_candidate": (record / "candidate-revision.txt").read_text().strip(),
    "native_cpu_checks": 14,
    "traced_cpu_ab_tests": 2,
    "cpu_regression_fixtures": ["identity", "shifted", "mismatched"],
    "integrated_scope": {
        "revision": (record / "integrated-revision.txt").read_text().strip(),
        "tree": (record / "integrated-source-tree.txt").read_text().strip(),
        "cpu_passes": sum(map(int, scope)),
        "cpu_executables": len(scope),
        "clippy_exit": 0,
        "format_exit": 0,
        "source_policy_exit": 0,
        "first_clippy_log": "integrated-initial-clippy.log",
    },
    "physical_report": report,
    "raw_archive": {"file": archive.name, "sha256": sha256(archive.read_bytes()).hexdigest(), "files": manifest},
}
(dest / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Verified {len(manifest)} raw records. Archive SHA-256 {receipt['raw_archive']['sha256']}")

#!/usr/bin/env bash
set -euo pipefail
test "$#" = 2
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/resident-input"
input_root=$1
input_receipt=$2
test "$(git rev-parse HEAD)" = 3f6cd9bad7a58dbedf1b9d574a349db1a7618c17
test -z "$(git status --porcelain=v1)"
test -r "$record/release-binary.sha256"
test ! -e "$record/run"
test ! -e "$record/launch.status"
sha256sum --check "$record/release-binary.sha256" > "$record/launch-input-digests.log"
printf '%s  %s\n' 8e4742b2480e041ca95cceeb023627a4c3c69c27f618e3bc13c64874a75ff468 "$input_receipt" \
  | sha256sum --check - >> "$record/launch-input-digests.log"
python=$(cat "$record/python-executable.txt")
sha256sum --check "$record/python-executable.sha256" >> "$record/launch-input-digests.log"
export PYTHONPATH="$root/pancake-conformance/src:$root/qualification/p10-performance"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
launch=(env -u DISPLAY -u WAYLAND_DISPLAY -u LD_PRELOAD -u LD_LIBRARY_PATH
  -u VK_ICD_FILENAMES -u VK_ADD_DRIVER_FILES -u OCL_ICD_VENDORS -u PANCAKE_T50_RESIDENT_BASELINE
  systemd-run --user --scope --quiet --unit=pancake-t50-resident-3f6cd9b
  -p MemoryMax=28G -p MemorySwapMax=0
  taskset --cpu-list 0-31 "$python" "$record/run-pair.py" "$record" "$input_root" "$input_receipt")
printf '%q ' "${launch[@]}" > "$record/launch.command"
printf '\n' >> "$record/launch.command"
date --iso-8601=seconds > "$record/launch-start.txt"
code=0
"${launch[@]}" > "$record/diagnostic-console.log" 2>&1 || code=$?
printf '%s\n' "$code" > "$record/launch.status"
date --iso-8601=seconds > "$record/launch-finish.txt"
exit "$code"

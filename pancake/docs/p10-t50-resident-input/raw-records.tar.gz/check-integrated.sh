#!/usr/bin/env bash
set -euo pipefail
record=/tmp/pancake-worktrees.t3paqgWM/resident-input/artifacts/resident-input
source=/tmp/pancake-worktrees.t3paqgWM/resident-core
cd "$source"
test "$(git rev-parse HEAD)" = 9629212b8438aad688a026e0a57b550fbbf60d72
test -z "$(git status --porcelain=v1)"
git rev-parse HEAD > "$record/integrated-revision.txt"
git rev-parse HEAD^{tree} > "$record/integrated-source-tree.txt"
sha256sum pancake/Cargo.lock > "$record/integrated-lock.sha256"
cd pancake
rustc -Vv > "$record/integrated-rustc.txt"
cargo clippy --version > "$record/integrated-clippy-tool.txt"
rustfmt --version > "$record/integrated-rustfmt-tool.txt"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_DIR=/tmp/pancake-worktrees.t3paqgWM/resident-input/pancake/target/resident-input-cpu
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache

run() {
    local result=$1 status=0
    shift
    printf '%q ' "$@" > "$record/$result.command"
    printf '\n' >> "$record/$result.command"
    "$@" > "$record/$result.log" 2>&1 || status=$?
    printf '%s\n' "$status" > "$record/$result.status"
    return "$status"
}

run integrated-source-policy python3 scripts/miri_host_policy.py "$PWD" validate
run integrated-format cargo fmt --all -- --check
cargo metadata --offline --locked --format-version 1 --all-features > "$record/integrated-graph.json"
python3 scripts/dependency_policy.py --config deny.toml --ledger dependency-policy.json \
    --metadata "$record/integrated-graph.json" --effective-config "$record/integrated-deny.toml" \
    --license-inventory "$record/integrated-licenses.json" --clippy-config clippy.toml \
    --effective-clippy-dir "$record/integrated-clippy" > "$record/integrated-deps-policy.log" 2>&1
sha256sum "$record/integrated-graph.json" "$record/integrated-clippy/clippy.toml" > "$record/integrated-policy.sha256"
cargo metadata --offline --locked --no-deps --format-version 1 > "$record/integrated-target-metadata.json"
python3 scripts/assurance_targets.py "$record/integrated-target-metadata.json" cpu > "$record/integrated-cpu-targets.txt"
args=(--lib --bins)
while IFS= read -r target; do args+=(--test "$target"); done < "$record/integrated-cpu-targets.txt"
run integrated-cpu taskset --cpu-list 16,17,18,19 cargo test --locked --offline -p pancake -p pancake-cli \
    --all-features "${args[@]}" -- --include-ignored
run integrated-clippy env "CLIPPY_CONF_DIR=$record/integrated-clippy" taskset --cpu-list 16,17,18,19 \
    cargo clippy --locked --offline -p pancake -p pancake-cli --all-targets --all-features -- -D warnings

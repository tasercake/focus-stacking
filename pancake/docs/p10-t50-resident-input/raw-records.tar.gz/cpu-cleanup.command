cargo clean --target-dir /tmp/pancake-worktrees.t3paqgWM/resident-input/pancake/target/resident-input-cpu

"""One same-binary physical T50 input-reuse A/B outside the frozen timing schedule."""

import csv
from collections import defaultdict
from dataclasses import replace
import json
import os
from pathlib import Path
import runpy
import statistics
import sys
from types import SimpleNamespace

from p10 import CANDIDATE, ROOT, TARGETS_PATH, _campaign_lock, _git, _hardware, _run_sample, _write
from pancake_conformance.target import TargetSpec
from protocol import Campaign, corpus, pinned_json, sha256, verify_frames
from resources import NvidiaMemory

GPU_UUID = "GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac"
SOURCE = "3f6cd9bad7a58dbedf1b9d574a349db1a7618c17"
TARGETS_SHA = "58bb68533311c48696a3a844d80eef2f37a3c1f39649305948c838b7002663dc"
LOCK_SHA = "f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc"
FROZEN_SHA = "8881a4968bb95f5a911b040a6ebc9635a9cbdc5a759ac0443605de33f700849c"
PAIR_SUMMARY_SHA = "0ee9779cb7fc0ce6b5a57bf1845eb2b0e5c13c5e997dc1e61d747f8fc48a5b71"
PAIR = ROOT / "qualification/p10-performance/evidence/t50-12f2151-preflight"
INPUT_BYTES = 288_000_000
OUTER_STAGES = {
    "decode", "runtime_setup", "registration_prepare", "fusion_prepare", "register",
    "accumulate", "fusion_finish", "final_crop", "job_drain", "encode", "publish",
}


def trace_summary(path, reuse):
    """Reject incomplete traces, then summarize the existing boundaries."""
    observations = defaultdict(list)
    with path.open(newline="") as stream:
        if stream.readline().strip() != "# dropped_records=0":
            raise ValueError("phase trace is truncated or lacks its opening record")
        for row in csv.DictReader(stream, delimiter="\t"):
            stage = row["stage"]
            observations[stage].append({
                "frame": int(row["frame"]) if row["frame"] != "-" else None,
                "start_ns": int(row["start_ns"]),
                "elapsed_ns": int(row["elapsed_ns"]),
                "logical_bytes": int(row["logical_bytes"]) if row["logical_bytes"] != "-" else None,
            })
    total, = observations.pop("job_total")
    if total["start_ns"] != 0 or total["elapsed_ns"] <= 0:
        raise ValueError("completed job trace is malformed")
    for stage in ("decode", "identity", "proxy_upload", "proxy_readback", "fusion_upload", "fusion_wait"):
        records = observations.get(stage, [])
        expected = [] if reuse and stage == "fusion_upload" else list(range(50))
        if [record["frame"] for record in records] != expected:
            raise ValueError(f"unexpected frame coverage for {stage}")
        if stage in ("proxy_upload", "fusion_upload") and any(
            record["logical_bytes"] != INPUT_BYTES for record in records
        ):
            raise ValueError(f"unexpected full RGB byte count in {stage}")
    if len(observations["estimate_pair"]) != 49 or "warp" in observations or "resize" in observations:
        raise ValueError("trace does not describe the frozen first-reference identity route")
    if any(
        record["start_ns"] < 0 or record["elapsed_ns"] < 0
        or record["start_ns"] + record["elapsed_ns"] > total["elapsed_ns"]
        for records in observations.values() for record in records
    ):
        raise ValueError("stage interval crosses the recorded job lifetime")
    if OUTER_STAGES - observations.keys():
        raise ValueError("the trace missed a required top-level T50 stage")
    outer = sorted(
        (record for stage in OUTER_STAGES for record in observations[stage]),
        key=lambda record: record["start_ns"],
    )
    if any(
        first["start_ns"] + first["elapsed_ns"] > second["start_ns"]
        for first, second in zip(outer, outer[1:])
    ):
        raise ValueError("top-level stages overlap")
    phases = {}
    for name, records in observations.items():
        durations = [record["elapsed_ns"] for record in records]
        amounts = [record["logical_bytes"] for record in records if record["logical_bytes"] is not None]
        phases[name] = {
            "count": len(records),
            "total_ns": sum(durations),
            "median_ns": statistics.median(durations),
            "maximum_ns": max(durations),
            "logical_bytes": sum(amounts) if amounts else None,
        }
    elapsed = sum(record["elapsed_ns"] for record in outer)
    return {
        "format": "owner-thread host wall intervals and logical bytes",
        "sha256": sha256(path),
        "bytes": path.stat().st_size,
        "records": sum(len(records) for records in observations.values()) + 1,
        "job_total_ns": total["elapsed_ns"],
        "nonoverlapping_top_level_ns": elapsed,
        "unattributed_host_ns": total["elapsed_ns"] - elapsed,
        "phases": phases,
    }


def main(stage, input_root, input_receipt):
    """Verify the staged release and input identities, then run each variant exactly once."""
    try:
        if _git(ROOT, "rev-parse", "HEAD") != SOURCE or _git(ROOT, "status", "--porcelain"):
            raise ValueError("physical trace requires the exact clean diagnostic source")
        actual_lock = sha256(ROOT / "pancake/Cargo.lock")
        if actual_lock != LOCK_SHA or sha256(TARGETS_PATH) != TARGETS_SHA:
            raise ValueError("lock or benchmark target changed")
        if (stage / "candidate-revision.txt").read_text().strip() != SOURCE:
            raise ValueError("staged release receipt belongs to another source")
        expected_hash, executable = (stage / "release-binary.sha256").read_text().split(maxsplit=1)
        binary = Path(executable.strip()).resolve(strict=True)
        if sha256(binary) != expected_hash:
            raise ValueError("staged release executable failed digest check")

        campaign = Campaign.load(TARGETS_PATH)
        profile = next(profile for profile in campaign.profiles("gpu") if profile.key == "T50.hybrid.gpu")
        previous = pinned_json(PAIR / "pair-001/summary.json", PAIR_SUMMARY_SHA)
        if profile.options != previous["settings"]:
            raise ValueError("frozen settings differ from the historical candidate arm")
        materialized = json.loads((input_receipt).read_text())
        if materialized["reference_receipt_sha256"] != FROZEN_SHA:
            raise ValueError("the materialization did not consume the frozen generator recipe")
        frame_records, corpus_source = corpus(ROOT, campaign, "T50")
        frozen = pinned_json(Path(corpus_source["path"]), FROZEN_SHA)
        file_keys = ("name", "file_sha256", "decoded_pixel_sha256", "bytes", "focus", "role")
        staged_records = [{key: image[key] for key in file_keys} for image in materialized["files"]]
        frozen_records = [{key: image[key] for key in file_keys} for image in frozen["files"]]
        if staged_records != frozen_records:
            raise ValueError("materialized file and decoded-pixel identities differ from the frozen set")
        everyone = [
            {**frame, "path": frame["name"], "sha256": frame["file_sha256"]}
            for frame in frozen["files"]
        ]
        all_files = verify_frames(input_root, everyone, 52)
        frames = verify_frames(input_root, frame_records, 50)
        if len(all_files) != 52 or frames != all_files[:50] or frames != sorted(frames):
            raise ValueError("expected the same 50 distinct ordered originals")
    except (OSError, ValueError, RuntimeError) as error:
        print(f"input or source preparation failed: {error}", file=sys.stderr)
        return 2

    diagnostic = stage / "run"
    diagnostic.mkdir(exist_ok=False)
    target = TargetSpec.load(CANDIDATE)
    identity = {
        "commit": SOURCE, "lock_sha256": actual_lock,
        "descriptor_sha256": sha256(CANDIDATE),
        "executable": str(binary), "binary_sha256": expected_hash,
        "instrumentation_source_sha256": sha256(ROOT / "pancake/src/job/trace.rs"),
        "runner_sha256": sha256(ROOT / "qualification/p10-performance/p10.py"),
    }
    args = SimpleNamespace(
        runtime="wgpu-vulkan", gpu_uuid=GPU_UUID, candidate_gpu_index=0,
        cuda_library_path=None, threads=len(os.sched_getaffinity(0)), timeout=900,
        rss_sampler_cpu=None,
    )
    report = {
        "scope": "same-binary baseline/resident trace diagnostic outside the frozen timing schedule", "arms": {},
        "profile": profile.key, "settings": profile.options, "identity": identity,
        "materialization_sha256": sha256(input_receipt),
        "frozen_input_receipt_sha256": FROZEN_SHA, "source_frame_count": len(frames),
        "historical_summary_sha256": PAIR_SUMMARY_SHA, "status": "pending",
    }
    try:
        with _campaign_lock():
            resource_guard = runpy.run_path(str(PAIR / "paired-diagnostic.py.txt"))["resource_guard"]
            guard = resource_guard(GPU_UUID)
            hardware = _hardware(GPU_UUID)
            report.update(resource_guard=guard, hardware=hardware)
            if (guard["initial_host_available_bytes"] < guard["required_host_available_bytes"]
                    or guard["initial_device_free_mib"] < guard["required_device_free_mib"]):
                raise ValueError("insufficient host or RTX starting headroom")
            if (hardware["cpu_affinity"] != list(range(32))
                    or hardware["gpu"]["pci.bus_id"] != "00000000:01:00.0"
                    or hardware["gpu"]["driver_version"] != "580.178.04"):
                raise ValueError("physical host, affinity or driver differs from the historical arm")
            _write(diagnostic / "report.json", report)
            gpu = NvidiaMemory(GPU_UUID)
            try:
                for ordinal, (label, reuse) in enumerate((("baseline", False), ("resident", True)), start=1):
                    trace = diagnostic / f"diagnostic-{ordinal:02d}/candidate/phases.tsv"
                    environment = target.env | {"PANCAKE_T50_PHASE_TRACE": str(trace)}
                    if not reuse:
                        environment["PANCAKE_T50_RESIDENT_BASELINE"] = "1"
                    observed = replace(target, env=environment)
                    run, _ = _run_sample(
                        profile, ("diagnostic", ordinal, "candidate"), "candidate",
                        observed, identity, args, frames, (4000, 6000, 3), diagnostic, gpu,
                    )
                    report["arms"][label] = {"job": run}
                    _write(diagnostic / "report.json", report)
                    if not run["valid"]:
                        raise ValueError(run["invalid_reason"])
                    verify_output_identity(run, frames)
                    phase = trace_summary(trace, reuse)
                    report["arms"][label]["trace"] = phase
                    _write(diagnostic / "report.json", report)
            finally:
                gpu.close()
            baseline = report["arms"]["baseline"]["job"]["output"]
            resident = report["arms"]["resident"]["job"]["output"]
            historical = previous["jobs"]["candidate"]["output"]
            report["output_comparison"] = {
                "complete_encoded_identity": baseline["sha256"] == resident["sha256"],
                "complete_pixel_identity": baseline["pixel_sha256"] == resident["pixel_sha256"],
                "historical_pixel_identity": baseline["pixel_sha256"] == historical["pixel_sha256"],
                "historical_encoded_identity": baseline["sha256"] == historical["sha256"],
            }
            events = (diagnostic / f"diagnostic-{ordinal:02d}/candidate/events.jsonl"
                      for ordinal in (1, 2))
            original_event, resident_event = (path.read_bytes() for path in events)
            if original_event != resident_event or not all(report["output_comparison"].values()):
                raise ValueError("baseline and retained outputs differ in pixels, encoding or events")
            report["status"] = "completed_exact_identity"
    except (OSError, ValueError, RuntimeError) as error:
        report.update(status="failed", failure=str(error))
    finally:
        try:
            report["all_52_inputs_unchanged"] = verify_frames(input_root, everyone, 52) == all_files
        except (OSError, ValueError) as error:
            report.update(status="failed", input_verification_error=str(error))
        _write(diagnostic / "report.json", report)
    print(report["status"])
    return 0 if report["status"].startswith("completed_") and report["all_52_inputs_unchanged"] else 1


def verify_output_identity(run, frames):
    """Require the named physical GPU, exact transforms and native RGB16 output."""
    event = run["completion"]
    matrices = event["alignment_transforms"]
    if (event["physical_gpu"] is not True or event.get("fallback_reason") is not None
            or {Path(name).name for name in matrices} != {frame.name for frame in frames}
            or any(matrix != [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]] for matrix in matrices.values())):
        raise ValueError("expected physical completion and all 50 exact identity matrices")
    output = run["output"]
    if output["shape"] != [3998, 5998, 3] or output["dtype"] != "uint16":
        raise ValueError("output departed from frozen RGB16 geometry")


if __name__ == "__main__":
    arguments = (Path(path).resolve() for path in sys.argv[1:])
    raise SystemExit(main(*arguments))

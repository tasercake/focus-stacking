python3 scripts/miri_host_policy.py /tmp/pancake-worktrees.t3paqgWM/resident-core/pancake validate 

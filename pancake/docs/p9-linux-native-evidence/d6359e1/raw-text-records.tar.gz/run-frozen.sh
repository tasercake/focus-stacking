#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-d6359e1"
test "$(git rev-parse HEAD)" = d6359e129737f1a9077fb4abc2a8f783fa1f7b38
test -z "$(git status --porcelain=v1)"
sha256sum --check "$base/cuda/binary.sha256"
candidate_hash=$(cut -d' ' -f1 "$base/cuda/binary.sha256")
install -D -m 755 "$base/cuda/pancake-cli" pancake/target/release/pancake-cli
printf '%s  %s\n' "$candidate_hash" pancake/target/release/pancake-cli | sha256sum --check
suite=(uv run --project pancake-conformance --frozen --offline pancake-conformance run
    --target pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml
    --no-coverage)
environment=(env -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS -u PANCAKE_RUNTIME -u LD_LIBRARY_PATH
    "XDG_RUNTIME_DIR=$base/xdg" "UV_PROJECT_ENVIRONMENT=$base/venv"
    "PANCAKE_COMPUTE_CACHE_DIR=$base/$1-compute-cache"
    VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json)
case "$1" in
    cpu)
        "${environment[@]}" "${suite[@]}" \
            --case devices.cpu.weighted_average --case devices.cpu.exposure_fusion \
            --output "$base/cpu-run" > "$base/cpu-console.log" 2>&1
        ;;
    cuda)
        /usr/local/cuda-12.5/bin/nvcc --version > "$base/cuda/nvcc.txt"
        sha256sum "$(realpath /usr/local/cuda-12.5/lib64/libnvrtc.so)" \
            "$(realpath /usr/local/cuda-12.5/lib64/libnvrtc-builtins.so)" \
            "$(realpath /usr/lib/x86_64-linux-gnu/libcuda.so)" > "$base/cuda/runtime-libraries.sha256"
        nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$base/nvidia.txt"
        "${environment[@]}" PANCAKE_RUNTIME=cuda LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64 \
            "${suite[@]}" --case devices.gpu.weighted.zero_regions --case devices.gpu.exposure_constant_mix.9 \
            --output "$base/cuda-run" > "$base/cuda-console.log" 2>&1
        ;;
    *)
        printf 'Expected cpu or cuda argument\n' >&2
        exit 2
        ;;
esac
cat "$base/$1-console.log"

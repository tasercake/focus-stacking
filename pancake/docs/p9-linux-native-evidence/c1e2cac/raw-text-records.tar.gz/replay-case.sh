#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-c1e2cac"
lane=${1:?Pass cpu or cuda}
case "$lane" in
    cpu|cuda) ;;
    *) exit 2 ;;
esac
test "$(cat "$base/cuda/build.status")" = 0
test -s "$base/cuda/runtime-symbols.txt"
date --iso-8601=seconds > "$base/$lane-started.txt"
status=0
taskset --cpu-list 12,13 bash "$base/run-frozen.sh" "$lane" || status=$?
printf '%s\n' "$status" > "$base/$lane-run.status"
date --iso-8601=seconds > "$base/$lane-finished.txt"
exit "$status"

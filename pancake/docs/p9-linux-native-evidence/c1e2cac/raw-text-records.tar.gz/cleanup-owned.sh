#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-c1e2cac"
test "$(git rev-parse HEAD)" = c1e2cac93ad41c02b328d87bdd5d01e1ce2b46eb
test -s "$base/audit.json"
candidate_hash=$(cut -d' ' -f1 "$base/cuda/binary.sha256")
printf '%s  %s\n' "$candidate_hash" pancake/target/release/pancake-cli | sha256sum --check
unlink pancake/target/release/pancake-cli
cd pancake
cargo clean --target-dir "$PWD/target/native-release"
test ! -d "$PWD/target/native-release"

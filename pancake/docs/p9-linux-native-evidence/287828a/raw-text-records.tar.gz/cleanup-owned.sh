#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-287828a"
test "$(git rev-parse HEAD)" = 287828aac07ffad2252785b73a52a59fc07b3409
test -s "$base/audit.json"
candidate_hash=$(cut -d' ' -f1 "$base/cuda/binary.sha256")
printf '%s  %s\n' "$candidate_hash" pancake/target/release/pancake-cli | sha256sum --check
unlink pancake/target/release/pancake-cli
cd pancake
cargo clean --target-dir "$PWD/target/native-release"
test ! -d "$PWD/target/native-release"

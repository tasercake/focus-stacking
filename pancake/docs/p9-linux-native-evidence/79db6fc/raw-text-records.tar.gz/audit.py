"""Audit actual native runtime evidence against the unchanged frozen suite."""

import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
suite = Path("pancake-conformance")
adapter = suite / "src/pancake_conformance/adapters/pancake"
revision = "79db6fc62bed7f61b136d7384992c4970dd09ef3"
profiles = {
    "cpu": ("devices.cpu.weighted_average", "devices.cpu.exposure_fusion"),
    "cuda": ("devices.gpu.weighted.zero_regions", "devices.gpu.exposure_constant_mix.9"),
}

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

contract = json.loads((adapter / "contract-current.json").read_text())
frozen = hashlib.sha256()
for name, expected in sorted(contract["files"].items()):
    source = (suite / name).read_bytes()
    assert hashlib.sha256(source).hexdigest() == expected, name
    frozen.update(name.encode() + b"\0" + source)
assert frozen.hexdigest() == contract["combined_sha256"]
assert (root / "source.txt").read_text().strip() == revision

builds = {}
for runtime in ("hip", "cuda"):
    path = root / runtime
    assert (path / "dependency-policy.status").read_text().strip() == "0"
    assert (path / "cargo-deny.status").read_text().strip() == "0"
    assert "advisories ok, bans ok, sources ok" in (path / "cargo-deny.log").read_text()
    assert f"Compiling cubecl-{runtime} v0.11.4" in (path / "build.log").read_text()
    assert "Finished `release` profile [optimized]" in (path / "build.log").read_text()
    assert "ELF 64-bit LSB pie executable, x86-64" in (path / "elf.txt").read_text()
    symbols = (path / "runtime-symbols.txt").read_text().splitlines()
    assert symbols and all(f"cubecl_{runtime}::" in symbol for symbol in symbols)
    binary = path / "pancake-cli"
    actual = digest(binary)
    assert actual == (path / "binary.sha256").read_text().split()[0]
    builds[runtime] = {
        "binary_sha256": actual,
        "bytes": binary.stat().st_size,
        "linked_native_symbol_count": len(symbols),
        "metadata_sha256": digest(path / "metadata.json"),
        "compile_and_link": "passed",
        "dependency_policy": "passed",
        "offline_cargo_deny": "passed",
        "runtime_exercised": runtime == "cuda",
    }
assert digest(Path("pancake/target/release/pancake-cli")) == builds["cuda"]["binary_sha256"]

outcomes = {}
for runtime, cases in profiles.items():
    run = root / f"{runtime}-run"
    report = json.loads((run / "report.json").read_text())
    provenance = json.loads((run / "provenance.json").read_text())
    assert provenance["target_commit"] == provenance["suite_commit"] == revision
    assert provenance["target_dirty"] == provenance["suite_dirty"] == ""
    assert provenance["contract_version"] == 2
    assert provenance["target_descriptor_sha256"] == digest(adapter / "pancake.toml")
    assert provenance["uv_lock_sha256"] == digest(suite / "uv.lock")
    assert set(provenance["cases"]) == set(cases)
    assert report["complete"] is True and report["status"] == "passed"
    assert report["selected_count"] == report["completed_count"] == len(cases)
    assert report["counts"] == {"passed": len(cases), "failed": 0, "unsupported": 0}
    assert len(report["cases"]) == len(cases)
    assert {result["id"] for result in report["cases"]} == set(cases)

    events = {}
    for result in report["cases"]:
        assert result["status"] == "passed" and result["execution_environment"] == "host"
        case = run / "cases" / result["id"]
        assert json.loads((case / "result.json").read_text()) == result
        calls = list(case.glob("call-*"))
        assert len(calls) == 1
        call = calls[0]
        command = json.loads((call / "command.json").read_text())
        assert command["argv"][0] == "./target/release/pancake-cli"
        output = Path(command["argv"][command["argv"].index("--output") + 1])
        assert output.is_file() and output.stat().st_size > 0
        assert output in (case / name for name in result["outputs"].values())
        event, = (json.loads(line) for line in (call / "events.jsonl").read_text().splitlines())
        assert event["event"] == "stack_complete" and event["completed"] is True
        assert event["runtime"] == runtime and event["fallback_reason"] is None
        if runtime == "cuda":
            assert "--gpu" in command["argv"]
            assert event["actual_backend"] == "gpu" and event["physical_gpu"] is True
            assert event["device"] == "NVIDIA GeForce RTX 3090"
            assert event["device_pci_address"] == "0000:01:00.0"
            assert event["device_fingerprint"] == "ptx_sm86"
        else:
            assert "--cpu" in command["argv"]
            assert event["actual_backend"] == "cpu" and event["physical_gpu"] is False
            assert "AMD Ryzen 9 7950X3D" in event["device"]
            assert event["device_pci_address"] is None
        events[result["id"]] = {"device": event["device"], "runtime": runtime, "output_sha256": digest(output)}
    outcomes[runtime] = {"provenance": provenance, "counts": report["counts"], "completed": events}

receipt = {
    "schema_version": 1,
    "tested_revision": revision,
    "cargo_lock_sha256": digest(Path("pancake/Cargo.lock")),
    "frozen_contract_file_count": len(contract["files"]),
    "frozen_contract_sha256": frozen.hexdigest(),
    "builds": builds,
    "run_binary_sha256": builds["cuda"]["binary_sha256"],
    "runs": outcomes,
    "offline_advisory_database_revision": (root / "advisory-db.txt").read_text().strip(),
}
(root / "audit.json").write_text(json.dumps(receipt, indent=2) + "\n")
print("Two linked production profiles and four frozen CLI cases verified")

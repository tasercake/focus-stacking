#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-79db6fc"
test "$(git rev-parse HEAD)" = 79db6fc62bed7f61b136d7384992c4970dd09ef3
test -z "$(git status --porcelain=v1)"
sha256sum --check "$base/cuda/binary.sha256"
candidate_hash=$(cut -d' ' -f1 "$base/cuda/binary.sha256")
printf '%s  %s\n' "$candidate_hash" pancake/target/release/pancake-cli | sha256sum --check
nvcc=/usr/local/cuda-12.5/bin/nvcc
"$nvcc" --version > "$base/cuda/nvcc.txt"
sha256sum "$(realpath /usr/local/cuda-12.5/lib64/libnvrtc.so)" "$(realpath /usr/lib/x86_64-linux-gnu/libcuda.so)" > "$base/cuda/runtime-libraries.sha256"
suite=(uv run --project pancake-conformance --frozen pancake-conformance run
    --target pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml
    --no-coverage)
environment=(env -u DISPLAY -u WAYLAND_DISPLAY -u PANCAKE_RUNTIME -u LD_LIBRARY_PATH
    "XDG_RUNTIME_DIR=$base/xdg" "UV_PROJECT_ENVIRONMENT=$base/venv"
    VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json)
"${environment[@]}" "${suite[@]}" \
    --case devices.cpu.weighted_average --case devices.cpu.exposure_fusion \
    --output "$base/cpu-run" > "$base/cpu-console.log" 2>&1
"${environment[@]}" PANCAKE_RUNTIME=cuda LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64 \
    "${suite[@]}" --case devices.gpu.weighted.zero_regions --case devices.gpu.exposure_constant_mix.9 \
    --output "$base/cuda-run" > "$base/cuda-console.log" 2>&1
cat "$base/cpu-console.log" "$base/cuda-console.log"

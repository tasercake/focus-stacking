"""Pack raw text evidence and hashes of all original run files."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

base = Path("artifacts/pancake-native-8694b55")
dest = Path("pancake/docs/p9-linux-native-evidence/8694b55")
audit = json.loads((base / "audit.json").read_text())

def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()

def properties(path):
    return {"sha256": digest(path), "bytes": path.stat().st_size}

root_names = (
    "advisory-db.txt", "host-build-tools.txt", "build-tools.sha256", "staged-preflight-inode.txt", "staged-preflight-date.txt", "retained-cuda-inode.txt", "retained-cuda.sha256", "hardware-handoff.txt", "cuda-children-after.txt", "script-syntax.log", "source-policy.log", "cuda-libdevice.sha256", "build-affinity.txt", "build-invocation.txt", "lock-check.txt",
    "cpu-staged-inode.txt", "cuda-staged-inode.txt", "cpu-resource.txt", "cuda-resource.txt", "affinity-topology.csv", "archive-evidence.py", "audit.json", "audit.py",
    "build-profiles.sh", "cargo-deny-version.txt", "cargo.txt", "check-profile-graphs.sh",
    "cleanup.log", "cleanup-owned.sh", "conformance-bootstrap.log", "cpu-console.log", "cpu-run.status", "cpu.txt",
    "cpu-finished.txt", "cpu-started.txt", "cuda-finished.txt", "cuda-started.txt",
    "cuda-console.log", "cuda-run.status", "distribution.txt", "lock.txt", "nvidia.txt", "os.txt",
    "profile-metadata.sha256", "run-frozen.sh", "rustc.txt", "source-tree.txt",
    "replay-case.sh", "source.txt", "tested-source.sha256", "uv.txt", "vendor-policy.log",
)
raw_files = set(map(Path, root_names))
raw_files.update((Path("stored-input-review.commands"), Path("review/frozen-suite.diff"), Path("review/cargo-lock.diff")))
profile_names = (
    "binary.sha256", "build.command", "build-resource.txt", "build-disk-before.txt",
    "build-disk-after.txt", "build-target-size.txt", "build-finished.txt", "build-started.txt", "build.log",
    "build.status", "cargo-deny.log", "cargo-deny.status", "deny-effective.toml",
    "dependency-graph.stderr", "dependency-graph.txt", "dependency-policy.log",
    "dependency-policy.status", "elf-dynamic.txt", "elf-notes.txt", "elf.txt",
    "licenses.json", "metadata.json", "metadata.stderr", "runtime-symbols.txt",
)
for runtime in ("cuda", "hip"):
    raw_files.update(Path(runtime) / name for name in profile_names)
raw_files.update((Path("cuda/nvcc.txt"), Path("cuda/runtime-libraries.sha256")))
run_manifest = {}
for name in ("cpu-run", "cuda-run"):
    for path in sorted((base / name).rglob("*")):
        if not path.is_file():
            continue
        assert not path.is_symlink()
        relative = path.relative_to(base)
        run_manifest[relative.as_posix()] = properties(path)
        if path.name in {
            "command.json", "events.jsonl", "fixture.json", "junit.xml",
            "provenance.json", "report.json", "result.json", "stderr.txt", "stdout.txt",
        }:
            raw_files.add(relative)

dest.mkdir(parents=True, exist_ok=True)
archive = dest / "raw-text-records.tar.gz"
raw_manifest = {}
with archive.open("wb") as stream, gzip.GzipFile(
    filename="", fileobj=stream, mode="wb", mtime=0
) as compressed, tarfile.open(fileobj=compressed, mode="w|") as tar:
    for relative in sorted(raw_files):
        path = base / relative
        assert path.is_file() and not path.is_symlink()
        raw_manifest[relative.as_posix()] = properties(path)
        tar.add(path, arcname=relative.as_posix(), recursive=False)

with tarfile.open(archive, mode="r:gz") as tar:
    assert set(tar.getnames()) == set(raw_manifest)
    for member in tar.getmembers():
        assert member.isfile()
        contents = tar.extractfile(member).read()
        assert raw_manifest[member.name] == {
            "sha256": hashlib.sha256(contents).hexdigest(), "bytes": len(contents)
        }

manifest = dest / "run-file-manifest.json.gz"
with manifest.open("wb") as stream, gzip.GzipFile(
    filename="", fileobj=stream, mode="wb", mtime=0
) as compressed:
    compressed.write((json.dumps(run_manifest, indent=2) + "\n").encode())
assert json.loads(gzip.decompress(manifest.read_bytes())) == run_manifest

audit["evidence_archives"] = {
    archive.name: {**properties(archive), "files": raw_manifest},
    manifest.name: {**properties(manifest), "file_count": len(run_manifest)},
}
(dest / "receipt.json").write_text(json.dumps(audit, indent=2) + "\n")
print(f"Verified {len(raw_manifest)} raw archive members and {len(run_manifest)} run file hashes.")

#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-8694b55"
revision=8694b555666a1ddf4051e2839bbced4bcc625859
test "$(git rev-parse HEAD)" = "$revision"
test -z "$(git status --porcelain=v1)"
expected_lock=f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc
printf '%s  %s\n' "$expected_lock" pancake/Cargo.lock | sha256sum --check > "$base/lock-check.txt"
taskset -pc "$$" > "$base/build-affinity.txt"
lscpu -p=CPU,CORE,SOCKET,NODE > "$base/affinity-topology.csv"
git rev-parse HEAD > "$base/source.txt"
git rev-parse "HEAD^{tree}" > "$base/source-tree.txt"
sha256sum pancake/{Cargo.toml,Cargo.lock,vendor/upstream-sources.json,vendor/oneshot-0.2.1/src/receiver.rs} > "$base/tested-source.sha256"
sha256sum pancake/Cargo.lock > "$base/lock.txt"
uname -a > "$base/os.txt"
cat /etc/os-release > "$base/distribution.txt"
lscpu > "$base/cpu.txt"
uv --version > "$base/uv.txt"

cd pancake
export CARGO_TARGET_DIR="$PWD/target/native-release"
export CARGO_INCREMENTAL=0 RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
rustc -Vv > "$base/rustc.txt"
cargo -Vv > "$base/cargo.txt"
for runtime in cuda hip; do
    profile="$base/$runtime"
    date --iso-8601=seconds > "$profile/build-started.txt"
    runtime_env=(env -u CUDARC_CUDA_VERSION)
    if [[ $runtime == cuda ]]; then
        runtime_env=(env CUDARC_CUDA_VERSION=12050)
    fi
    command=("${runtime_env[@]}" cargo build --locked --offline --release -p pancake -p pancake-cli
        --bin pancake-cli -j 2 --features "cubecl/$runtime")
    printf '%q ' "${command[@]}" > "$profile/build.command"
    printf '\n' >> "$profile/build.command"
    df -B1 "$PWD" > "$profile/build-disk-before.txt"
    if /usr/bin/time --verbose --output="$profile/build-resource.txt" "${command[@]}" > "$profile/build.log" 2>&1; then
        printf '0\n' > "$profile/build.status"
    else
        status=$?
        printf '%s\n' "$status" > "$profile/build.status"
        printf '%s build exit %s\n' "$runtime" "$status"
        tail -25 "$profile/build.log"
        exit "$status"
    fi
    date --iso-8601=seconds > "$profile/build-finished.txt"
    df -B1 "$PWD" > "$profile/build-disk-after.txt"
    du -sb "$CARGO_TARGET_DIR" > "$profile/build-target-size.txt"
    cp --reflink=auto "$CARGO_TARGET_DIR/release/pancake-cli" "$profile/pancake-cli"
    sha256sum "$profile/pancake-cli" > "$profile/binary.sha256"
    file "$profile/pancake-cli" > "$profile/elf.txt"
    readelf -n "$profile/pancake-cli" > "$profile/elf-notes.txt"
    readelf -d "$profile/pancake-cli" > "$profile/elf-dynamic.txt"
    nm --defined-only --demangle "$profile/pancake-cli" | rg "cubecl_$runtime::" > "$profile/runtime-symbols.txt"
    printf '%s build and native link passed\n' "$runtime"
    tail -4 "$profile/build.log"
done

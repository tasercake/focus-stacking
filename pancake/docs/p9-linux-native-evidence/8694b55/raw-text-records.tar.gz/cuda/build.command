env CUDARC_CUDA_VERSION=12050 cargo build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli -j 2 --features cubecl/cuda 

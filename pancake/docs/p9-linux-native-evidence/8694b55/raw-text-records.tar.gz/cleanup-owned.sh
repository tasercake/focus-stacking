#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-8694b55"
test "$(git rev-parse HEAD)" = 8694b555666a1ddf4051e2839bbced4bcc625859
test -s "$base/audit.json"
candidate_hash=$(cut -d' ' -f1 "$base/cuda/binary.sha256")
printf '%s  %s\n' "$candidate_hash" pancake/target/release/pancake-cli | sha256sum --check
unlink pancake/target/release/pancake-cli
cd pancake
cargo clean --target-dir "$PWD/target/native-release"
test ! -d "$PWD/target/native-release"

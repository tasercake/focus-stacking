env -u CUDARC_CUDA_VERSION cargo build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli -j 2 --features cubecl/hip 

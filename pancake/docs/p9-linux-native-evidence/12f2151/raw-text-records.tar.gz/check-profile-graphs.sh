#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/pancake-native-12f2151"
export PATH=/tmp/pancake-tools/bin:$PATH
git -C "$HOME/.cargo/advisory-dbs/advisory-db-3157b0e258782691" rev-parse HEAD > "$base/advisory-db.txt"
cd pancake
cargo deny --version > "$base/cargo-deny-version.txt"
python3 -m unittest vendor/tests/test_patch_contracts.py -v > "$base/vendor-policy.log" 2>&1
: > "$base/profile-metadata.sha256"
for runtime in cuda hip; do
    profile="$base/$runtime"
    cargo metadata --locked --offline --format-version 1 --all-features --features "cubecl/$runtime" > "$profile/metadata.json" 2> "$profile/metadata.stderr"
    sha256sum "$profile/metadata.json" >> "$base/profile-metadata.sha256"
    cargo tree --locked --offline -p pancake -p pancake-cli --features "cubecl/$runtime" -e no-dev > "$profile/dependency-graph.txt" 2> "$profile/dependency-graph.stderr"
    if python3 scripts/dependency_policy.py --config deny.toml --ledger dependency-policy.json \
            --metadata "$profile/metadata.json" --effective-config "$profile/deny-effective.toml" \
            --license-inventory "$profile/licenses.json" --clippy-config clippy.toml \
            --effective-clippy-dir "$profile/clippy" > "$profile/dependency-policy.log" 2>&1; then
        printf '0\n' > "$profile/dependency-policy.status"
    else
        printf '%s\n' "$?" > "$profile/dependency-policy.status"
    fi
    if cargo deny --locked --offline --workspace --all-features --features "cubecl/$runtime" \
            --config "$profile/deny-effective.toml" check advisories bans sources --deny warnings \
            > "$profile/cargo-deny.log" 2>&1; then
        printf '0\n' > "$profile/cargo-deny.status"
    else
        printf '%s\n' "$?" > "$profile/cargo-deny.status"
    fi
    printf '%s dependency policy and cargo-deny exits: %s, %s\n' "$runtime" \
        "$(cat "$profile/dependency-policy.status")" "$(cat "$profile/cargo-deny.status")"
done

"""Check the complete cb5e3a4 device replay against frozen IDs and actual events."""

from collections import Counter
from pathlib import Path
import hashlib
import json
import sys

root = Path(sys.argv[1]).resolve()
run = root / "run"
suite = Path("pancake-conformance")
adapter = suite / "src/pancake_conformance/adapters/pancake"
provenance = json.loads((run / "provenance.json").read_text())
report = json.loads((run / "report.json").read_text())
roadmap = json.loads((adapter / "case-roadmap.json").read_text())
expected = [case["id"] for case in roadmap["cases"] if case["suite"] == "devices"]
actual = [case["id"] for case in report["cases"]]
assert len(actual) == len(set(actual)) == len(expected) == 72
assert set(actual) == set(expected) == set(provenance["cases"])
assert report["complete"] is True and report["status"] == "passed"
assert report["completed_count"] == report["selected_count"] == 72
assert report["counts"] == {"passed": 72, "failed": 0, "unsupported": 0}
assert provenance["target_commit"] == provenance["suite_commit"] == "cb5e3a4a35c2ce356c93fed0f784825a17787148"
assert provenance["target_dirty"] == provenance["suite_dirty"] == ""
assert provenance["contract_version"] == 2
assert provenance["uv_lock_sha256"] == hashlib.sha256((suite / "uv.lock").read_bytes()).hexdigest()
assert provenance["target_descriptor_sha256"] == hashlib.sha256((adapter / "pancake.toml").read_bytes()).hexdigest()

contract = json.loads((adapter / "contract-current.json").read_text())
frozen_digest = hashlib.sha256()
for filename, expected_hash in sorted(contract["files"].items()):
    contents = (suite / filename).read_bytes()
    assert hashlib.sha256(contents).hexdigest() == expected_hash, filename
    frozen_digest.update(filename.encode() + b"\0" + contents)
assert frozen_digest.hexdigest() == contract["combined_sha256"]

completion_backends = Counter()
request_backends = Counter()
evidence_outcome = Counter()
for case in report["cases"]:
    assert case["status"] == "passed" and case["execution_environment"] == "host"
    name = case["id"]
    case_root = run / "cases" / name
    assert json.loads((case_root / "result.json").read_text()) == case
    expected_rejection = name.startswith("devices.gpu.corrupt.") or name == "devices.gpu.corrupt_input_rejected"
    requests = case["notes"]["requests"]
    call_roots = sorted(case_root.glob("call-*"))
    assert len(call_roots) == len(requests)
    for call_root, request in zip(call_roots, requests, strict=True):
        command = json.loads((call_root / "command.json").read_text())
        assert command["argv"][0] == provenance["cli_command"][0], call_root
        request_device = request["options"]["device"]
        request_backends[request_device] += 1
        events_file = call_root / "events.jsonl"
        events = [json.loads(line) for line in events_file.read_text().splitlines() if line] if events_file.exists() else []
        assert not any(event["event"] == "observer_error" for event in events), call_root
        if expected_rejection:
            stderr = (call_root / "stderr.txt").read_text()
            corrupt_name = "corrupt.png" if name == "devices.gpu.corrupt_input_rejected" else "frame_99-corrupt.png"
            assert request_device == "gpu" and "could not decode input" in stderr and corrupt_name in stderr, call_root
            assert not events, call_root
            evidence_outcome["corrupt_input_rejected"] += 1
            if corrupt_name == "frame_99-corrupt.png":
                assert hashlib.sha256((case_root / "retained.png").read_bytes()).hexdigest() == request["inputs"][0]["sha256"], name
                evidence_outcome["existing_export_preserved"] += 1
            continue
        assert len(events) == 1, call_root
        event = events[0]
        assert event["event"] == "stack_complete" and event["completed"] is True, call_root
        assert event["fallback_reason"] is None, call_root
        if request_device == "cpu":
            assert (event["actual_backend"], event["runtime"], event["physical_gpu"], event["device_pci_address"]) == (
                "cpu", "cpu", False, None
            ), call_root
            assert "AMD Ryzen 9 7950X3D" in event["device"], call_root
        else:
            assert (event["actual_backend"], event["runtime"], event["physical_gpu"], event["device_pci_address"]) == (
                "gpu", "wgpu-vulkan", True, "0000:01:00.0"
            ), call_root
            assert event["device"] == "NVIDIA GeForce RTX 3090", call_root
        completion_backends[event["runtime"]] += 1
        output_flag = command["argv"].index("--output")
        output = Path(command["argv"][output_flag + 1])
        assert output in (case_root / relative for relative in case["outputs"].values()), call_root
        assert output.is_file() and output.stat().st_size > 0, call_root

receipt = {
    "schema_version": 1,
    "target_revision": provenance["target_commit"],
    "contract_version": 2,
    "catalog_device_cases": len(expected),
    "frozen_contract_file_count": len(contract["files"]),
    "frozen_contract_sha256": frozen_digest.hexdigest(),
    "requested_backends": dict(request_backends),
    "completed_runtimes": dict(completion_backends),
    "negative_observations": dict(evidence_outcome),
    "suite_counts": report["counts"],
    "elapsed_case_seconds": sum(case["duration"] for case in report["cases"]),
    "status": "passed",
}
(root / "audit.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))

#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/registration-owned-upload"
cpus=${1:?Specify approved CPU affinity}
candidate=07816a24a62f96bc3d3252e95fcfd2b4b5950269
return_branch=codex/pancake-registration-owned-upload
test "$(git branch --show-current)" = "$return_branch"
test -z "$(git status --porcelain)"
sha256sum --check "$record/owned-binaries.sha256"
git switch --detach "$candidate"
restore() { git switch "$return_branch"; }
trap restore EXIT
test -z "$(git status --porcelain)"
sha256sum pancake/{Cargo.lock,assurance-platforms.json} > "$record/device-source.sha256"
binary=pancake/target/release/pancake-cli
expected=$(head -n1 "$record/owned-binaries.sha256" | cut -d' ' -f1)
printf '%s  %s\n' "$expected" "$binary" > "$record/device-binary.sha256"
sha256sum --check "$record/device-binary.sha256"

nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader \
    > "$record/device-physical-host.txt"
adapter=pancake-conformance/src/pancake_conformance/adapters/pancake
jq -r '.cases[] | select(.primary_milestone == "P6") | .id' "$adapter/case-roadmap.json" \
    > "$record/device-regression-cases.txt"
printf '%s\n' algorithms.recovery.cascade.gpu >> "$record/device-regression-cases.txt"
test "$(sort -u "$record/device-regression-cases.txt" | wc -l)" = 73
selection=()
while IFS= read -r case_id; do selection+=(--case "$case_id"); done < "$record/device-regression-cases.txt"
run=(timeout --signal=TERM --kill-after=5s 300s taskset --cpu-list "$cpus" env
    -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS -u PANCAKE_RUNTIME
    -u VK_ICD_FILENAMES -u VK_ADD_DRIVER_FILES -u LD_LIBRARY_PATH
    "XDG_RUNTIME_DIR=$record/xdg" "UV_PROJECT_ENVIRONMENT=$record/venv"
    VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
    uv run --project pancake-conformance --offline --frozen pancake-conformance run
    --target "$adapter/pancake.toml" --no-coverage "${selection[@]}" --output "$record/device-regression")
printf '%q ' "${run[@]}" > "$record/device-regression.command"
printf '\n' >> "$record/device-regression.command"
status=0
"${run[@]}" > "$record/device-regression.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/device-regression.status"
tail -n 8 "$record/device-regression.log"
test "$status" = 0
sha256sum --check "$record/device-binary.sha256"
python3 "$record/audit-expanded-devices.py" "$record"

"""Prove the complete candidate P5 and P6 union and retain raw device receipts."""

from collections import Counter
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile

record, destination = (Path(value).resolve() for value in sys.argv[1:])
read = lambda path: json.loads(path.read_text())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

adapter = Path("pancake-conformance/src/pancake_conformance/adapters/pancake")
roadmap = read(adapter / "case-roadmap.json")
p5 = {item["id"] for item in roadmap["cases"] if item["primary_milestone"] == "P5"}
p6 = {item["id"] for item in roadmap["cases"] if item["primary_milestone"] == "P6"}
assert len(p5) == 64 and len(p6) == 72 and not p5 & p6
cpu = read(record / "cpu-regression/report.json")
extended = read(record / "device-regression/report.json")
audit = read(record / "device-regression-audit.json")
t50 = read(destination / "receipt.json")
p5_host = [item["id"] for item in cpu["cases"]]
p5_p6 = [item["id"] for item in extended["cases"]]
assert len(set(p5_host + p5_p6)) == len(p5_host + p5_p6) == 136
assert set(p5_host + p5_p6) == p5 | p6
assert Counter(item["status"] for report in (cpu, extended) for item in report["cases"]) == {"passed": 136}
assert audit["target_revision"] == t50["source_revisions"]["owned"]
assert audit["exact_case_provenance"]["target_commit"] == t50["cpu_regression"]["provenance"]["target_commit"]
assert audit["binary_sha256"] == t50["physical_pair"]["source_and_binary_identities"]["owned"]["binary_sha256"]
assert audit["binary_sha256"] == read(record / "binary-handoff.json")["binary_sha256"]
assert audit["completed_runtimes"] == {"cpu": 33, "wgpu-vulkan": 37}
assert audit["negative_observations"] == {"corrupt_input_rejected": 31, "existing_export_preserved": 30}
assert audit["frozen_contract_file_count"] == 90

files = sorted(path for path in (record / "device-regression").rglob("*") if path.is_file())
assert all(not path.is_symlink() for path in files)
file_hashes = {path.relative_to(record).as_posix(): {"sha256": digest(path), "bytes": path.stat().st_size}
               for path in files}
manifest = destination / "device-file-manifest.json.gz"
with manifest.open("wb") as raw, gzip.GzipFile(fileobj=raw, filename="", mode="wb", mtime=0) as stream:
    stream.write((json.dumps(file_hashes, indent=2) + "\n").encode())
assert json.loads(gzip.decompress(manifest.read_bytes())) == file_hashes
raw = destination / "device-regression-raw.tar.gz"
files = [path for path in files if path.suffix in {".json", ".jsonl", ".txt", ".xml"}]
files.extend(record / name for name in (
    "audit-expanded-devices.py", "binary-handoff.json", "device-binary.sha256", "device-physical-host.txt",
    "device-regression-audit.json", "device-regression-cases.txt", "device-regression.command",
    "device-regression.log", "device-regression.sh", "device-regression.status", "device-source.sha256",
    "extend-evidence.py",
))
raw_hashes = {path.relative_to(record).as_posix(): digest(path) for path in files}
assert sum(path.endswith("/command.json") for path in raw_hashes) == 101
with tarfile.open(raw, "w:gz") as bundle:
    for path in sorted(files):
        bundle.add(path, arcname=path.relative_to(record).as_posix(), recursive=False)
with tarfile.open(raw) as bundle:
    assert set(bundle.getnames()) == set(raw_hashes)
    assert all(sha256(bundle.extractfile(member).read()).hexdigest() == raw_hashes[member.name]
               for member in bundle.getmembers())
report = {
    "source_revision": audit["target_revision"],
    "binary_sha256": audit["binary_sha256"],
    "p5_p6_unique": 136,
    "p5_expected": sorted(p5),
    "p6_expected": sorted(p6),
    "cpu_p5_selected": p5_host,
    "expanded_device_selected": p5_p6,
    "device_audit": audit,
    "t50_receipt_sha256": digest(destination / "receipt.json"),
    "binary_handoff_provenance_sha256": digest(record / "binary-handoff.json"),
    "archive": {"sha256": digest(raw), "entries_sha256": raw_hashes},
    "generated_run_file_manifest": {"sha256": digest(manifest), "entries": len(file_hashes)},
}
(destination / "device-regression.json").write_text(json.dumps(report, indent=2) + "\n")
print(f"Verified 136 distinct P5/P6 passes, {len(raw_hashes)} archived records and {len(file_hashes)} run-file hashes")

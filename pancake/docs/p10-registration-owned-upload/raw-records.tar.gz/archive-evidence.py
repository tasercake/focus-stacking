"""Verify the native allocation witness and frozen T50 pair before packing receipts."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile

stage, output = (Path(value).resolve() for value in sys.argv[1:])


def json_at(relative):
    return json.loads((stage / relative).read_text())


def text_at(relative):
    return (stage / relative).read_text().strip()


def digest(path):
    with path.open("rb") as stream:
        checksum = sha256()
        while block := stream.read(1024 * 1024):
            checksum.update(block)
        return checksum.hexdigest()


allocations = {
    arm: json_at(f"{arm}-registration-mappings.json") for arm in ("stock", "owned")
}
assert allocations["stock"]["full_frame_registration_allocations"] == 3
assert allocations["owned"]["full_frame_registration_allocations"] == 1
for arm, item in allocations.items():
    assert text_at(f"{arm}-probe.status") == "0"
    assert len(item["nonregistration_mappings"]) == 1
    assert all("pancake::registration::kernels::warp (" in "\n".join(entry["stack"])
               for entry in item["registration_mappings"])
assert text_at("stock-actual-red.status") == "1"
assert text_at("owned-actual-green.status") == "0"

cpu_scope = json_at("cpu-regression/provenance.json")
cpu_report = json_at("cpu-regression/report.json")
owned_source = text_at("owned-source-revision.txt")
assert cpu_scope["target_commit"] == cpu_scope["suite_commit"] == owned_source
assert cpu_scope["target_dirty"] == cpu_scope["suite_dirty"] == ""
assert cpu_report["complete"] and cpu_report["counts"] == {"passed": 63, "failed": 0, "unsupported": 0}
assert set(cpu_scope["cases"]) == set(text_at("cpu-regression-cases.txt").splitlines())
events = [json.loads(line) for path in (stage / "cpu-regression").glob("cases/*/call-*/events.jsonl")
          for line in path.read_text().splitlines()]
assert Counter(row["runtime"] for row in events) == {"cpu": 63}
assert all(row["physical_gpu"] is False and row["fallback_reason"] is None for row in events)

physical = json_at("comparison-run/report.json")
assert physical["status"] == "completed_exact_output"
assert text_at("t50-launch.status") == "0"
assert physical["all_52_inputs_unchanged"] is True
assert physical["source_frame_count"] == 50
for arm in ("stock", "owned"):
    identity = physical["source_and_binary_identities"][arm]
    assert identity["binary_sha256"] == text_at(f"{arm}-binaries.sha256").split()[0]
    assert identity["revision"] == text_at(f"{arm}-source-revision.txt")
    proof = physical["arms"][arm]["completion"]
    assert proof["runtime"] == "wgpu-vulkan" and proof["physical_gpu"] is True
    assert proof["device"] == "NVIDIA GeForce RTX 3090" and proof["device_pci_address"] == "0000:01:00.0"
    assert proof["fallback_reason"] is None and len(proof["alignment_transforms"]) == 50

output.mkdir(parents=True, exist_ok=True)
raw = output / "raw-records.tar.gz"
roots = [
    path for path in stage.iterdir() if path.is_file()
    and (path.name == "independent-review.md" or path.suffix in {
        ".txt", ".log", ".sha256", ".py", ".sh", ".status", ".json",
        ".gdb", ".strace", ".command", ".patch", ".rs",
    })
]
run_files = []
for directory in ("cpu-regression", "comparison-run"):
    run_files += [
        path for path in (stage / directory).rglob("*") if path.is_file()
        and (path.suffix in {".json", ".jsonl", ".txt", ".xml"} or path.name.endswith(".jsonl.gz"))
        and "cache" not in path.relative_to(stage).parts
    ]
files = sorted(set(roots + run_files))
entries = {path.relative_to(stage).as_posix(): digest(path) for path in files}
with tarfile.open(raw, "w:gz") as bundle:
    for path in files:
        assert not path.is_symlink()
        bundle.add(path, arcname=path.relative_to(stage).as_posix(), recursive=False)
with tarfile.open(raw, "r:gz") as bundle:
    assert set(bundle.getnames()) == set(entries)
    for member in bundle.getmembers():
        assert member.isfile()
        assert sha256(bundle.extractfile(member).read()).hexdigest() == entries[member.name]
summary = {
    "source_revisions": {arm: text_at(f"{arm}-source-revision.txt") for arm in ("stock", "owned")},
    "cpu_staging_allocation_proof": allocations,
    "cpu_regression": {"counts": cpu_report["counts"], "provenance": cpu_scope},
    "physical_pair": physical,
    "archive": {"sha256": digest(raw), "entries_sha256": entries},
}
(output / "receipt.json").write_text(json.dumps(summary, indent=2) + "\n")
print(f"Verified {len(entries)} archive entries, 63 CPU cases and both physical T50 outputs")

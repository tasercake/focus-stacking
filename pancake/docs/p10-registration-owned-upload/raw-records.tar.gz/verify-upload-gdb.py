"""Verify the packed staging allocations from the actual registration stack."""

import json
from pathlib import Path
import re
import sys

trace, receipt = map(Path, sys.argv[1:3])
packed = []
current = None
for line in trace.read_text().splitlines():
    match = re.fullmatch(r"packed-map len=(\d+)", line)
    if match:
        current = {"mapping_bytes": int(match.group(1)), "stack": []}
        packed.append(current)
    if current is not None and re.match(r"^#\d+\s", line):
        current["stack"].append(line)
assert "[Inferior " in trace.read_text() and "exited normally" in trace.read_text()
maps = [item for item in packed if any("pancake::registration::kernels::warp (" in frame
                                     for frame in item["stack"])]
if not maps:
    raise SystemExit("No packed allocation has a verified registration warp caller")
summary = {"full_frame_registration_allocations": len(maps),
           "logical_frame_bytes": 6000 * 4000 * 3 * 4,
           "registration_mappings": maps,
           "nonregistration_mappings": [item for item in packed if item not in maps]}
receipt.write_text(json.dumps(summary, indent=2) + "\n")
print(f"Registration used {len(maps)} full-frame staging mappings")
if len(maps) != 1:
    raise SystemExit("Regression: packed registration must stage in one host allocation")

"""Count packed 24 MP staging allocations from symbolized production calls."""

import json
import os
from pathlib import Path
import re
import sys

trace, receipt = map(Path, sys.argv[1:3])
frame_bytes = 6000 * 4000 * 3 * 4
page = os.sysconf("SC_PAGESIZE")
stack = []
large_calls = []
mapping = None
call_pattern = re.compile(r"(?:^|\s)mmap\([^,]+, (\d+), .*?\) = (0x[0-9a-f]+)$")
registration = re.compile(r"pancake::registration::kernels::(?:upload|warp)")

def retain(mapping, stack):
    """Include full-sized, successful allocations with useful call sites."""
    if mapping is None:
        return
    size, address, syscall = mapping
    if frame_bytes <= size < frame_bytes + page * 2:
        large_calls.append({
            "mapping_bytes": size,
            "address": address,
            "syscall": syscall,
            "registration": any(registration.search(frame) for frame in stack),
            "stack": stack,
        })


for line in trace.read_text().splitlines():
    if re.match(r"^\s*(?:\d+\s*)?>\s*", line):
        stack.append(line.strip())
        continue
    retain(mapping, stack)
    stack = []
    match = call_pattern.search(line)
    mapping = (int(match.group(1)), match.group(2), line) if match else None
retain(mapping, stack)

owned = [call for call in large_calls if call["registration"]]
summary = {"logical_frame_bytes": frame_bytes, "page_bytes": page,
           "full_frame_registration_allocations": len(owned), "all_full_frame_allocations": large_calls}
receipt.write_text(json.dumps(summary, indent=2) + "\n")
print(f"registration staging used {len(owned)} full-frame mappings")
if len(owned) == 0:
    sys.exit("Unable to identify a symbolized registration staging allocation")
if len(owned) != 1:
    sys.exit("Registration must stage this packed source in one host allocation")

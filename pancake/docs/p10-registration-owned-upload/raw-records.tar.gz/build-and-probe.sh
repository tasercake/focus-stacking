#!/usr/bin/env bash
set -euo pipefail

arm=${1:?Provide stock or owned}
cpus=${2:?Provide the allocated CPU affinity}
case "$arm" in
    stock|owned) ;;
    *) exit 2 ;;
esac

record="$PWD/artifacts/registration-owned-upload"
test -z "$(git status --porcelain)"
git rev-parse HEAD > "$record/$arm-source-revision.txt"
git rev-parse 'HEAD^{tree}' > "$record/$arm-source-tree.txt"
sha256sum pancake/Cargo.lock > "$record/$arm-lock.sha256"
printf '%s\n' "$cpus" > "$record/$arm-affinity.txt"

cd pancake
export CARGO_TARGET_DIR="$PWD/target/registration-upload-release"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
probe="examples/registration_upload_probe.rs"
test ! -e "$probe"
mkdir -p examples
install -m644 "$record/registration_upload_probe.rs" "$probe"
remove_probe() {
    rm -- "$probe"
    rmdir examples
}
trap remove_probe EXIT
offline_cargo=(taskset --cpu-list "$cpus" cargo +1.100.0 build --offline --locked --release)
"${offline_cargo[@]}" -p pancake -p pancake-cli --example registration_upload_probe --bin pancake-cli \
    > "$record/$arm-build.log" 2>&1
install -m755 "$CARGO_TARGET_DIR/release/pancake-cli" "$record/$arm-pancake-cli"
install -m755 "$CARGO_TARGET_DIR/release/examples/registration_upload_probe" \
    "$record/$arm-registration-upload-probe"
sha256sum "$record/$arm-pancake-cli" "$record/$arm-registration-upload-probe" > "$record/$arm-binaries.sha256"
readelf -n "$record/$arm-pancake-cli" > "$record/$arm-elf-notes.txt"
remove_probe
trap - EXIT

env -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS -u PANCAKE_RUNTIME \
    "PANCAKE_COMPUTE_CACHE_DIR=$record/$arm-probe-cache" \
    timeout --signal=TERM --kill-after=5s 100s taskset --cpu-list "$cpus" \
    strace -f -k -e trace=mmap,mremap -o "$record/$arm-maps.strace" \
    "$record/$arm-registration-upload-probe" > "$record/$arm-probe.log" 2>&1
printf '0\n' > "$record/$arm-probe.status"

status=0
python3 "$record/verify-upload-maps.py" "$record/$arm-maps.strace" "$record/$arm-staging-count.json" \
    > "$record/$arm-staging-check.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/$arm-staging-check.status"
cat "$record/$arm-staging-check.log"
test -z "$(git status --porcelain)"

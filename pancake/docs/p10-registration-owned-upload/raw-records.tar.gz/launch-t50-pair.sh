#!/usr/bin/env bash
set -euo pipefail

test "$#" = 2
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/registration-owned-upload"
input_root=$1
input_receipt=$2
test -z "$(git status --porcelain)"
test ! -e "$record/comparison-run"
test ! -e "$record/t50-launch.status"
sha256sum --check "$record/stock-binaries.sha256" "$record/owned-binaries.sha256" > "$record/t50-launch-digests.log"
sha256sum "$input_receipt" >> "$record/t50-launch-digests.log"

python=/home/krishna/Documents/focus-stacking/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin/python
sha256sum "$python" >> "$record/t50-launch-digests.log"
export PYTHONPATH="$root/pancake-conformance/src:$root/qualification/p10-performance"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
scope=(env -u DISPLAY -u WAYLAND_DISPLAY -u LD_PRELOAD -u LD_LIBRARY_PATH
    -u VK_ICD_FILENAMES -u VK_ADD_DRIVER_FILES -u OCL_ICD_VENDORS
    -u PANCAKE_T50_PHASE_TRACE -u PANCAKE_T50_RESIDENT_BASELINE
    systemd-run --user --scope --quiet --unit=pancake-registration-owned-upload
    -p MemoryMax=28G -p MemorySwapMax=0
    taskset --cpu-list 0-31 "$python" "$record/run-t50-pair.py" "$record" "$input_root" "$input_receipt")
printf '%q ' "${scope[@]}" > "$record/t50-launch.command"
printf '\n' >> "$record/t50-launch.command"
date -Iseconds > "$record/t50-launch-start.txt"
status=0
"${scope[@]}" > "$record/t50-console.log" 2>&1 || status=$?
date -Iseconds > "$record/t50-launch-finish.txt"
printf '%s\n' "$status" > "$record/t50-launch.status"
cat "$record/t50-console.log"
exit "$status"

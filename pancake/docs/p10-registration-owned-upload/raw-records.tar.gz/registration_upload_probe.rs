//! Exercise the production registration upload at the 24 MP packed RGB shape.

use pancake::registration::{Affine, Bounds, Frame, warp};

/// Exact width of a T50 source image.
const WIDTH: usize = 6_000;
/// Exact height of a T50 source image.
const HEIGHT: usize = 4_000;
/// Byte budget for checked staging and the very small result.
const BUDGET: usize = 1_073_741_824;

/// Read the lower-right two rows of the checker without losing any sample bits.
fn main() -> Result<(), String> {
    let sample_count = WIDTH
        .checked_mul(HEIGHT)
        .and_then(|pixels| pixels.checked_mul(3))
        .ok_or("probe sample count overflow")?;
    let mut pixels = Vec::with_capacity(sample_count);
    for index in 0..sample_count {
        let code =
            u16::try_from(index & usize::from(u16::MAX)).map_err(|error| error.to_string())?;
        pixels.push(f32::from(code) / 65_536.0 - 0.25);
    }

    let x = WIDTH.saturating_sub(3);
    let y = HEIGHT.saturating_sub(2);
    let output = Bounds::new(x, y, 3, 2)?;
    let device = cubecl::Device::cpu().map_err(|error| error.to_string())?;
    let frame = Frame::new(WIDTH, HEIGHT, &pixels)?;
    let observed = warp(&device, frame, Affine::IDENTITY, output, BUDGET)?;

    let row = |line: usize| -> Result<&[f32], String> {
        let start = line
            .checked_mul(WIDTH)
            .and_then(|position| position.checked_add(x))
            .and_then(|position| position.checked_mul(3))
            .ok_or("packed test pixel is outside the address space")?;
        let end = start.checked_add(9).ok_or("test row end overflow")?;
        pixels
            .get(start..end)
            .ok_or("test row is outside the source".to_owned())
    };
    let expected = row(y)?.iter().chain(row(y.saturating_add(1))?);
    if observed
        .iter()
        .map(|sample| sample.to_bits())
        .ne(expected.map(|sample| sample.to_bits()))
    {
        return Err("registration upload changed the packed RGB bits".to_owned());
    }
    Ok(())
}

#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/registration-owned-upload"
cpu_list=${1:?Set authorized CPU list}
test "$(cat "$record/owned-actual-green.status")" = 0
test -z "$(git status --porcelain)"
sha256sum --check "$record/owned-binaries.sha256"
install -D -m755 "$record/owned-pancake-cli" pancake/target/release/pancake-cli
test "$(sha256sum pancake/target/release/pancake-cli | cut -d' ' -f1)" = \
    "$(head -n1 "$record/owned-binaries.sha256" | cut -d' ' -f1)"
mkdir -p -m700 "$record/xdg"
adapter=pancake-conformance/src/pancake_conformance/adapters/pancake
jq -r '.cases[] | select(.primary_milestone == "P5" and .id != "algorithms.recovery.cascade.gpu") | .id' \
    "$adapter/case-roadmap.json" > "$record/cpu-regression-cases.txt"
test "$(wc -l < "$record/cpu-regression-cases.txt")" = 63
selection=()
while IFS= read -r case_id; do selection+=(--case "$case_id"); done < "$record/cpu-regression-cases.txt"
status=0
taskset --cpu-list "$cpu_list" env -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS \
    -u PANCAKE_RUNTIME -u VK_DRIVER_FILES -u LD_LIBRARY_PATH \
    "XDG_RUNTIME_DIR=$record/xdg" "UV_PROJECT_ENVIRONMENT=$record/venv" \
    uv run --project pancake-conformance --offline --frozen pancake-conformance run \
    --target "$adapter/pancake.toml" --no-coverage "${selection[@]}" \
    --output "$record/cpu-regression" > "$record/cpu-regression.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/cpu-regression.status"
tail -n 8 "$record/cpu-regression.log"
exit "$status"

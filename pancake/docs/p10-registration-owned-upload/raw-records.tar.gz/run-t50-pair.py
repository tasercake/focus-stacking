"""Compare exact uninstrumented registration upload revisions on shared T50."""

import json
import os
from pathlib import Path
import runpy
import sys
from types import SimpleNamespace

from p10 import CANDIDATE, ROOT, TARGETS_PATH, _campaign_lock, _git, _hardware, _run_sample, _write
from pancake_conformance.target import TargetSpec
from protocol import Campaign, corpus, pinned_json, sha256, verify_frames
from resources import NvidiaMemory

GPU_UUID = "GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac"
BASE = "287828aac07ffad2252785b73a52a59fc07b3409"
LOCK_SHA = "f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc"
FROZEN_SHA = "8881a4968bb95f5a911b040a6ebc9635a9cbdc5a759ac0443605de33f700849c"
EXPECTED_OUTPUT = {
    "sha256": "6160722086e2153b4dd3d8e3810dd22e156669fcafaa15fc72a3e88968b39302",
    "pixel_sha256": "f54746784bcc278da2df734e9f034053a3b54105ddb2a30046baf6dab07a80a3",
    "shape": [3998, 5998, 3],
    "dtype": "uint16",
}


def build_identity(stage, arm):
    """Verify the two executable copies against recorded build receipts."""
    source = (stage / f"{arm}-source-revision.txt").read_text().strip()
    lock = (stage / f"{arm}-lock.sha256").read_text().split()[0]
    digest, binary = (stage / f"{arm}-binaries.sha256").read_text().splitlines()[0].split(maxsplit=1)
    path = Path(binary).resolve(strict=True)
    if sha256(path) != digest or lock != LOCK_SHA:
        raise ValueError(f"binary or lock digest mismatch for {arm}")
    return {"revision": source, "lock_sha256": lock, "executable": str(path), "binary_sha256": digest}


def check_export(run, frames):
    """Require the exact historical crop, pixels, and transform set."""
    if not run["valid"]:
        raise ValueError(run["invalid_reason"])
    output = run["output"]
    if any(output[key] != expected for key, expected in EXPECTED_OUTPUT.items()):
        raise ValueError("T50 export diverged from the historical RGB16 witness")
    completion = run["completion"]
    transforms = completion["alignment_transforms"]
    if ({Path(name).name for name in transforms} != {frame.name for frame in frames}
            or any(matrix != [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]] for matrix in transforms.values())
            or completion["physical_gpu"] is not True or completion["fallback_reason"] is not None):
        raise ValueError("invalid physical CUDA/Vulkan identity, fallback or registration")


def main(stage, inputs, materialization):
    """Run one job per exact binary and revalidate the full shared dataset."""
    identities = {arm: build_identity(stage, arm) for arm in ("stock", "owned")}
    if (identities["stock"]["revision"] != BASE
            or _git(ROOT, "rev-parse", "HEAD") != identities["owned"]["revision"]
            or _git(ROOT, "status", "--porcelain")):
        raise ValueError("comparison must launch from the clean candidate and verified stock")
    campaign = Campaign.load(TARGETS_PATH)
    profile = next(profile for profile in campaign.profiles("gpu") if profile.key == "T50.hybrid.gpu")
    acquisition = json.loads(materialization.read_text())
    if acquisition["reference_receipt_sha256"] != FROZEN_SHA:
        raise ValueError("the shared data did not come from the frozen generator")
    frame_records, source = corpus(ROOT, campaign, "T50")
    frozen = pinned_json(Path(source["path"]), FROZEN_SHA)
    keys = ("name", "file_sha256", "decoded_pixel_sha256", "bytes", "focus", "role")
    for actual, expected in zip(acquisition["files"], frozen["files"], strict=True):
        if any(actual[key] != expected[key] for key in keys):
            raise ValueError(f"materialized physical bytes differ for {expected['name']}")
    everyone = [{**image, "path": image["name"], "sha256": image["file_sha256"]} for image in frozen["files"]]
    all_files = verify_frames(inputs, everyone, 52)
    frames = verify_frames(inputs, frame_records, 50)
    if frames != all_files[:50] or frames != sorted(frames):
        raise ValueError("T50 sources are not in the frozen order")

    directory = stage / "comparison-run"
    directory.mkdir()
    options = SimpleNamespace(runtime="wgpu-vulkan", gpu_uuid=GPU_UUID, candidate_gpu_index=0,
                              cuda_library_path=None, threads=len(os.sched_getaffinity(0)),
                              timeout=900, rss_sampler_cpu=None)
    target = TargetSpec.load(CANDIDATE)
    report = {
        "scope": "One uninstrumented T50 application pair outside the frozen timing schedule",
        "profile": profile.key, "settings": profile.options, "source_frame_count": len(frames),
        "materialization_sha256": sha256(materialization),
        "frozen_input_receipt_sha256": FROZEN_SHA,
        "runner_sha256": sha256(ROOT / "qualification/p10-performance/p10.py"),
        "source_and_binary_identities": identities, "arms": {}, "status": "pending",
    }
    outputs = []
    try:
        with _campaign_lock():
            previous = ROOT / "qualification/p10-performance/evidence/t50-12f2151-preflight"
            resource_guard = runpy.run_path(str(previous / "paired-diagnostic.py.txt"))["resource_guard"]
            guard = resource_guard(GPU_UUID)
            hardware = _hardware(GPU_UUID)
            report.update(resource_guard=guard, hardware=hardware)
            if (guard["initial_host_available_bytes"] < guard["required_host_available_bytes"]
                    or guard["initial_device_free_mib"] < guard["required_device_free_mib"]):
                raise ValueError("insufficient host or RTX starting headroom")
            if (hardware["cpu_affinity"] != list(range(32))
                    or hardware["gpu"]["pci.bus_id"] != "00000000:01:00.0"
                    or hardware["gpu"]["driver_version"] != "580.178.04"):
                raise ValueError("host, affinity or driver differs from the qualified profile")
            _write(directory / "report.json", report)
            gpu = NvidiaMemory(GPU_UUID)
            try:
                for ordinal, arm in enumerate(("stock", "owned"), start=1):
                    run, output = _run_sample(profile, ("diagnostic", ordinal, "candidate"), "candidate",
                                              target, identities[arm], options, frames,
                                              (4000, 6000, 3), directory, gpu)
                    outputs.append(output)
                    report["arms"][arm] = run
                    check_export(run, frames)
                    _write(directory / "report.json", report)
            finally:
                gpu.close()
            completion_files = [directory / f"diagnostic-{number:02d}/candidate/events.jsonl" for number in (1, 2)]
            if completion_files[0].read_bytes() != completion_files[1].read_bytes():
                raise ValueError("registration completion events differ")
            report["status"] = "completed_exact_output"
            report["owned_to_stock_wall_ratio"] = (
                report["arms"]["owned"]["elapsed_ns"] / report["arms"]["stock"]["elapsed_ns"]
            )
    except (OSError, ValueError, RuntimeError) as error:
        report.update(status="failed", failure=str(error))
    finally:
        report["all_52_inputs_unchanged"] = verify_frames(inputs, everyone, 52) == all_files
        if report["status"] == "completed_exact_output":
            for output in outputs:
                output.unlink()
        _write(directory / "report.json", report)
    print(report["status"])
    return 0 if report["status"] == "completed_exact_output" and report["all_52_inputs_unchanged"] else 1


if __name__ == "__main__":
    raise SystemExit(main(*(Path(value).resolve() for value in sys.argv[1:])))

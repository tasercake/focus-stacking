#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/p9-integrated-sanitizers"
expected=d6359e129737f1a9077fb4abc2a8f783fa1f7b38
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain=v1)"
git rev-parse HEAD > "$record/source-revision.txt"
git rev-parse HEAD^{tree} > "$record/source-tree.txt"
date -Iseconds > "$record/start-time.txt"
sha256sum pancake/{Cargo.toml,Cargo.lock,assurance-platforms.json,scripts/check.sh,crates/pancake-gui/src/tests.rs,vendor/upstream-sources.json,vendor/oneshot-0.2.1/src/receiver.rs} > "$record/tested-source.sha256"
sha256sum /tmp/pancake-tools/bin/pancake-rust-cache > "$record/compiler-cache-wrapper.sha256"
rustup run nightly-2026-11-15 rustc --version --verbose > "$record/toolchain.txt"
lscpu > "$record/cpu.txt"
uname -a > "$record/os.txt"
cp /etc/os-release "$record/distribution.txt"
lscpu -p=CPU,CORE,SOCKET,NODE | awk -F, '$1 ~ /^[0-3]$/ {print}' > "$record/affinity-topology.csv"
python3 pancake/scripts/miri_host_policy.py pancake validate > "$record/source-policy.log"

cd pancake
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS
unset PANCAKE_RUNTIME PANCAKE_TEST_GPU_RUNTIME CONFORMANCE_EVENTS_PATH
for sanitizer in address thread; do
    export CARGO_TARGET_DIR="$PWD/target/host-sanitizer-$sanitizer"
    export PANCAKE_COMPUTE_CACHE_DIR="$CARGO_TARGET_DIR/compute-cache"
    date -Iseconds > "$record/$sanitizer-start.txt"
    if env -u TSAN_OPTIONS -u ASAN_OPTIONS -u LSAN_OPTIONS -u UBSAN_OPTIONS \
        timeout --signal=TERM --kill-after=10s 1200s taskset --cpu-list 0,1,2,3 \
        bash scripts/check.sh sanitizer "$sanitizer" > "$record/$sanitizer.log" 2>&1; then
        printf '0\n' > "$record/$sanitizer.status"
    else
        printf '%s\n' "$?" > "$record/$sanitizer.status"
    fi
    date -Iseconds > "$record/$sanitizer-finish.txt"
    if test -f target/assurance/selected-targets.txt; then
        cp target/assurance/selected-targets.txt "$record/$sanitizer-selected-targets.txt"
    fi
    {
        sed -nE 's/^ +Running .+ \(([^)]+)\)$/\1/p' "$record/$sanitizer.log"
        for package in pancake-cli pancake-gui; do
            executable="$CARGO_TARGET_DIR/x86_64-unknown-linux-gnu/debug/$package"
            if test -f "$executable"; then printf '%s\n' "$executable"; fi
        done
    } | sort -u > "$record/$sanitizer-executables.txt"
    while IFS= read -r executable; do
        if test -f "$executable"; then
            sha256sum "$executable" >> "$record/$sanitizer-binaries.sha256"
            { printf '%s ' "$executable"; readelf -n "$executable" | sed -nE 's/^ +Build ID: (.+)$/\1/p'; } \
                >> "$record/$sanitizer-build-ids.txt"
        fi
    done < "$record/$sanitizer-executables.txt"
    printf '%s status %s\n' "$sanitizer" "$(cat "$record/$sanitizer.status")"
    tail -n 8 "$record/$sanitizer.log"
    if test "$(cat "$record/$sanitizer.status")" = 0; then
        env -u RUSTC_WRAPPER cargo clean --target-dir "$CARGO_TARGET_DIR" \
            > "$record/$sanitizer-cleanup.log" 2>&1
    else
        printf 'Retained build for failure classification.\n' > "$record/$sanitizer-cleanup.log"
    fi
done
cd ..
date -Iseconds > "$record/finish-time.txt"
git status --porcelain=v1 > "$record/untracked-check.log"
test ! -s "$record/untracked-check.log"
test "$(cat "$record/address.status")" = 0 && test "$(cat "$record/thread.status")" = 0

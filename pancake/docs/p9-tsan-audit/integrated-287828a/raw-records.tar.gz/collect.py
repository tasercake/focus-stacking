"""Retain exact executable, test-scope and sanitizer outcomes from the replay."""

from hashlib import sha256
import json
from pathlib import Path
import re
import sys


def read(path):
    """Read one text receipt, allowing missing output from an interrupted stage."""
    return path.read_text() if path.is_file() else ""


def file_record(path):
    """Hash the exact bytes retained in the archive."""
    data = path.read_bytes()
    return {"sha256": sha256(data).hexdigest(), "bytes": len(data)}


def results(records, kind):
    """Pair Cargo test executables with their next libtest result."""
    log = read(records / f"{kind}.log")
    names = ("passed", "failed", "ignored", "measured", "filtered")
    counts = dict.fromkeys(names, 0)
    executable = None
    executables = []
    for line in log.splitlines():
        launch = re.fullmatch(r" +Running (.+) \(([^)]+)\)", line)
        if launch:
            executable = {"target": launch.group(1), "path": launch.group(2)}
            executables.append(executable)
        result = re.match(
            r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
            r"(\d+) measured; (\d+) filtered out",
            line,
        )
        if result and executable:
            executable["status"] = result.group(1)
            executable["counts"] = dict(zip(names, map(int, result.groups()[1:])))
            for name, count in executable["counts"].items():
                counts[name] += count
            executable = None

    status_text = read(records / f"{kind}.status").strip()
    status = int(status_text) if status_text else None
    selected = read(records / f"{kind}-selected-targets.txt").splitlines()
    integration = [
        Path(item["target"].removeprefix("tests/")).stem
        for item in executables
        if item["target"].startswith("tests/")
    ]
    libraries = [item for item in executables if item["target"] == "unittests src/lib.rs"]
    binaries = [item for item in executables if item["target"] == "unittests src/main.rs"]
    sanitizer_reports = [
        line.strip()
        for line in log.splitlines()
        if re.search(
            r"(?:(?:WARNING|ERROR|SUMMARY|FATAL): .*?(?:AddressSanitizer|LeakSanitizer|ThreadSanitizer)"
            r"|(?:AddressSanitizer|LeakSanitizer|ThreadSanitizer):(?:DEADLYSIGNAL| CHECK failed))",
            line,
        )
    ]
    scope_complete = (
        sorted(integration) == sorted(selected)
        and len(libraries) == 1
        and len(binaries) == 2
        and all("counts" in target for target in executables)
    )
    hashes = {}
    for line in read(records / f"{kind}-binaries.sha256").splitlines():
        digest, path = line.split(maxsplit=1)
        hashes[path] = digest
    build_ids = {}
    for line in read(records / f"{kind}-build-ids.txt").splitlines():
        if match := re.fullmatch(r"(.+) ([a-f0-9]+)", line):
            build_ids[match.group(1)] = match.group(2)
    identity_complete = all(
        target["path"] in hashes and target["path"] in build_ids for target in executables
    )
    return {
        "process_status": status,
        "scope_complete": scope_complete,
        "identity_complete": identity_complete,
        "workspace_gate_passed": (
            status == 0 and scope_complete and identity_complete and not sanitizer_reports
            and counts["passed"] > 0
            and all(counts[name] == 0 for name in ("failed", "ignored", "filtered"))
        ),
        "counts": counts,
        "executables": executables,
        "executable_sha256": hashes,
        "executable_elf_build_id": build_ids,
        "integration_tests": selected,
        "sanitizer_reports": sanitizer_reports,
        "start_time": read(records / f"{kind}-start.txt").strip(),
        "finish_time": read(records / f"{kind}-finish.txt").strip(),
    }


def main():
    """Write the exact single-gate receipt from immutable raw records."""
    records, output = map(Path, sys.argv[1:3])
    archive = output / "raw-records.tar.gz"
    outcome = results(records, "thread")
    log = read(records / "thread.log")
    terminal_warnings = re.findall(r"ThreadSanitizer: reported [0-9]+ warnings?", log)
    outcome["sanitizer_reports"].extend(terminal_warnings)
    if terminal_warnings:
        outcome["workspace_gate_passed"] = False
    details = {
        "campaign": "Exact integrated Linux workspace CPU ThreadSanitizer replay",
        "source_revision": read(records / "source-revision.txt").strip(),
        "source_tree": read(records / "source-tree.txt").strip(),
        "pancake_tree": read(records / "pancake-tree.txt").strip(),
        "source_file_sha256": {
            name: digest
            for digest, name in (line.split(maxsplit=1) for line in read(records / "tested-source.sha256").splitlines())
        },
        "host": {
            "kernel": read(records / "os.txt").strip(),
            "distribution": read(records / "distribution.txt").splitlines(),
            "affinity": read(records / "process-affinity.txt").strip(),
            "affinity_topology_cpu_core_socket_node": [
                [int(part) for part in line.split(",")]
                for line in read(records / "affinity-topology.csv").splitlines()
            ],
            "fontconfig_elf_build_id": re.search(r"Build ID: (\w+)", read(records / "fontconfig-build-id.txt")).group(1),
            "compile_jobs": 2,
        },
        "compiler": read(records / "toolchain.txt").splitlines(),
        "target": "x86_64-unknown-linux-gnu",
        "unmodified_gate_command": ["bash", "scripts/check.sh", "sanitizer", "thread"],
        "test_scheduling": "default libtest, no RUST_TEST_THREADS setting",
        "sanitizer_options_override": [],
        "scope": "All workspace CPU integration cases, library, CLI and offscreen GUI unit tests",
        "result": outcome,
        "archive": {
            **file_record(archive),
            "files": {item.name: file_record(item) for item in sorted(records.iterdir()) if item.is_file()},
        },
    }
    (output / "receipt.json").write_text(json.dumps(details, indent=2, sort_keys=True) + "\n")
    print(outcome["process_status"], len(outcome["executables"]), outcome["counts"], outcome["workspace_gate_passed"])
    return 0 if outcome["workspace_gate_passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env bash
set -euo pipefail
work=$(pwd)
proof="$work/artifacts/tsan-replay"
expected=0a9ae85b88519a795e3b6ba90860c3b3e664bcaa
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain=v1)"
git rev-parse HEAD > "$proof/source-revision.txt"
git rev-parse HEAD^{tree} > "$proof/source-tree.txt"
git rev-parse HEAD:pancake > "$proof/pancake-tree.txt"
sha256sum pancake/{Cargo.toml,Cargo.lock,assurance-platforms.json,scripts/check.sh,scripts/assurance_targets.py,crates/pancake-gui/src/tests.rs,crates/pancake-gui/src/workspace.slint,vendor/upstream-sources.json,vendor/oneshot-0.2.1/src/receiver.rs} > "$proof/tested-source.sha256"
rustup run nightly-2026-11-15 rustc --version --verbose > "$proof/toolchain.txt"
rustup run nightly-2026-11-15 cargo -V >> "$proof/toolchain.txt"
lscpu > "$proof/cpu.txt"
uname -a > "$proof/os.txt"
cp /etc/os-release "$proof/distribution.txt"
lscpu -p=CPU,CORE,SOCKET,NODE | awk -F, '$1 ~ /^[23]$/ {print}' > "$proof/affinity-topology.csv"
readelf -n /lib/x86_64-linux-gnu/libfontconfig.so.1 > "$proof/fontconfig-build-id.txt"
python3 pancake/scripts/miri_host_policy.py pancake validate > "$proof/source-policy.log"
cd pancake
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$PWD/target/isolated-cpu-tsan"
export PANCAKE_COMPUTE_CACHE_DIR="$CARGO_TARGET_DIR/compute-cache"
unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS
unset PANCAKE_RUNTIME PANCAKE_TEST_GPU_RUNTIME CONFORMANCE_EVENTS_PATH
unset RUST_TEST_THREADS RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER
printf 'CARGO_BUILD_JOBS=%s\nCARGO_INCREMENTAL=%s\nCARGO_TARGET_DIR=%s\n' \
    "$CARGO_BUILD_JOBS" "$CARGO_INCREMENTAL" "$CARGO_TARGET_DIR" > "$proof/environment.txt"
taskset --cpu-list 2,3 sh -c 'taskset -pc $$' > "$proof/process-affinity.txt"
date -Iseconds > "$proof/thread-start.txt"
status=0
env -u TSAN_OPTIONS -u ASAN_OPTIONS -u LSAN_OPTIONS -u UBSAN_OPTIONS \
    timeout --signal=TERM --kill-after=10s 1200s taskset --cpu-list 2,3 \
    bash scripts/check.sh sanitizer thread > "$proof/thread.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$proof/thread.status"
date -Iseconds > "$proof/thread-finish.txt"
if test -f target/assurance/selected-targets.txt; then
    cp target/assurance/selected-targets.txt "$proof/thread-selected-targets.txt"
fi
{
    sed -nE 's/^ +Running .+ \(([^)]+)\)$/\1/p' "$proof/thread.log"
    for package in pancake-cli pancake-gui; do
        binary="$CARGO_TARGET_DIR/x86_64-unknown-linux-gnu/debug/$package"
        if test -f "$binary"; then printf '%s\n' "$binary"; fi
    done
} | sort -u > "$proof/thread-executables.txt"
while IFS= read -r binary; do
    if test -f "$binary"; then
        sha256sum "$binary" >> "$proof/thread-binaries.sha256"
        { printf '%s ' "$binary"; readelf -n "$binary" | sed -nE 's/^ +Build ID: (.+)$/\1/p'; } \
            >> "$proof/thread-build-ids.txt"
    fi
done < "$proof/thread-executables.txt"
printf 'ThreadSanitizer process status %s\n' "$status"
tail -n 15 "$proof/thread.log"
exit "$status"

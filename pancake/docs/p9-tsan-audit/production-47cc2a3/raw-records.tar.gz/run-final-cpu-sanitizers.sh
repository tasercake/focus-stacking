#!/usr/bin/env bash
set -euo pipefail

record="$PWD/artifacts/p9-tsan/final"
test "$(git rev-parse HEAD)" = 7a953359356883e66c39ad928646a8e6495683b9
test -z "$(git status --porcelain=v1)"
git rev-parse HEAD > "$record/source-revision.txt"
sha256sum pancake/{Cargo.toml,Cargo.lock,assurance-platforms.json,scripts/check.sh,crates/pancake-gui/src/tests.rs,vendor/upstream-sources.json,vendor/oneshot-0.2.1/src/receiver.rs} > "$record/tested-source.sha256"
rustup run nightly-2026-11-15 rustc --version --verbose > "$record/toolchain.txt"
lscpu > "$record/cpu.txt"
uname -a > "$record/os.txt"
cd pancake
export CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
for sanitizer in address thread; do
    export CARGO_TARGET_DIR="$PWD/target/host-sanitizer-$sanitizer"
    if env -u TSAN_OPTIONS -u ASAN_OPTIONS -u LSAN_OPTIONS \
        timeout --signal=TERM --kill-after=10s 1200s taskset --cpu-list 0,1,2,3 \
        bash scripts/check.sh sanitizer "$sanitizer" > "$record/$sanitizer.log" 2>&1; then
        printf '0\n' > "$record/$sanitizer.status"
    else
        printf '%s\n' "$?" > "$record/$sanitizer.status"
    fi
    cp target/assurance/selected-targets.txt "$record/$sanitizer-selected-targets.txt"
    for package in pancake-cli pancake-gui; do
        executable="$CARGO_TARGET_DIR/x86_64-unknown-linux-gnu/debug/$package"
        if test -f "$executable"; then
            sha256sum "$executable" >> "$record/$sanitizer-binaries.sha256"
            readelf -n "$executable" | rg 'Build ID:' >> "$record/$sanitizer-build-ids.txt"
        fi
    done
    printf '%s status %s\n' "$sanitizer" "$(cat "$record/$sanitizer.status")"
    tail -n 12 "$record/$sanitizer.log"
    if test "$(cat "$record/$sanitizer.status")" != 0; then
        shopt -s nullglob
        for gui_test in "$CARGO_TARGET_DIR"/x86_64-unknown-linux-gnu/debug/build/pancake-gui/*/out/pancake_gui-*; do
            if test -x "$gui_test"; then
                ln "$gui_test" "$record/$(basename "$gui_test")-$sanitizer.elf"
            fi
        done
    fi
    unset RUSTC_WRAPPER
    cargo clean --target-dir "$CARGO_TARGET_DIR" > "$record/$sanitizer-cleanup.log" 2>&1
    export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
done

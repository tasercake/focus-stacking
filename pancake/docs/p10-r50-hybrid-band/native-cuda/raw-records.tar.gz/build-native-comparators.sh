#!/usr/bin/env bash
set -euo pipefail

root=$PWD
base="$root/artifacts/hybrid-cuda-parity"
lock=f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc
export CARGO_TARGET_DIR="$root/pancake/target/hybrid-cuda"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache CUDARC_CUDA_VERSION=12050

for role in stock candidate; do
    case $role in
        stock)
            branch=codex/pancake-hybrid-cuda-control-b820da0
            revision=b820da05d3982a7912cb7c7c9d8aa926ece14a9c
            ;;
        candidate)
            branch=codex/pancake-hybrid-cuda-parity
            revision=903836ca831ba1e92b7d4f006836320dd8cbe402
            ;;
    esac
    dir="$base/$role"
    cd "$root"
    git switch "$branch"
    test "$(git rev-parse HEAD)" = "$revision"
    test -z "$(git status --porcelain=v1)"
    git rev-parse HEAD > "$dir/source.txt"
    git rev-parse 'HEAD^{tree}' > "$dir/tree.txt"
    node=pancake/src/fusion/advanced/levels.rs
    sha256sum "$node" "$base/compare-native-f32.rs" > "$dir/inputs.sha256"
    printf '%s  %s\n' "$lock" pancake/Cargo.lock | sha256sum --check > "$dir/lock-check.txt"
    cd pancake
    date --iso-8601=seconds > "$dir/build-started.txt"
    cargo +1.100.0 metadata --offline --locked --format-version 1 --features cubecl/cuda > "$dir/metadata.json"
    cargo +1.100.0 tree --offline --locked -p pancake --features cubecl/cuda -e features,no-dev > "$dir/features.txt"
    command=(cargo +1.100.0 build --offline --locked -p pancake --lib --jobs 2 --features cubecl/cuda --message-format json)
    printf '%q ' "${command[@]}" > "$dir/build.command"
    printf '\n' >> "$dir/build.command"
    /usr/bin/time --verbose --output="$dir/build-resource.txt" "${command[@]}" > "$dir/cargo.jsonl" 2> "$dir/build.log"
    du -sb "$CARGO_TARGET_DIR" > "$dir/target-size.txt"
    python3 "$base/dependency-links.py" "$dir"
    mapfile -t libs < "$dir/direct-rlibs.txt"
    test "${#libs[@]}" = 2
    sha256sum "${libs[@]}" > "$dir/direct-rlibs.sha256"
    command=(rustc +1.100.0 --edition=2024 -L "dependency=$dir/deps" --extern "pancake=${libs[0]}"
        --extern "cubecl=${libs[1]}" "$base/compare-native-f32.rs" -o "$dir/driver")
    printf '%q ' "${command[@]}" > "$dir/driver.command"
    printf '\n' >> "$dir/driver.command"
    "${command[@]}" > "$dir/driver-build.log" 2>&1
    sha256sum "$dir/driver" > "$dir/driver.sha256"
    file "$dir/driver" > "$dir/elf.txt"
    readelf -n "$dir/driver" > "$dir/elf-notes.txt"
    readelf -d "$dir/driver" > "$dir/elf-dynamic.txt"
    nm --defined-only --demangle "$dir/driver" | rg 'cubecl_cuda::|cubecl_llvm::nvptx::' > "$dir/native-symbols.txt"
    rg -q 'cubecl_cuda::' "$dir/native-symbols.txt"
    rg -q 'cubecl_llvm::nvptx::' "$dir/native-symbols.txt"
    date --iso-8601=seconds > "$dir/build-finished.txt"
    printf '%s native comparator linked\n' "$role"
done

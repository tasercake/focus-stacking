"""Associate the exact Cargo artifact set with one separately linked driver."""
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
artifacts = root / 'deps'
artifacts.mkdir()
direct = {}
for line in (root / 'cargo.jsonl').read_text().splitlines():
    item = json.loads(line)
    if item.get('reason') != 'compiler-artifact':
        continue
    crate = item['target']['name']
    for name in item['filenames']:
        path = Path(name)
        if path.suffix not in {'.rlib', '.so'}:
            continue
        assert path.is_file(), path
        link = artifacts / path.name
        if link.is_symlink():
            assert link.resolve() == path.resolve(), (link, path)
        else:
            link.symlink_to(path)
        if crate in {'pancake', 'cubecl'} and path.suffix == '.rlib':
            assert crate not in direct, crate
            direct[crate] = str(path)
(root / 'direct-rlibs.txt').write_text(''.join(f'{direct[crate]}\n' for crate in ('pancake', 'cubecl')))

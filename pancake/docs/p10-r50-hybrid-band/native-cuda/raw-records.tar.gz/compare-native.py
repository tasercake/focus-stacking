"""Measure exact f32 equality and localize any real change by fixture."""
import json
import math
from pathlib import Path
import struct
import sys

root = Path(sys.argv[1])
old = (root / 'stock/output.f32le').read_bytes()
new = (root / 'candidate/output.f32le').read_bytes()
assert len(old) == len(new) == 943_848
cases = ((129, 193, 8), (33, 19, 4), (33, 1, 1), (1, 33, 4), (33, 19, 0), (1, 1, 0))
fixtures = ('deterministic-rgb', 'equal-positive-contrast', 'zero-contrast')
position = 0
comparisons = []
for width, height, depth in cases:
    samples = width * height * 3
    end = position + 4 * samples
    for fixture in fixtures:
        before = memoryview(old)[position:end]
        after = memoryview(new)[position:end]
        different = 0
        peak = 0.0
        for (raw_a,), (raw_b,) in zip(struct.iter_unpack('<I', before), struct.iter_unpack('<I', after)):
            if raw_a == raw_b:
                continue
            different += 1
            a, = struct.unpack('<f', struct.pack('<I', raw_a))
            b, = struct.unpack('<f', struct.pack('<I', raw_b))
            assert math.isfinite(a) and math.isfinite(b)
            peak = max(peak, abs(a - b))
        comparisons.append({'extent': [width,height], 'depth': depth, 'fixture': fixture,
                            'samples': samples, 'different_bits': different, 'max_absolute_f32_error': peak})
        position = end
        end = position + 4 * samples
assert position == len(old)
record = {'cases':len(comparisons), 'samples':sum(r['samples'] for r in comparisons),
          'different_bits':sum(r['different_bits'] for r in comparisons),
          'max_absolute_f32_error':max(r['max_absolute_f32_error'] for r in comparisons),
          'identical_bytes':old==new, 'fixtures':comparisons}
(root/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key!='fixtures'}))
if old != new:
    sys.exit(1)

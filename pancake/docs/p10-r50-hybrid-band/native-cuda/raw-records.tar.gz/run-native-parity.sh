#!/usr/bin/env bash
set -euo pipefail

base="$PWD/artifacts/hybrid-cuda-parity"
uuid=GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac
candidate=903836ca831ba1e92b7d4f006836320dd8cbe402
test "$(git rev-parse HEAD)" = "$candidate"
test -z "$(git status --porcelain=v1)"
sha256sum --check "$base/fixture-driver.sha256"
sha256sum --check "$base/stock/driver.sha256" "$base/candidate/driver.sha256"
/usr/local/cuda-12.5/bin/nvcc --version > "$base/nvcc.txt"
sha256sum "$(realpath /usr/local/cuda-12.5/lib64/libnvrtc.so)" \
    "$(realpath /usr/local/cuda-12.5/lib64/libnvrtc-builtins.so)" \
    "$(realpath /usr/lib/x86_64-linux-gnu/libcuda.so)" \
    /usr/local/cuda-12.5/nvvm/libdevice/libdevice.10.bc > "$base/cuda-runtime-libraries.sha256"
nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$base/nvidia-before.csv"
grep -Fx "NVIDIA GeForce RTX 3090, $uuid, 00000000:01:00.0, 580.178.04" "$base/nvidia-before.csv"
for role in stock candidate; do
    dir="$base/$role"
    install -d -m 700 "$dir/cache" "$dir/compute" "$dir/xdg"
    command=(timeout --signal=TERM --kill-after=5s 90s taskset --cpu-list 12,13
        env -u DISPLAY -u WAYLAND_DISPLAY -u DBUS_SESSION_BUS_ADDRESS -u PANCAKE_RUNTIME
        "CUDA_VISIBLE_DEVICES=$uuid" CUDA_PATH=/usr/local/cuda-12.5 LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64
        "CUDA_CACHE_PATH=$dir/cache" "PANCAKE_COMPUTE_CACHE_DIR=$dir/compute" "XDG_RUNTIME_DIR=$dir/xdg"
        "$dir/driver" cuda "$dir/output.f32le")
    printf '%q ' "${command[@]}" > "$dir/runtime.command"
    printf '\n' >> "$dir/runtime.command"
    date --iso-8601=seconds > "$dir/runtime-started.txt"
    status=0
    "${command[@]}" > "$dir/stdout.txt" 2> "$dir/stderr.txt" || status=$?
    printf '%s\n' "$status" > "$dir/runtime.status"
    date --iso-8601=seconds > "$dir/runtime-finished.txt"
    cat "$dir/stderr.txt"
    test "$status" = 0
    rg -q '^runtime=cuda physical=true device=NVIDIA GeForce RTX 3090 fingerprint=ptx_sm86 pci=Some\("0000:01:00.0"\)$' "$dir/stderr.txt"
    sha256sum "$dir/output.f32le" > "$dir/output.sha256"
    printf '%s driver finished\n' "$role"
done
nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$base/nvidia-after.csv"
cmp "$base/nvidia-before.csv" "$base/nvidia-after.csv"
ps -eo pid,comm,args | awk -v dir="$base" '$2 == "driver" && index($0, dir) { print; found = 1 } END { exit found }' > "$base/driver-children-after.txt"

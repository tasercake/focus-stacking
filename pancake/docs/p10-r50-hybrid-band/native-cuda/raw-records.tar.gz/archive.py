"""Verify and preserve the local raw CUDA functional comparison."""
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile

root=Path(sys.argv[1])
dest=Path(sys.argv[2])
record=json.loads((root/'audit.json').read_text())
record.pop('priority', None)
files={path for path in root.iterdir() if path.is_file()}
for role in ('stock','candidate'):
    files.update(path for path in (root/role).iterdir() if path.is_file() and path.name!='driver')
assert root/'cleanup.log' in files
archive=dest/'raw-records.tar.gz'
manifest={}
with archive.open('wb') as output, gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w|') as tar:
        for path in sorted(files):
            assert not path.is_symlink()
            name=path.relative_to(root).as_posix()
            data=path.read_bytes()
            manifest[name]={'bytes':len(data),'sha256':sha256(data).hexdigest()}
            tar.add(path,arcname=name,recursive=False)
with tarfile.open(archive,mode='r:gz') as tar:
    assert tar.getnames()==list(manifest)
    for file in tar.getmembers():
        data=tar.extractfile(file).read()
        assert manifest[file.name]=={'bytes':len(data),'sha256':sha256(data).hexdigest()}
record['archive']={'file':archive.name,'sha256':sha256(archive.read_bytes()).hexdigest(),'members':manifest}
(dest/'receipt.json').write_text(json.dumps(record, indent=2)+'\n')
print(f"{len(manifest)} archived and rehashed members, archive {record['archive']['sha256']}")

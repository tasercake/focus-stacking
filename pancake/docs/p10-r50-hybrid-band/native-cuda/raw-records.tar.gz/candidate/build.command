cargo +1.100.0 build --offline --locked -p pancake --lib --jobs 2 --features cubecl/cuda --message-format json 

taskset --cpu-list 12,13 bash /tmp/pancake-worktrees.t3paqgWM/hybrid-cuda-parity/artifacts/hybrid-cuda-parity/build-native-comparators.sh

taskset --cpu-list 0\,1 cargo build --locked --offline --release -p pancake-cli --bin pancake-cli -j 2 

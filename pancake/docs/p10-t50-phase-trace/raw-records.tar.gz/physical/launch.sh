#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/t50-phase-trace/physical"
test "$(git rev-parse HEAD)" = 64fbdb6d500b185a161e33ae1d975e293cbc64cb
test -z "$(git status --porcelain=v1)"
test -r "$record/materialization.json"
test -r "$record/release-binary.sha256"
test ! -e "$record/run"
test ! -e "$record/launch.status"
sha256sum --check "$record/materialization.sha256" "$record/release-binary.sha256" \
  > "$record/launch-input-digests.log"
export PYTHONPATH="$root/pancake-conformance/src:$root/qualification/p10-performance"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
launch=(env -u DISPLAY -u WAYLAND_DISPLAY -u LD_PRELOAD -u LD_LIBRARY_PATH
  -u VK_ICD_FILENAMES -u VK_ADD_DRIVER_FILES -u OCL_ICD_VENDORS
  systemd-run --user --scope --quiet --unit=pancake-t50-phase-trace-64fbdb6
  -p MemoryMax=28G -p MemorySwapMax=0
  taskset --cpu-list 0-31 "$record/generator-venv/bin/python" "$record/diagnostic.py" "$record")
printf '%q ' "${launch[@]}" > "$record/launch.command"
printf '\n' >> "$record/launch.command"
date --iso-8601=seconds > "$record/launch-start.txt"
code=0
"${launch[@]}" > "$record/diagnostic-console.log" 2>&1 || code=$?
printf '%s\n' "$code" > "$record/launch.status"
date --iso-8601=seconds > "$record/launch-finish.txt"
exit "$code"

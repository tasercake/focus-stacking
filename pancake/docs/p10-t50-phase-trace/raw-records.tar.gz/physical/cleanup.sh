#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/t50-phase-trace/physical"
test "$(cat "$record/launch.status")" = 0
"$record/generator-venv/bin/python" "$root/qualification/t50-generated/t50_generated.py" \
  --cleanup-from "$record/materialization.json" --output "$record/inputs" \
  --receipt "$record/input-cleanup.json" > "$record/input-cleanup.log" 2>&1
python3 - "$record" <<'PY'
from hashlib import file_digest
import json
from pathlib import Path
import sys
record = Path(sys.argv[1])
report = json.loads((record / "run/report.json").read_text())
output = record / "run/diagnostic-01/candidate/complete.tif"
with output.open("rb") as source:
    checksum = file_digest(source, "sha256").hexdigest()
size = output.stat().st_size
assert checksum == report["job"]["output"]["sha256"]
assert size == report["job"]["output"]["bytes"]
output.unlink()
assert not output.exists()
assert not list((record / "inputs").glob("*.tif"))
data = {"export_sha256_before_unlink": checksum, "removed_export_bytes": size,
        "export_absent": True, "generated_tiffs_remaining": 0}
(record / "output-cleanup.json").write_text(json.dumps(data, indent=2) + "\n")
PY
cd "$root/pancake"
cargo clean --target-dir "$PWD/target/t50-phase-trace-release" > "$record/release-cleanup.log" 2>&1
cargo clean --target-dir "$PWD/target/t50-phase-trace-cpu" > "$record/cpu-cleanup.log" 2>&1

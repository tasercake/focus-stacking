"""One opt-in T50 Vulkan candidate trace, outside the frozen timing schedule."""

import csv
from collections import defaultdict
from dataclasses import replace
import json
import os
from pathlib import Path
import runpy
import statistics
import sys
from types import SimpleNamespace

from p10 import CANDIDATE, ROOT, TARGETS_PATH, _campaign_lock, _git, _hardware, _run_sample, _write
from pancake_conformance.target import TargetSpec
from protocol import Campaign, corpus, pinned_json, sha256, verify_frames
from resources import NvidiaMemory

GPU_UUID = "GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac"
SOURCE = "64fbdb6d500b185a161e33ae1d975e293cbc64cb"
TARGETS_SHA = "58bb68533311c48696a3a844d80eef2f37a3c1f39649305948c838b7002663dc"
LOCK_SHA = "f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc"
FROZEN_SHA = "8881a4968bb95f5a911b040a6ebc9635a9cbdc5a759ac0443605de33f700849c"
PAIR_SUMMARY_SHA = "0ee9779cb7fc0ce6b5a57bf1845eb2b0e5c13c5e997dc1e61d747f8fc48a5b71"
PAIR = ROOT / "qualification/p10-performance/evidence/t50-12f2151-preflight"
INPUT_BYTES = 288_000_000
OUTER_STAGES = {
    "decode", "runtime_setup", "registration_prepare", "fusion_prepare", "register",
    "accumulate", "fusion_finish", "final_crop", "job_drain", "encode", "publish",
}


def trace_summary(path):
    """Reject incomplete traces, then summarize the existing boundaries."""
    observations = defaultdict(list)
    with path.open(newline="") as stream:
        if stream.readline().strip() != "# dropped_records=0":
            raise ValueError("phase trace is truncated or lacks its opening record")
        for row in csv.DictReader(stream, delimiter="\t"):
            stage = row["stage"]
            observations[stage].append({
                "frame": int(row["frame"]) if row["frame"] != "-" else None,
                "start_ns": int(row["start_ns"]),
                "elapsed_ns": int(row["elapsed_ns"]),
                "logical_bytes": int(row["logical_bytes"]) if row["logical_bytes"] != "-" else None,
            })
    total, = observations.pop("job_total")
    if total["start_ns"] != 0 or total["elapsed_ns"] <= 0:
        raise ValueError("completed job trace is malformed")
    for stage in ("decode", "identity", "proxy_upload", "proxy_readback", "fusion_upload", "fusion_wait"):
        records = observations[stage]
        if [record["frame"] for record in records] != list(range(50)):
            raise ValueError(f"unexpected frame coverage for {stage}")
        if stage in ("proxy_upload", "fusion_upload") and any(
            record["logical_bytes"] != INPUT_BYTES for record in records
        ):
            raise ValueError(f"unexpected full RGB byte count in {stage}")
    if len(observations["estimate_pair"]) != 49 or "warp" in observations or "resize" in observations:
        raise ValueError("trace does not describe the frozen first-reference identity route")
    if any(
        record["start_ns"] < 0 or record["elapsed_ns"] < 0
        or record["start_ns"] + record["elapsed_ns"] > total["elapsed_ns"]
        for records in observations.values() for record in records
    ):
        raise ValueError("stage interval crosses the recorded job lifetime")
    if OUTER_STAGES - observations.keys():
        raise ValueError("the trace missed a required top-level T50 stage")
    outer = sorted(
        (record for stage in OUTER_STAGES for record in observations[stage]),
        key=lambda record: record["start_ns"],
    )
    if any(
        first["start_ns"] + first["elapsed_ns"] > second["start_ns"]
        for first, second in zip(outer, outer[1:])
    ):
        raise ValueError("top-level stages overlap")
    phases = {}
    for name, records in observations.items():
        durations = [record["elapsed_ns"] for record in records]
        amounts = [record["logical_bytes"] for record in records if record["logical_bytes"] is not None]
        phases[name] = {
            "count": len(records),
            "total_ns": sum(durations),
            "median_ns": statistics.median(durations),
            "maximum_ns": max(durations),
            "logical_bytes": sum(amounts) if amounts else None,
        }
    elapsed = sum(record["elapsed_ns"] for record in outer)
    return {
        "format": "owner-thread host wall intervals and logical bytes",
        "sha256": sha256(path),
        "bytes": path.stat().st_size,
        "records": sum(len(records) for records in observations.values()) + 1,
        "job_total_ns": total["elapsed_ns"],
        "nonoverlapping_top_level_ns": elapsed,
        "unattributed_host_ns": total["elapsed_ns"] - elapsed,
        "phases": phases,
    }


def main(stage):
    """Verify the staged release and input identities, then run exactly once."""
    try:
        if _git(ROOT, "rev-parse", "HEAD") != SOURCE or _git(ROOT, "status", "--porcelain"):
            raise ValueError("physical trace requires the exact clean diagnostic source")
        actual_lock = sha256(ROOT / "pancake/Cargo.lock")
        if actual_lock != LOCK_SHA or sha256(TARGETS_PATH) != TARGETS_SHA:
            raise ValueError("lock or benchmark target changed")
        if (stage / "release-source.txt").read_text().strip() != SOURCE:
            raise ValueError("staged release receipt belongs to another source")
        expected_hash, executable = (stage / "release-binary.sha256").read_text().split(maxsplit=1)
        binary = Path(executable.strip()).resolve(strict=True)
        if sha256(binary) != expected_hash:
            raise ValueError("staged release executable failed digest check")

        campaign = Campaign.load(TARGETS_PATH)
        profile = next(profile for profile in campaign.profiles("gpu") if profile.key == "T50.hybrid.gpu")
        previous = pinned_json(PAIR / "pair-001/summary.json", PAIR_SUMMARY_SHA)
        if profile.options != previous["settings"]:
            raise ValueError("frozen settings differ from the historical candidate arm")
        materialized = json.loads((stage / "materialization.json").read_text())
        if materialized["reference_receipt_sha256"] != FROZEN_SHA:
            raise ValueError("the materialization did not consume the frozen generator recipe")
        frame_records, corpus_source = corpus(ROOT, campaign, "T50")
        frozen = pinned_json(Path(corpus_source["path"]), FROZEN_SHA)
        file_keys = ("name", "file_sha256", "decoded_pixel_sha256", "bytes", "focus", "role")
        staged_records = [{key: image[key] for key in file_keys} for image in materialized["files"]]
        frozen_records = [{key: image[key] for key in file_keys} for image in frozen["files"]]
        if staged_records != frozen_records:
            raise ValueError("materialized file and decoded-pixel identities differ from the frozen set")
        everyone = [
            {**frame, "path": frame["name"], "sha256": frame["file_sha256"]}
            for frame in frozen["files"]
        ]
        all_files = verify_frames(stage / "inputs", everyone, 52)
        frames = verify_frames(stage / "inputs", frame_records, 50)
        if len(all_files) != 52 or frames != all_files[:50] or frames != sorted(frames):
            raise ValueError("expected the same 50 distinct ordered originals")
    except (OSError, ValueError, RuntimeError) as error:
        print(f"input or source preparation failed: {error}", file=sys.stderr)
        return 2

    diagnostic = stage / "run"
    diagnostic.mkdir(exist_ok=False)
    trace = diagnostic / "diagnostic-01/candidate/phases.tsv"
    target = TargetSpec.load(CANDIDATE)
    observed = replace(target, env=target.env | {"PANCAKE_T50_PHASE_TRACE": str(trace)})
    identity = {
        "commit": SOURCE, "lock_sha256": actual_lock,
        "descriptor_sha256": sha256(CANDIDATE),
        "executable": str(binary), "binary_sha256": expected_hash,
        "instrumentation_source_sha256": sha256(ROOT / "pancake/src/job/trace.rs"),
        "runner_sha256": sha256(ROOT / "qualification/p10-performance/p10.py"),
    }
    args = SimpleNamespace(
        runtime="wgpu-vulkan", gpu_uuid=GPU_UUID, candidate_gpu_index=0,
        cuda_library_path=None, threads=len(os.sched_getaffinity(0)), timeout=900,
        rss_sampler_cpu=None,
    )
    report = {
        "scope": "one traced candidate diagnostic, no reference run or frozen timing jobs",
        "profile": profile.key, "settings": profile.options, "identity": identity,
        "materialization_sha256": sha256(stage / "materialization.json"),
        "frozen_input_receipt_sha256": FROZEN_SHA, "source_frame_count": len(frames),
        "historical_summary_sha256": PAIR_SUMMARY_SHA, "status": "pending",
    }
    try:
        with _campaign_lock():
            resource_guard = runpy.run_path(str(PAIR / "paired-diagnostic.py.txt"))["resource_guard"]
            guard = resource_guard(GPU_UUID)
            hardware = _hardware(GPU_UUID)
            report.update(resource_guard=guard, hardware=hardware)
            if (guard["initial_host_available_bytes"] < guard["required_host_available_bytes"]
                    or guard["initial_device_free_mib"] < guard["required_device_free_mib"]):
                raise ValueError("insufficient host or RTX starting headroom")
            if (hardware["cpu_affinity"] != list(range(32))
                    or hardware["gpu"]["pci.bus_id"] != "00000000:01:00.0"
                    or hardware["gpu"]["driver_version"] != "580.178.04"):
                raise ValueError("physical host, affinity or driver differs from the historical arm")
            _write(diagnostic / "report.json", report)
            gpu = NvidiaMemory(GPU_UUID)
            try:
                run, _ = _run_sample(
                    profile, ("diagnostic", 1, "candidate"), "candidate",
                    observed, identity, args, frames, (4000, 6000, 3), diagnostic, gpu,
                )
            finally:
                gpu.close()
            report["job"] = run
            if not run["valid"]:
                raise ValueError(run["invalid_reason"])
            event = run["completion"]
            matrices = event["alignment_transforms"]
            if (event["physical_gpu"] is not True or event.get("fallback_reason") is not None
                    or {Path(name).name for name in matrices} != {frame.name for frame in frames}
                    or any(matrix != [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]] for matrix in matrices.values())):
                raise ValueError("expected the same physical completion and all 50 exact identity matrices")
            reference = previous["jobs"]["candidate"]["output"]
            actual = run["output"]
            report["historical_candidate_output"] = {
                "candidate_source": previous["release"],
                "pixel_sha256": reference["pixel_sha256"],
                "encoded_sha256": reference["sha256"],
                "full_pixel_identity": actual["pixel_sha256"] == reference["pixel_sha256"],
                "encoded_identity": actual["sha256"] == reference["sha256"],
            }
            if actual["shape"] != [3998, 5998, 3] or actual["dtype"] != "uint16":
                raise ValueError("candidate departed from the frozen RGB16 output geometry")
            report["trace"] = trace_summary(trace)
            report["status"] = "completed_matching_pixels" if report["historical_candidate_output"]["full_pixel_identity"] else "completed_different_pixels"
    except (OSError, ValueError, RuntimeError) as error:
        report.update(status="failed", failure=str(error))
    finally:
        try:
            report["all_52_inputs_unchanged"] = verify_frames(stage / "inputs", everyone, 52) == all_files
        except (OSError, ValueError) as error:
            report.update(status="failed", input_verification_error=str(error))
        _write(diagnostic / "report.json", report)
    print(report["status"])
    return 0 if report["status"].startswith("completed_") and report["all_52_inputs_unchanged"] else 1


if __name__ == "__main__":
    raise SystemExit(main(Path(sys.argv[1]).resolve()))

#!/usr/bin/env bash
set -euo pipefail

root=$(git rev-parse --show-toplevel)
record="$root/artifacts/t50-phase-trace/physical"
revision=64fbdb6d500b185a161e33ae1d975e293cbc64cb
frozen="$root/qualification/t50-generated/evidence/native-t50-receipt.json"
source="$root/pancake"
test "$(git rev-parse HEAD)" = "$revision"
test -z "$(git status --porcelain=v1)"
printf '%s  %s\n' f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc "$source/Cargo.lock" | sha256sum --check -
printf '%s  %s\n' 8881a4968bb95f5a911b040a6ebc9635a9cbdc5a759ac0443605de33f700849c "$frozen" | sha256sum --check -
case "$1" in
  build)
    cd "$source"
    export CARGO_TARGET_DIR="$PWD/target/t50-phase-trace-release"
    export CARGO_INCREMENTAL=0 RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
    rustc -Vv > "$record/rustc.txt"
    cargo -Vv > "$record/cargo.txt"
    git rev-parse HEAD > "$record/release-source.txt"
    git rev-parse HEAD^{tree} > "$record/release-tree.txt"
    sha256sum "$source/Cargo.lock" "$source/docs/performance-targets.json" "$source/src/job/trace.rs" \
      "$root/pancake-conformance/src/pancake_conformance/adapters/pancake/pancake.toml" \
      "$root/qualification/p10-performance/"{p10,protocol,resources}.py "$frozen" > "$record/release-inputs.sha256"
    date --iso-8601=seconds > "$record/build-start.txt"
    build=(taskset --cpu-list 0,1 cargo build --locked --offline --release -p pancake-cli --bin pancake-cli -j 2)
    printf '%q ' "${build[@]}" > "$record/build.command"
    printf '\n' >> "$record/build.command"
    "${build[@]}" > "$record/build.log" 2>&1
    date --iso-8601=seconds > "$record/build-finish.txt"
    sha256sum "$CARGO_TARGET_DIR/release/pancake-cli" > "$record/release-binary.sha256"
    readelf -n "$CARGO_TARGET_DIR/release/pancake-cli" > "$record/release-build-id.txt"
    ;;
  stage)
    test ! -e "$record/inputs"
    df -PB1 "$record" > "$record/stage-disk.txt"
    awk 'NR==2 { enough=$4>=25769803776 } END { exit !enough }' "$record/stage-disk.txt"
    nice -n 15 ionice -c 3 taskset --cpu-list 15 uv venv --offline --python 3.12.12 "$record/generator-venv" \
      > "$record/venv.log" 2>&1
    generator="$record/generator-venv/bin/python"
    nice -n 15 ionice -c 3 taskset --cpu-list 15 uv pip install --offline --python "$generator" \
      -r "$root/qualification/t50-generated/requirements.txt" > "$record/generator-deps.log" 2>&1
    "$generator" --version > "$record/generator-python.txt"
    uv pip freeze --python "$generator" > "$record/generator-deps.txt"
    date --iso-8601=seconds > "$record/generation-start.txt"
    command=(nice -n 15 ionice -c 3 taskset --cpu-list 15 "$generator"
      "$root/qualification/t50-generated/t50_generated.py" --materialize-from "$frozen"
      --output "$record/inputs" --receipt "$record/materialization.json")
    printf '%q ' "${command[@]}" > "$record/generation.command"
    printf '\n' >> "$record/generation.command"
    "${command[@]}" > "$record/generation.log" 2>&1
    date --iso-8601=seconds > "$record/generation-finish.txt"
    sha256sum "$record/materialization.json" > "$record/materialization.sha256"
    ;;
  *) printf 'Use build or stage.\n' >&2; exit 2 ;;
esac

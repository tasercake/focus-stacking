#!/usr/bin/env bash
set -euo pipefail

root=$(git rev-parse --show-toplevel)
record="$root/artifacts/t50-phase-trace"
red=8b01dad6c81c7c679701bdcaf95499b6d82239f4
candidate=codex/pancake-t50-timing
test -z "$(git status --porcelain=v1)"
git rev-parse "$candidate" > "$record/green-revision.txt"
git rev-parse "$red" > "$record/red-revision.txt"
sha256sum "$root/pancake/Cargo.lock" > "$record/lock.txt"
lscpu -p=CPU,CORE,SOCKET > "$record/cpu-topology.csv"
git switch --detach "$red"
cd "$root/pancake"
rustc -Vv > "$record/rustc.txt"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_DIR="$PWD/target/t50-phase-trace-cpu"
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
focused=(taskset --cpu-list 16,17,18,19 cargo test --locked -p pancake-cli --test cpu_runtime_options
  opt_in_phase_trace_preserves_the_completed_stack -- --exact)
if "${focused[@]}" > "$record/red.log" 2>&1; then
    printf '0\n' > "$record/red.status"
    printf 'The test-only revision unexpectedly passed.\n' >&2
    exit 1
else
    printf '%s\n' "$?" > "$record/red.status"
fi
rg -q 'the opt-in phase trace was missing:' "$record/red.log"
git switch "$candidate"
test "$(git rev-parse HEAD)" = "$(cat "$record/green-revision.txt")"
status=0
"${focused[@]}" > "$record/green.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/green.status"
test "$status" = 0
status=0
taskset --cpu-list 16,17,18,19 cargo test --locked -p pancake --lib job::lifecycle::tests \
    > "$record/lifecycle.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$record/lifecycle.status"
test "$status" = 0

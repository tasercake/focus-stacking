"""Archive the verified T50 study and exact CPU comparison."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import tarfile

base = Path("artifacts/t50-phase-trace")
dest = Path("pancake/docs/p10-t50-phase-trace")
physical = base / "physical"
run = physical / "run"
candidate = run / "diagnostic-01/candidate"
report = json.loads((run / "report.json").read_text())
assert report["status"] == "completed_matching_pixels"
assert report["all_52_inputs_unchanged"] is True
assert report["historical_candidate_output"]["encoded_identity"] is True
assert report["historical_candidate_output"]["full_pixel_identity"] is True
trace = candidate / "phases.tsv"
assert report["trace"]["sha256"] == sha256(trace.read_bytes()).hexdigest()
assert report["trace"]["records"] == len(trace.read_text().splitlines()) - 2 == 1661
assert report["job"]["completion"]["runtime"] == "wgpu-vulkan"
assert report["job"]["completion"]["actual_backend"] == "gpu"
assert report["job"]["completion"]["physical_gpu"] is True
assert (base / "red.status").read_text().strip() == "101"
assert "the opt-in phase trace was missing:" in (base / "red.log").read_text()
assert (base / "green.status").read_text().strip() == "0"
assert (base / "lifecycle.status").read_text().strip() == "0"
assert "6 passed; 0 failed" in (base / "lifecycle.log").read_text()
assert (base / "plain.events.jsonl").read_bytes() == (base / "traced.events.jsonl").read_bytes()
assert (base / "plain.stdout").read_bytes() == (base / "traced.stdout").read_bytes()
assert not list((physical / "inputs").glob("*.tif"))
assert not list(run.rglob("*.tif"))
cleanup = json.loads((physical / "input-cleanup.json").read_text())
assert cleanup["cleanup"]["remaining_tiff_count"] == 0

files = set(path for path in base.iterdir() if path.is_file() and path.name != "report-in.md")
files.update(path for path in physical.iterdir() if path.is_file())
files.update(path for path in run.rglob("*") if path.is_file())
manifest = {}
archive = dest / "raw-records.tar.gz"
with archive.open("wb") as stream, gzip.GzipFile(
    filename="", mode="wb", fileobj=stream, mtime=0
) as compressed, tarfile.open(fileobj=compressed, mode="w|") as tar:
    for path in sorted(files):
        assert not path.is_symlink()
        name = path.relative_to(base).as_posix()
        contents = path.read_bytes()
        manifest[name] = {"bytes": len(contents), "sha256": sha256(contents).hexdigest()}
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, mode="r:gz") as tar:
    assert set(tar.getnames()) == set(manifest)
    for member in tar.getmembers():
        assert member.isfile()
        contents = tar.extractfile(member).read()
        assert manifest[member.name] == {"bytes": len(contents), "sha256": sha256(contents).hexdigest()}

receipt = {
    "scope": "one completed physical diagnostic outside the frozen measurement schedule",
    "product_base": "d6359e129737f1a9077fb4abc2a8f783fa1f7b38",
    "instrumented_release_tree": (physical / "release-tree.txt").read_text().strip(),
    "release_identity": report["identity"],
    "cpu_regression": {
        "test_only_revision": (base / "red-revision.txt").read_text().strip(),
        "test_only_process_exit": int((base / "red.status").read_text()),
        "first_compile_rejected_revision": (base / "initial-qualification-revision.txt").read_text().strip(),
        "final_revision": (base / "green-revision.txt").read_text().strip(),
        "trace_equivalence_passes": 1,
        "lifecycle_passes": 6,
        "independent_cpu_witness_records": 41,
        "independent_cpu_witness_sha256": sha256((base / "witness.tsv").read_bytes()).hexdigest(),
        "cpu_affinity": [16, 17, 18, 19],
    },
    "physical": {
        "hardware": report["hardware"],
        "resources": report["resource_guard"],
        "profile": report["profile"],
        "settings": report["settings"],
        "wall_elapsed_ns": report["job"]["elapsed_ns"],
        "output": report["job"]["output"],
        "completion_runtime": report["job"]["completion"]["runtime"],
        "historical_output_match": report["historical_candidate_output"],
        "frozen_inputs_sha256": report["frozen_input_receipt_sha256"],
        "materialization_sha256": report["materialization_sha256"],
        "all_inputs_unchanged": report["all_52_inputs_unchanged"],
        "trace": report["trace"],
        "input_cleanup_sha256": sha256((physical / "input-cleanup.json").read_bytes()).hexdigest(),
        "output_cleanup": json.loads((physical / "output-cleanup.json").read_text()),
    },
    "raw_archive": {"file": archive.name, "sha256": sha256(archive.read_bytes()).hexdigest(), "files": manifest},
}
(dest / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Verified {len(manifest)} raw records. Archive SHA-256 {receipt['raw_archive']['sha256']}")

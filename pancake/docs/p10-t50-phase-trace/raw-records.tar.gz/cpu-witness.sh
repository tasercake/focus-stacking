#!/usr/bin/env bash
set -euo pipefail

root=$(git rev-parse --show-toplevel)
record="$root/artifacts/t50-phase-trace"
data="$record/fixture"
mkdir -p "$data"
python3 - "$data" <<'PY'
from pathlib import Path
import struct
import sys
import zlib

directory = Path(sys.argv[1])
def chunk(kind, body):
    checksum = zlib.crc32(kind + body)
    return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", checksum)

raster = bytearray()
for y in range(11):
    raster.append(0)
    for x in range(13):
        offset = y * 13 + x
        values = (6500, 35000, 59000) if offset % 3 == 0 else (52000, 6500, 13000)
        raster.extend(struct.pack(">3H", *values))
picture = b"\x89PNG\r\n\x1a\n"
picture += chunk(b"IHDR", struct.pack(">IIBBBBB", 13, 11, 16, 2, 0, 0, 0))
picture += chunk(b"IDAT", zlib.compress(raster))
picture += chunk(b"IEND", b"")
for name in ("first.png", "second.png"):
    (directory / name).write_bytes(picture)
PY

binary="$root/pancake/target/t50-phase-trace-cpu/debug/pancake-cli"
sha256sum "$binary" > "$record/witness-binary.sha256"
file "$binary" > "$record/witness-binary.txt"
readelf -n "$binary" > "$record/witness-build-id.txt"
for profile in plain traced; do
    launch=(env -u DISPLAY -u WAYLAND_DISPLAY -u PANCAKE_RUNTIME -u PANCAKE_T50_PHASE_TRACE
        "CONFORMANCE_EVENTS_PATH=$record/$profile.events.jsonl"
        "PANCAKE_COMPUTE_CACHE_DIR=$record/compute-cache")
    if [[ $profile == traced ]]; then
        launch+=("PANCAKE_T50_PHASE_TRACE=$record/witness.tsv")
    fi
    command=("${launch[@]}" taskset --cpu-list 16,17,18,19 "$binary"
        --input "$data/first.png" "$data/second.png" --cpu --method hybrid --align
        --alignment-mode similarity --alignment-ref first --pyramid-levels 2 --bit-depth 16
        --output "$data/$profile.tif")
    printf '%q ' "${command[@]}" > "$record/$profile.command"
    printf '\n' >> "$record/$profile.command"
    "${command[@]}" > "$record/$profile.stdout" 2> "$record/$profile.stderr"
done
cmp "$data/plain.tif" "$data/traced.tif"
cmp "$record/plain.events.jsonl" "$record/traced.events.jsonl"
cmp "$record/plain.stdout" "$record/traced.stdout"
cmp "$record/plain.stderr" "$record/traced.stderr"
sha256sum "$data"/{first.png,second.png,plain.tif,traced.tif} > "$record/witness-fixture.sha256"
python3 - "$record" <<'PY'
from pathlib import Path
from collections import Counter
import csv
import json
import sys

record = Path(sys.argv[1])
with (record / "witness.tsv").open() as stream:
    assert stream.readline().strip() == "# dropped_records=0"
    trace = list(csv.DictReader(stream, delimiter="\t"))
counts = Counter((row["frame"], row["stage"]) for row in trace)
for frame in ("0", "1"):
    for stage in ("decode", "identity", "proxy_upload", "proxy_readback", "fusion_upload", "fusion_wait"):
        assert counts[frame, stage] == 1, (frame, stage)
    for row in trace:
        if row["frame"] == frame and row["stage"] in ("proxy_upload", "fusion_upload"):
            assert int(row["logical_bytes"]) == 1716, row
assert counts["-", "job_total"] == 1
event = json.loads((record / "traced.events.jsonl").read_text())
assert event["completed"] and event["runtime"] == "cpu" and event["actual_backend"] == "cpu"
assert all(matrix == [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]] for matrix in event["alignment_transforms"].values())
print(f"The two CPU exports, completion events and progress streams matched at {len(trace)} trace records.")
PY

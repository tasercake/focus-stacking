python3 <BORROWER_WORKTREE>/pancake/docs/d150-geometry-audit/anchor-skip-prereg/anchor_skip_trial.py --plan <BORROWER_WORKTREE>/pancake/docs/d150-geometry-audit/anchor-skip-prereg/plan.json prepare 

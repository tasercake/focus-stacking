#!/usr/bin/env bash
set -euo pipefail
repo="$PWD"
folder="$repo/pancake/docs/d150-geometry-audit/anchor-skip-prereg"
proof="$repo/artifacts/d150-packed-empty"
trial="$folder/anchor_skip_trial.py"
plan="$folder/plan.json"
stage="$repo/artifacts/d150-anchor-skip-011/run-001"
owner=<LENDER_STAGE>
removal=<WORKSPACE>/artifacts/p10-stock-lifecycle-e81079d/d150-archive-removal.json
reference_python=<WORKSPACE>/pancake-conformance/src/pancake_conformance/adapters/chimpstackr_reference/.venv/bin/python
acquisition="$stage/materialized/acquisition.json"
export CARGO_TARGET_DIR="$repo/pancake/target/d150-packed-empty" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
actual_revision=$(git rev-parse HEAD)
test "$actual_revision" = 914ec559fdfcea07465bd02e65dc8e2e3e5f977c
test -z "$(git status --porcelain)"
test -z "$(git diff --name-only af964f5 -- pancake/src pancake/Cargo.lock pancake/Cargo.toml pancake/.cargo pancake/vendor)"
record() {
    local name=$1 exit_status=0
    shift
    printf '%q ' "$@" > "$proof/$name.command"
    printf '\n' >> "$proof/$name.command"
    date --iso-8601=seconds > "$proof/$name.start"
    "$@" > "$proof/$name.log" 2>&1 || exit_status=$?
    printf '%s\n' "$exit_status" > "$proof/$name.status"
    date --iso-8601=seconds > "$proof/$name.end"
    tail -12 "$proof/$name.log"
    return "$exit_status"
}
record prepare python3 "$trial" --plan "$plan" prepare
mkdir -p "$repo/pancake/examples" "$stage/bin"
example="$repo/pancake/examples/d150_anchor_skip_probe.rs"
(
    test ! -e "$example"
    cp "$stage/d150_anchor_skip_probe.rs" "$example"
    trap 'rm "$example"' EXIT
    cd pancake
    record real-build taskset --cpu-list 4,5 cargo +1.100.0 build --locked --offline --example d150_anchor_skip_probe
)
cp "$CARGO_TARGET_DIR/debug/examples/d150_anchor_skip_probe" "$stage/bin/"
sha256sum "$stage/bin/d150_anchor_skip_probe" > "$proof/real-binary.sha256"
sha256sum "$stage/d150_anchor_skip_probe.rs" > "$proof/real-example.sha256"
sha256sum "$reference_python" > "$proof/reference-python.sha256"
"$reference_python" -c 'import cv2,numpy,sys; print(sys.version); print(cv2.__version__,numpy.__version__)' > "$proof/reference-python.version"
postflight() {
    record lender-postflight taskset --cpu-list 4,5 python3 "$proof/borrow-011.py.txt" \
      postflight "$plan" "$stage" "$owner" "$removal" "$proof/lender-postflight.json"
}
trap postflight EXIT
record stage-borrow taskset --cpu-list 4,5 python3 "$proof/borrow-011.py.txt" \
  stage "$plan" "$stage" "$owner" "$removal" "$proof/lender-preflight.json"
record staged-verify python3 "$trial" --plan "$plan" verify-inputs
record real-proposals timeout --signal=TERM --kill-after=5s 150s taskset --cpu-list 4,5 \
  "$stage/bin/d150_anchor_skip_probe" --plan "$plan" --acquisition "$acquisition" \
  --output "$stage/product-proposals.json"
record real-holdouts timeout --signal=TERM --kill-after=5s 150s taskset --cpu-list 4,5 \
  "$reference_python" -B "$trial" --plan "$plan" score --trace "$stage/product-proposals.json" \
  --output "$stage/native-holdouts.json"
sha256sum "$stage/packed-directions.json" "$stage/product-proposals.json" "$stage/native-holdouts.json" > "$proof/real-report.sha256"
if ! jq -e '.controls.status == "controls_reproduced"' "$stage/native-holdouts.json" >/dev/null; then
    printf '%s\n' 'Native control screen inconclusive; optional packed replay is ineligible under the preregistration.' > "$proof/packed-disposition.txt"
elif ! jq -e '.results | length > 0' "$stage/packed-directions.json" >/dev/null; then
    printf '%s\n' 'No distinct three-map inputs; optional fixed-layout packed replay is unavailable.' > "$proof/packed-disposition.txt"
else
    archived="$repo/pancake/docs/d150-geometry-audit/witness-batching/real-overlay.patch.gz"
    control="$folder/packed-control.patch.gz"
    zero_overlap="$folder/packed-zero-overlap.patch.gz"
    (
        trap - EXIT
        sha256sum -c "$proof/real-report.sha256"
        gzip -dc "$archived" | git apply
        if ! gzip -dc "$control" | git apply; then gzip -dc "$archived" | git apply -R; exit 1; fi
        if ! gzip -dc "$zero_overlap" | git apply; then
            gzip -dc "$control" | git apply -R
            gzip -dc "$archived" | git apply -R
            exit 1
        fi
        cleanup() {
            gzip -dc "$zero_overlap" | git -C "$repo" apply -R
            gzip -dc "$control" | git -C "$repo" apply -R
            gzip -dc "$archived" | git -C "$repo" apply -R
        }
        trap cleanup EXIT
        cd pancake
        export PANCAKE_WITNESS_ACQUISITION="$acquisition" PANCAKE_WITNESS_DIRECTIONS="$stage/packed-directions.json"
        export PANCAKE_WITNESS_OUTPUT="$stage/packed-corroboration.json"
        record real-packed taskset --cpu-list 4,5 cargo +1.100.0 test --locked --offline --lib \
          packed_witness_real_d150_proxy_diagnostic -- --test-threads=1
    )
    printf '%s\n' 'Optional packed replay completed; compare each native and proxy verdict.' > "$proof/packed-disposition.txt"
fi
record final-copy-verify python3 "$trial" --plan "$plan" verify-inputs
test -z "$(git status --porcelain)"

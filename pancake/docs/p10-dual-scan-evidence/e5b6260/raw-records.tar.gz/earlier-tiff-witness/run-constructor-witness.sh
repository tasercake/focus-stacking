#!/usr/bin/env bash
set -euo pipefail

receipt_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
arm=$1
test_name=$2
expected=$3
executable=$(python3 - "$receipt_dir/$arm-cargo.jsonl" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as manifest:
    for line in manifest:
        row = json.loads(line)
        if row.get("target", {}).get("name") == "cpu_image_io" and row.get("executable"):
            print(row["executable"])
            break
    else:
        raise SystemExit("Cargo did not report the compiled cpu_image_io test executable")
PY
)
sha256sum "$executable" > "$receipt_dir/$arm-executable.sha256"
set +e
taskset -c 6,7 gdb -q -nx -batch -iex 'set debuginfod enabled off' -ex "set \$expected_hits = $expected" \
    -x "$receipt_dir/constructor-witness.gdb" --args "$executable" \
    --exact "$test_name" --test-threads=1 > "$receipt_dir/$arm-$test_name.gdb.log" 2>&1
result=$?
set -e
echo "$result" > "$receipt_dir/$arm-$test_name.status"
cat "$receipt_dir/$arm-$test_name.gdb.log"
exit "$result"

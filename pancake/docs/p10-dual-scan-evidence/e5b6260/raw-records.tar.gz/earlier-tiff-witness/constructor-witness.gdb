set debuginfod enabled off
set pagination off
set confirm off
set disable-randomization off
set print thread-events off
set breakpoint pending off
set $constructor_hits = 0
break '<pancake::image_io::RgbImage>::new'
commands 1
  silent
  set $constructor_hits = $constructor_hits + 1
  continue
end
run
printf "PUBLIC_RGB_CONSTRUCTOR_HITS=%d EXPECTED=%d\n", $constructor_hits, $expected_hits
if $_exitcode != 0
  quit 2
end
if $constructor_hits != $expected_hits
  quit 1
end
quit 0
